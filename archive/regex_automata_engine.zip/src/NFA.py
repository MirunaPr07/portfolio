from .DFA import DFA

from dataclasses import dataclass
from collections.abc import Callable

EPSILON = ''  # this is how epsilon is represented by the checker in the transition function of NFAs


@dataclass
class NFA[STATE]:
    S: set[str] # alfabetul
    K: set[STATE] # starile
    q0: STATE # starea init.
    d: dict[tuple[STATE, str], set[STATE]] # descrierea tranzitiilor
    F: set[STATE] # starile finale

    def epsilon_closure(self, state: STATE) -> set[STATE]:
        set_final = set()
        queue = [] # coada simulata cu o lista, in care mereu adug cu append si scot cu pop(0)
        queue.append(state)
        while len(queue) != 0:
            crt = queue.pop(0)
            set_final.add(crt)
            if (crt, EPSILON) in self.d:
                for st in self.d[(crt, EPSILON)]: # verific ca starea sa nu fie nici deja proc nici in parcurs de proc
                    if st not in set_final and st not in queue: # sa nu adaug de 2 ori aceeasi stare in coada!!
                        queue.append(st)
        return set_final

    def subset_construction(self) -> DFA[frozenset[STATE]]:
        alfabet = set(self.S)
        total_stari = set() # retin starile de la pasul asta intr un set de frozenset uri!!
        stari_finale = set()
        coada_stari = []
        dict_nou = {}
        stare_init = self.epsilon_closure(self.q0)
        coada_stari.append(stare_init)
        total_stari.add(frozenset(stare_init))
        while len(coada_stari) != 0:
            stare_crt = coada_stari.pop(0)
            for final in self.F:
                if final in stare_crt:
                    stari_finale.add(frozenset(stare_crt))
                    break
            for x in self.S:
                creata = set()
                for st in stare_crt:
                    if (st, x) in self.d:
                        urmatoare = self.d[(st, x)]
                        for aux in urmatoare:
                            creata.add(aux)
                            eps = self.epsilon_closure(aux)
                            for e in eps:
                                creata.add(e)
                if frozenset(creata) not in total_stari and creata not in coada_stari:
                    coada_stari.append(creata)
                total_stari.add(frozenset(creata)) # daca deja am starea asta, nu se mai adauga o data pt ca e set
                dict_nou[(frozenset(stare_crt), x)] = frozenset(creata) # in dfa toate starile sunt reprez. ca frozenset uri!!!!
        return DFA(alfabet, total_stari, frozenset(stare_init), dict_nou, stari_finale)



    def remap_states[OTHER_STATE](self, f: 'Callable[[STATE], OTHER_STATE]') -> 'NFA[OTHER_STATE]':
        return self
