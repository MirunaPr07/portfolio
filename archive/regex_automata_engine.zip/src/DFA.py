from collections.abc import Callable
from dataclasses import dataclass
from itertools import product
from typing import TypeVar
from functools import reduce

STATE = TypeVar('STATE')

@dataclass
class DFA[STATE]:
    S: set[str]
    K: set[STATE]
    q0: STATE
    d: dict[tuple[STATE, str], STATE]
    F: set[STATE]
    

    def accept(self, word: str) -> bool:
        stare_crt = self.q0
        for c in word:
            if c in self.S: # verific doar sa fie in alfabet
                stare_crt = self.d[stare_crt, c]
                continue
            return False
        if stare_crt in self.F:
            return True
        return False

    def rename(self) -> 'DFA[int]':
        # redenumirea starilor mai intai
        # nu mi a placut cum arata remap_states:
        # alfabetul e acelasi, modif structura starilor
        index = 0
        stari_noi = set()
        stari_fin = set()
        dict_nume = {}
        for stare in self.K:
            if stare in self.F:
                stari_fin.add(index)
            dict_nume[stare] = index
            stari_noi.add(index)
            index += 1
        stare_init = dict_nume[self.q0]
        dict_nou = {}
        for sursa, dest in self.d.items():
            dict_nou[(dict_nume[sursa[0]], sursa[1])] = dict_nume[dest]
        # acum trebuie sa lucrez cu parametrii asa:
        # self.S alfabet, stari_noi starile, stare_init starea initiala, dict_nou dictionarul, stari_fin starile finale
        return DFA(self.S, stari_noi, stare_init, dict_nou, stari_fin)


    def minimize(self) -> 'DFA[STATE]':
        dfa_crt = self.rename()
        lista_stari = sorted(dfa_crt.K) # il sortez direct ca sa am 0->0, 1->1, 2->2, deja m am sucit prea mult cu indecsii si ma incurc in ei
        lista_finale = list(dfa_crt.F)
        index = len(dfa_crt.K)
        matrix = [[0 for j in range(index)] for i in range(index)] # matrice cu nr de linii si col = index
        for i in range(index):
            for j in range(i + 1, index):
                if (lista_stari[i] in lista_finale and lista_stari[j] not in lista_finale) or (lista_stari[j] in lista_finale and lista_stari[i] not in lista_finale):
                    matrix[i][j] = 1
        # adica de la 0 la index inclusiv
        ok = True
        while ok == True:
            ok = False
            for i in range(index):
                for j in range(i + 1, index):
                    if matrix[i][j] != 1: # daca nu le am marcat deja ca distinguishable
                        for c in dfa_crt.S:
                            if matrix[dfa_crt.d[(lista_stari[i], c)]][dfa_crt.d[(lista_stari[j], c)]] == 1 or matrix[dfa_crt.d[(lista_stari[j], c)]][dfa_crt.d[(lista_stari[i], c)]] == 1:
                                matrix[i][j] = 1
                                ok = True
                                break
        echipe = {} # dictionar in care imi spun: starii x ii corespunde exhipa y
        for st in lista_stari:
            echipe[st] = st # toate sunt pe cont propriu
        for i in range(index):
            for j in range(i + 1, index):
                if matrix[i][j] == 0: # le adaug in aceeasi echipa
                    echipe[lista_stari[j]] = echipe[lista_stari[i]]
        stari_noi = set()
        fin_nou = set()
        for x, y in echipe.items():
            if x == dfa_crt.q0:
                init = y
            if x in lista_finale:
                fin_nou.add(y)
            stari_noi.add(y)
        # stari noi imi sunt echipele efectiv
        # init = starea initiala
        # stari_noi = totalitatea starilor
        # acelasi alfabet, fin_nou = set cu stari finale
        dict_nou = {}
        for sursa, dest in dfa_crt.d.items():
            dict_nou[(echipe[sursa[0]], sursa[1])] = echipe[dest] # se suprascrie cand am bulce catre aceeasi stare/ stari int ale unei echipe
        dfa_final = DFA(dfa_crt.S, stari_noi, init, dict_nou, fin_nou)
        return dfa_final
        
    def remap_states[OTHER_STATE](self, f: Callable[[STATE], 'OTHER_STATE']) -> 'DFA[OTHER_STATE]':
        return self
    
    