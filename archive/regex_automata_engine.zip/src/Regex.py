from typing import Any, List
from .NFA import NFA
from dataclasses import dataclass

EPSILON = ''

class Regex:
    index_crt = 0
    def thompson(self) -> NFA[int]:
        pass

    
class Caract(Regex):
    def __init__(self, c):
        self.c = c
    def thompson(self) -> NFA[int]:
        S = set()
        K = set()
        F = set()
        d = {}
        S.add(self.c)
        K.add(Regex.index_crt)
        K.add(Regex.index_crt + 1)
        q0 = Regex.index_crt
        F.add(Regex.index_crt + 1)
        d[(q0, self.c)] = {Regex.index_crt + 1}
        Regex.index_crt += 2
        return NFA(S, K, q0, d, F)


class Anything(Regex):
    def __init__(self, chars):
        self.chars = chars   # sir de caractere
    def thompson(self) -> NFA[int]:
        S = set()
        K = set()
        F = set()
        d = {}
        for c in self.chars:
            S.add(c) # alfabetul aici inseamna toate caracterele din interval
        K.add(Regex.index_crt)
        K.add(Regex.index_crt + 1)
        q0 = Regex.index_crt
        F.add(Regex.index_crt + 1)
        for c in self.chars:
            d[(q0, c)] = {Regex.index_crt + 1}
        Regex.index_crt += 2
        return NFA(S, K, q0, d, F)

class Eps(Regex):
    def __init__(self):
        pass
    def thompson(self) -> NFA[int]:
        S = set()
        K = set()
        F = set()
        d = {}
        # ca alfabet nu am nimic => set gol
        K.add(Regex.index_crt)
        K.add(Regex.index_crt + 1)
        q0 = Regex.index_crt
        F.add(Regex.index_crt + 1)
        d[(q0, EPSILON)] = {Regex.index_crt + 1}
        Regex.index_crt += 2
        return NFA(S, K, q0, d, F)


class Star(Regex):
    def __init__(self, regex_crt):
        self.regex_crt = regex_crt
    def thompson(self) -> NFA[int]:
        expresie = self.regex_crt
        nfa_expresie = expresie.thompson()
        # mi am calculat recursiv thompson pt fiecare elem de baza din expresie
        # alfabetul ramane acelasi ca la expresia primita
        alfabet = set(nfa_expresie.S)
        set_fin = set()
        dict_nou = {}
        init_vechi = nfa_expresie.q0
        fin_vechi = next(iter(nfa_expresie.F)) # oricum F are doar un element inauntru
        stari = set(nfa_expresie.K) # imi creez un set nou ce cont. toate starile vechi
        stari.add(Regex.index_crt)
        stari.add(Regex.index_crt + 1)
        init_nou = Regex.index_crt
        fin_nou = Regex.index_crt + 1
        set_fin.add(fin_nou)
        for tuplu, stare in nfa_expresie.d.items():
            dict_nou[tuplu] = set(stare)
        dict_nou[(init_nou, EPSILON)] = {init_vechi}
        if (fin_vechi, EPSILON) in dict_nou:
            dict_nou[(fin_vechi, EPSILON)].add(fin_nou)
        else:
            dict_nou[(fin_vechi, EPSILON)] = {fin_nou}
        dict_nou[(fin_vechi, EPSILON)].add(init_vechi)
        dict_nou[(init_nou, EPSILON)].add(fin_nou)
        Regex.index_crt += 2
        return NFA(alfabet, stari, init_nou, dict_nou, set_fin)

class Plus(Regex):
    def __init__(self, regex_crt):
        self.regex_crt = regex_crt
    def thompson(self) -> NFA[int]:
        expresie = self.regex_crt
        nfa_expresie = expresie.thompson()
        alfabet = set(nfa_expresie.S)
        set_fin = set()
        dict_nou = {}
        init_vechi = nfa_expresie.q0
        fin_vechi = next(iter(nfa_expresie.F))
        stari = set(nfa_expresie.K)
        stari.add(Regex.index_crt)
        stari.add(Regex.index_crt + 1)
        init_nou = Regex.index_crt
        fin_nou = Regex.index_crt + 1
        set_fin.add(fin_nou)
        for tuplu, stare in nfa_expresie.d.items():
            dict_nou[tuplu] = set(stare)
        dict_nou[(init_nou, EPSILON)] = {init_vechi}
        if (fin_vechi, EPSILON) in dict_nou:
            dict_nou[(fin_vechi, EPSILON)].add(fin_nou)
        else:
            dict_nou[(fin_vechi, EPSILON)] = {fin_nou}
        dict_nou[(fin_vechi, EPSILON)].add(init_vechi)
        Regex.index_crt += 2
        return NFA(alfabet, stari, init_nou, dict_nou, set_fin)

class Question(Regex):
    def __init__(self, regex_crt):
        self.regex_crt = regex_crt
    def thompson(self) -> NFA[int]:
        expresie = self.regex_crt
        nfa_expresie = expresie.thompson()
        alfabet = set(nfa_expresie.S)
        set_fin = set()
        dict_nou = {}
        init_vechi = nfa_expresie.q0
        fin_vechi = next(iter(nfa_expresie.F))
        stari = set(nfa_expresie.K)
        stari.add(Regex.index_crt)
        stari.add(Regex.index_crt + 1)
        init_nou = Regex.index_crt
        fin_nou = Regex.index_crt + 1
        set_fin.add(fin_nou)
        for tuplu, stare in nfa_expresie.d.items():
            dict_nou[tuplu] = set(stare)
        dict_nou[(init_nou, EPSILON)] = {init_vechi}
        if (fin_vechi, EPSILON) in dict_nou:
            dict_nou[(fin_vechi, EPSILON)].add(fin_nou)
        else:
            dict_nou[(fin_vechi, EPSILON)] = {fin_nou}
        dict_nou[(init_nou, EPSILON)].add(fin_nou)
        Regex.index_crt += 2
        return NFA(alfabet, stari, init_nou, dict_nou, set_fin)
    


class Concat(Regex):
    def __init__(self, regex1, regex2):
        self.regex1 = regex1
        self.regex2 = regex2
    def thompson(self) -> NFA[int]:
        r1 = self.regex1
        r2 = self.regex2
        nfa1 = r1.thompson()
        nfa2 = r2.thompson()
        dict_nou = {}
        alfabet = set(nfa1.S)
        alfabet.update(nfa2.S) # adaug si elementele alf. nfa ului 2 cu update
        init_vechi1 = nfa1.q0
        init_vechi2 = nfa2.q0
        fin_vechi1 = next(iter(nfa1.F))
        fin_vechi2 = next(iter(nfa2.F))
        stari = set(nfa1.K)
        stari.update(nfa2.K)
        init_nou = Regex.index_crt
        fin_nou = Regex.index_crt + 1
        stari.add(init_nou)
        stari.add(fin_nou)
        stare_fin_nou = {fin_nou}
        for tuplu, stare in nfa1.d.items():
            dict_nou[tuplu] = set(stare)
        for tuplu, stare in nfa2.d.items():
            dict_nou[tuplu] = set(stare)
        dict_nou[(init_nou, EPSILON)] = {init_vechi1}
        if (fin_vechi1, EPSILON) in dict_nou:
            dict_nou[(fin_vechi1, EPSILON)].add(init_vechi2)
        else:
            dict_nou[(fin_vechi1, EPSILON)] = {init_vechi2}
        if (fin_vechi2, EPSILON) in dict_nou:
            dict_nou[(fin_vechi2, EPSILON)].add(fin_nou)
        else:
            dict_nou[(fin_vechi2, EPSILON)] = {fin_nou}
        Regex.index_crt += 2
        return NFA(alfabet, stari, init_nou, dict_nou, stare_fin_nou)

class Union(Regex):
    def __init__(self, regex1, regex2):
        self.regex1 = regex1
        self.regex2 = regex2
    def thompson(self) -> NFA[int]:
        r1 = self.regex1
        r2 = self.regex2
        nfa1 = r1.thompson()
        nfa2 = r2.thompson()
        dict_nou = {}
        alfabet = set(nfa1.S)
        alfabet.update(nfa2.S)
        init_vechi1 = nfa1.q0
        init_vechi2 = nfa2.q0
        fin_vechi1 = next(iter(nfa1.F))
        fin_vechi2 = next(iter(nfa2.F))
        stari = set(nfa1.K)
        stari.update(nfa2.K)
        init_nou = Regex.index_crt
        fin_nou = Regex.index_crt + 1
        stari.add(init_nou)
        stari.add(fin_nou)
        stare_fin_nou = {fin_nou}
        for tuplu, stare in nfa1.d.items():
            dict_nou[tuplu] = set(stare)
        for tuplu, stare in nfa2.d.items():
            dict_nou[tuplu] = set(stare)
        dict_nou[(init_nou, EPSILON)] = {init_vechi1}
        dict_nou[(init_nou, EPSILON)].add(init_vechi2)
        if (fin_vechi1, EPSILON) in dict_nou:
            dict_nou[(fin_vechi1, EPSILON)].add(fin_nou)
        else:
            dict_nou[(fin_vechi1, EPSILON)] = {fin_nou}
        if (fin_vechi2, EPSILON) in dict_nou:
            dict_nou[(fin_vechi2, EPSILON)].add(fin_nou)
        else:
            dict_nou[(fin_vechi2, EPSILON)] = {fin_nou}
        Regex.index_crt += 2
        return NFA(alfabet, stari, init_nou, dict_nou, stare_fin_nou)
    
    
def extract_caractere(sir):
    caractere = []
    i = 0
    while i <= len(sir) - 1:
        c = sir[i]
        if c == '(' or c == ')' or c == '?' or c == '*' or c == '+' or c == '|':
            caractere.append(("operator", c))
        elif c == 'e' and i + 2 <= len(sir) - 1 and sir[i + 1] == 'p' and sir[i + 2] == 's':
            caractere.append(("epsilon", 'e')) # il retin ca a fost epsilon si sar peste
            i += 2 # o sa mai creasca o data cu 1 din while, deci ajunge sa cresc cu 2
        elif c == ' ': # tin cont sa sar specific peste spatiu!!!!! altfel ajung in else si il retin caracter
            i += 1
            continue
        elif c == '\\':  # trebuie escapat chiar si in cod:))
            caractere.append(("caracter", sir[i + 1]))
            i += 1
        elif c == '[':
            caractere.append(("any", sir[i + 1 : i + 4])) # il descriu ca: orice caracter intre si intre
            i += 4
        else:
            caractere.append(("caracter", c))
        i += 1
    return caractere


def add_concat(caractere):
    # adaug concatenarea ca o operatie specificata cu caracterul .
    # concatenarea poate aparea in mai multe cazuri: intre A si B
    # unde a poate fi: caracter, any, epsilon, unii operatori( ')', '*', '+', '?')
    # iar b caracter, any, epsilon si op. '('
    lista_noua = []
    i = 0
    while i <= len(caractere) - 1:
        crt = caractere[i]
        urm = None
        if i != len(caractere) - 1: # inseamna ca exista urmatorul element
            urm = caractere[i + 1]
        if crt[0] == "caracter" or crt[0] == "any" or crt[0] == "epsilon" or (crt[0] == "operator" and crt[1] != '(' and crt[1] != '|'):
            if urm != None and (urm[0] == "caracter" or urm[0] == "any" or urm[0] == "epsilon" or (urm[0] == "operator" and urm[1] == '(')):
                lista_noua.append(crt)
                lista_noua.append(("operator", '.'))
                i += 1
                continue
        lista_noua.append(crt)
        i += 1
    return lista_noua

def reprez_post(caractere):
    # eu la mom actual am o lista de tupluri in caractere
    lista_noua = []
    stiva = [] # stiva se ocupa de ordine => relevant pt. (), | si .

    for tip, caract in caractere:
        if tip == "caracter" or tip == "epsilon" or tip == "any":
            lista_noua.append((tip, caract))
        elif tip == "operator" and (caract == '*' or caract == '?' or caract == '+'):
            lista_noua.append((tip, caract))
        elif tip == "operator" and caract == '(':
            stiva.append(caract) 
            continue
        elif tip == "operator" and caract == ')':
            crt = stiva[-1]
            while crt != '(':
                lista_noua.append(("operator", crt))
                stiva.pop()
                crt = stiva[-1]
            stiva.pop()
            continue
        else: # mi au ramas de gestionat cazurile de | si . (prioritati, in ce ordine le adaug)
            while len(stiva) != 0 and stiva[-1] != '(' and (caract == stiva[-1] or (caract == '|' and stiva[-1] == '.')):
                lista_noua.append(("operator", stiva[-1]))
                stiva.pop()
            stiva.append(caract)
    while len(stiva) != 0:
        lista_noua.append(("operator", stiva[-1]))
        stiva.pop()
    return lista_noua

def reprez_finala(caractere):
    # nu uita ca acum reprezentarea lui caractere este tot sub forma unei liste de tupluri
    # de tipul (tip, valoare_efectiva)
    stiva = []
    for tip, val in caractere:
        if tip == "epsilon":
            stiva.append(Eps())
        elif tip == "caracter":
            stiva.append(Caract(val))
        elif tip == "operator":
            if val == '*':
                ultim = stiva.pop()
                stiva.append(Star(ultim))
            elif val == '+':
                ultim = stiva.pop()
                stiva.append(Plus(ultim))
            elif val == '?':
                ultim = stiva.pop()
                stiva.append(Question(ultim))
            elif val == '.':
                r2 = stiva.pop()
                r1 = stiva.pop()
                stiva.append(Concat(r1, r2))
            else:
                r2 = stiva.pop()
                r1 = stiva.pop()
                stiva.append(Union(r1, r2))
        else:
            # mi a ramas cazul de any!!
            sir = ""
            for i in range(ord(val[0]), ord(val[2]) + 1): # nu uita: il iei si pe ultimul => +1
                sir += chr(i)
            stiva.append(Anything(sir))
    return stiva[0]

def parse_regex(sir):
    Regex.index_crt = 0 # primesc un regex nou in checker => apeleaza mai intai parse, deci resetez la fiecare regex crt index ul la 0
    return reprez_finala(reprez_post(add_concat(extract_caractere(sir))))
