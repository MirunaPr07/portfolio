#include "lab_m1/tema2/tema2.h"

#include <vector>
#include <string>
#include <iostream>

using namespace std;
using namespace m1;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Tema2::Tema2()
{
}


Tema2::~Tema2()
{
}


void Tema2::Init()
{
    // din laborator: generarea unui cub, poate ajuta mai tarziu:
    // am ales pentru gari: cuburi, sfera, teapot
    {
        Mesh* mesh = new Mesh("box");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    {
        Mesh* mesh = new Mesh("sphere");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "sphere.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    {
        Mesh* mesh = new Mesh("teapot");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "teapot.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    // imi adaug fiecare gara in vectorul meu de gari acum ca am declarat si mesh urile:
    vectGari.clear();
    Gara g1, g2, g3, g4;
    // gara 1, principala:
    g1.col = glm::vec3(1.0f, 1.0f, 0.2f);
    g1.tip = TipGara::PRINC;
    g1.mesh = "box";
    g1.scale = 1.5f; // mai mare ca e principala
    g1.poz = LocGara(LiniiMediu / 2.0f, ColoaneMediu / 2.0f, 0.75f);
    vectGari.push_back(g1);

    //gara 2, sfera:
    g2.col = glm::vec3(0.2f, 0.7f, 1.0f);
    g2.tip = TipGara::SEC1;
    g2.mesh = "sphere";
    g2.scale = 1.3f;
    g2.poz = LocGara(2, 4, 0.45f); // pe munte?
    vectGari.push_back(g2);

    g3.col = glm::vec3(1.0f, 0.4f, 0.2f);
    g3.tip = TipGara::SEC2;
    g3.mesh = "teapot";
    g3.scale = 1.8f;
    g3.poz = LocGara(LiniiMediu - 2, ColoaneMediu - 4, 0.13f); // sub rau? ca sa treaca peste el
    vectGari.push_back(g3);

    g4.col = glm::vec3(0.8f, 0.2f, 0.9f);
    g4.tip = TipGara::SEC3;
    g4.mesh = "box";
    g4.scale = 1.0f;
    g4.poz = LocGara(LiniiMediu - 4, 2, 0.48f);
    vectGari.push_back(g4);

    // proiectia initiala:
    glm::ivec2 res = window->GetResolution();
    float aspect = (float)res.x / (float)res.y;
    projectionMatrix = glm::perspective(RADIANS(60.0f), aspect, 0.01f, 200.0f);

    auto cam = GetSceneCamera();
    cam->SetPosition(glm::vec3(0, 15.0f, 15.0f));
    cam->SetRotation(glm::vec3(-0.6f, 0, 0));
    cam->Update();


    // Create a shader program for drawing face polygon with the color of the normal
    {
        Shader *shader = new Shader("LabShader");
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "tema2", "shaders", "VertexShader.glsl"), GL_VERTEX_SHADER);
        shader->AddShader(PATH_JOIN(window->props.selfDir, SOURCE_PATH::M1, "tema2", "shaders", "FragmentShader.glsl"), GL_FRAGMENT_SHADER);
        shader->CreateAndLink();
        shaders[shader->GetName()] = shader;
    }
    CreeazaMeshMediu(LiniiMediu, ColoaneMediu, DimPatrat);

    // imi aleg manual traseul sinelor, cel gandit pe foaie:
    // mai intai adaug in vectorul de rails fiecare sina, iar la sfarsit vad cu functia mea creata pentru legaturi
    // care sunt relatiile dintre sine; actualizez next si children
    // formatul functiei e l1, l2, c1, c2 !!!!!
    rails.clear();
    for (int i = 5; i <= ColoaneMediu - 6; i++)
        AdaugaDublu(2, 2, i, i + 1);
    for (int i = 2; i <= LiniiMediu - 3; i++)
        AdaugaDublu(i, i + 1, ColoaneMediu - 5, ColoaneMediu - 5);
    for (int i = 1; i <= ColoaneMediu / 2 - 2; i++)
        AdaugaDublu(LiniiMediu / 2, LiniiMediu / 2, i, i + 1);
    for (int i = ColoaneMediu / 2 + 1; i <= ColoaneMediu - 6; i++)
        AdaugaDublu(LiniiMediu / 2, LiniiMediu / 2, i, i + 1);
    for (int i = 2; i <= LiniiMediu - 5; i++)
        AdaugaDublu(i, i + 1, 5, 5);
    for (int i = 3; i <= 8; i++)
        AdaugaDublu(19, 19, i, i + 1);
    for (int i = 16; i <= LiniiMediu - 3; i++)
        AdaugaDublu(i, i + 1, 9, 9);
    for (int i = 9; i <= ColoaneMediu - 6; i++)
        AdaugaDublu(16, 16, i, i + 1);
    for (int i = 9; i <= ColoaneMediu - 6; i++)
        AdaugaDublu(LiniiMediu - 2, LiniiMediu - 2, i, i + 1);
    GestioneazaLegaturi();

    // setez totul pentru tren
    InitTrain();
    train.speed = 4.0f; // am setat o mai mare, nu era timp intr un minut
    // am avut nevoie pentru constructia trenului sa creez mesh ul de cilindru:
    meshes["cil"] = CreeazaMeshCilindru("cil", 1.0f, 1.0f);

    // imi setez toate valorile, sa pot incepe jocul efectiv
    InitResources();
    GenereazaComandaNoua();
    gameOver = false;
    comandaCompleta = false;
    eramInStatie = false;
    statieCurenta = -1;
}

// toata numai din lab
Mesh* Tema2::CreateMesh(const char *name, const std::vector<VertexFormat> &vertices, const std::vector<unsigned int> &indices)
{
    unsigned int VAO = 0;
    // Create the VAO and bind it
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    // Create the VBO and bind it
    unsigned int VBO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    // Send vertices data into the VBO buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices[0], GL_STATIC_DRAW);

    // Create the IBO and bind it
    unsigned int IBO;
    glGenBuffers(1, &IBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);

    // Send indices data into the IBO buffer
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices[0], GL_STATIC_DRAW);

    // ========================================================================
    // This section demonstrates how the GPU vertex shader program
    // receives data.

    // TODO(student): If you look closely in the `Init()` and `Update()`
    // functions, you will see that we have three objects which we load
    // and use in three different ways:
    // - LoadMesh   + LabShader (this lab's shader)
    // - CreateMesh + VertexNormal (this shader is already implemented)
    // - CreateMesh + LabShader (this lab's shader)
    // To get an idea about how they're different from one another, do the
    // following experiments. What happens if you switch the color pipe and
    // normal pipe in this function (but not in the shader)? Now, what happens
    // if you do the same thing in the shader (but not in this function)?
    // Finally, what happens if you do the same thing in both places? Why?

    // position
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)offsetof(VertexFormat, position));

    // color
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)offsetof(VertexFormat, color));

    // text_coord
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)offsetof(VertexFormat, text_coord));

    // normal
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)offsetof(VertexFormat, normal));

    // ========================================================================

    // Unbind the VAO
    glBindVertexArray(0);

    // Check for OpenGL errors
    CheckOpenGLError();

    // Mesh information is saved into a Mesh object
    meshes[name] = new Mesh(name);
    meshes[name]->InitFromBuffer(VAO, static_cast<unsigned int>(indices.size()));
    meshes[name]->vertices = vertices;
    meshes[name]->indices = indices;
    return meshes[name];
}


void Tema2::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    if (gameOver == true)
        glClearColor(0.2f, 0.0f, 0.0f, 1.0f); // setez fundalul separat cand am pierdut=> caz over
    else glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();
    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}


void Tema2::Update(float deltaTimeSeconds)
{
    // lumea:
    {
        Shader* sh = shaders["LabShader"];
        glUseProgram(sh->program);

        GLint locatieUse = glGetUniformLocation(sh->program, "folColor");
        glUniform1i(locatieUse, 0);
        glm::mat4 modelMatrix = glm::mat4(1);
        RenderSimpleMesh(meshes["teren"], sh, modelMatrix);
    }
    // toate garile:
    for (auto& g : vectGari) {
        Shader* sh = shaders["LabShader"];
        glUseProgram(sh->program);

        GLint locatieUse;
        locatieUse = glGetUniformLocation(sh->program, "folColor");
        glUniform1i(locatieUse, 1);

        GLint locatieColor;
        locatieColor = glGetUniformLocation(sh->program, "u_color");
        glm::vec3 col = g.col;
        // doar la gara centrala gandesc altfel culoarea, pt ca se  inroseste
        if (g.tip == TipGara::PRINC)
            col = CuloareGaraCentralaDinTimp();
        glUniform3f(locatieColor, col.x, col.y, col.z);

        glm::mat4 modelMatrix = glm::mat4(1);
        modelMatrix = glm::translate(modelMatrix, g.poz);
        modelMatrix = glm::scale(modelMatrix, glm::vec3(g.scale));
        RenderSimpleMesh(meshes[g.mesh], sh, modelMatrix);
    }

    // parcurg tot ce am retinut in vectorul de sine si le desenez!!
    for (auto& r : rails)
        DeseneazaSine(r);
    // update la tren in functie de secunde
    UpdateTrain(deltaTimeSeconds);

    // calc mereu timpul ramas ca sa stiu daca s a terminat runda sau nu
    if (gameOver == false) {
        // timer comanda
        timpRamas -= deltaTimeSeconds;
        if (timpRamas <= 0.0f) {
            timpRamas = 0.0f;
            // s a terminat si opresc trenul acolo unde e
            gameOver = true;
            train.pornit = false;
        }
        // in fiecare secunda apelez functiile care trebuie mereu sa isi ia update in functie de timp:
        UpdateCooldownGari(deltaTimeSeconds);
        VerificaColiziuniStatii(deltaTimeSeconds);
    }

    DeseneazaLocomotiva(train.pozitie, train.gradeY);
    DeseneazaVagon(train.pozitie, train.gradeY);
    DeseneazaComanda();
}
   

void Tema2::FrameEnd()
{
    DrawCoordinateSystem();
}


void Tema2::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix)
{
    if (!mesh || !shader || !shader->GetProgramID())
        return;

    // Render an object using the specified shader and the specified position
    glUseProgram(shader->program);

    // TODO(student): Get shader location for uniform mat4 "Model"
    GLint locatieModel;
    locatieModel = glGetUniformLocation(shader->program, "Model");

    // TODO(student): Set shader uniform "Model" to modelMatrix
    glUniformMatrix4fv(locatieModel, 1, GL_FALSE, glm::value_ptr(modelMatrix));

    // TODO(student): Get shader location for uniform mat4 "View"
    GLint locatieView;
    locatieView = glGetUniformLocation(shader->program, "View");

    // TODO(student): Set shader uniform "View" to viewMatrix
    glm::mat4 viewMatrix = GetSceneCamera()->GetViewMatrix();
    glUniformMatrix4fv(locatieView, 1, GL_FALSE, glm::value_ptr(viewMatrix));

    // TODO(student): Get shader location for uniform mat4 "Projection"
    GLint locatieProjection;
    locatieProjection = glGetUniformLocation(shader->program, "Projection");


    // TODO(student): Set shader uniform "Projection" to projectionMatrix
    // am schimbat formula putin, ca sa trimit mai departe proiectia dorita de mine la mom actual, calc din onWindowResize
    glUniformMatrix4fv(locatieProjection, 1, GL_FALSE, glm::value_ptr(this->projectionMatrix));


    // Draw the object
    glBindVertexArray(mesh->GetBuffers()->m_VAO);
    glDrawElements(mesh->GetDrawMode(), static_cast<int>(mesh->indices.size()), GL_UNSIGNED_INT, 0);
}

glm::vec3 Tema2::CuloareMediu(TipMediu tip) {
    // primesc tipul (val din enum) si returnez culoarea specifica
    if (tip == TipMediu::CAMPIE)
        return glm::vec3(0.2f, 0.8f, 0.2f); // verde
    else if (tip == TipMediu::APA)
        return glm::vec3(0.2f, 0.4f, 0.9f); // albastru
    else if (tip == TipMediu::MUNTE)
        return glm::vec3(0.55f, 0.27f, 0.07f);
    else return glm::vec3(1, 1, 1);
}

Tema2::TipMediu Tema2::AlegeMediu(int l, int c) {
    // de aici modific eu unde vreau sa fie fiecare chestie
    // eu practic aleg aici unde sa fie apa si muntele, iar torul in rest e campie
    // mai fac niste teste sa vad cum creez harta cum mi o doresc
    // efectul de rau serpuit facut pe foaie:
    if ((l == LiniiMediu - 8 && c >= ColoaneMediu - 8 && c <= ColoaneMediu - 1) || (c == ColoaneMediu - 8 && l >= LiniiMediu - 8 && l <= LiniiMediu - 4) ||
        (l == LiniiMediu - 4 && c >= ColoaneMediu - 14 && c <= ColoaneMediu - 8) || (c == ColoaneMediu - 14 && l >= LiniiMediu - 4))
        return TipMediu::APA;
    // la munte e mai simplu: dreptunghi, pp stanga sus
    if (l >= 1 && l <= 5 && c >= 1 && c <= 9)
        return TipMediu::MUNTE;
    return TipMediu::CAMPIE;
}

void Tema2::CreeazaMeshMediu(int linii, int col, float sizeCasuta) {
    std::vector<VertexFormat> vertecsi;
    std::vector<unsigned int> indecsi;
    float width, height; // coordonatele centrului!!!
    width = col * DimPatrat * 0.5f;
    height = linii * DimPatrat * 0.5f;
    int cnt = 0;
    for (int l = 0; l <= linii - 1; l++)
        for (int c = 0; c <= col - 1; c++) {
            TipMediu t;
            glm::vec3 culoareCrt;
            glm::vec3 normala = glm::vec3(0, 1, 0);
            t = AlegeMediu(l, c);
            culoareCrt = CuloareMediu(t);
            // eu lucrez doar cu coord x si z, y = 0, asa ca
            // astea sunt colturile:
            float x0, x1, z0, z1;
            x0 = c * sizeCasuta - width;
            x1 = (c + 1) * sizeCasuta - width;
            z0 = l * sizeCasuta - height;
            z1 = (l + 1) * sizeCasuta - height;
            // ma fol ca sa stiu unde incepe, unde se term x, si unde incepe/ se term z(triunghiuri)
            vertecsi.push_back(VertexFormat(glm::vec3(x0, 0, z0), culoareCrt, normala));
            vertecsi.push_back(VertexFormat(glm::vec3(x1, 0, z0), culoareCrt, normala));
            vertecsi.push_back(VertexFormat(glm::vec3(x1, 0, z1), culoareCrt, normala));
            vertecsi.push_back(VertexFormat(glm::vec3(x0, 0, z1), culoareCrt, normala));
            // varfurile celor 2 triunghiuri care form patratul crt:
            indecsi.push_back(cnt + 0);
            indecsi.push_back(cnt + 1);
            indecsi.push_back(cnt + 2);

            indecsi.push_back(cnt + 0);
            indecsi.push_back(cnt + 2);
            indecsi.push_back(cnt + 3);
            cnt += 4;
        }
    CreateMesh("teren", vertecsi, indecsi);
}

glm::vec3 Tema2::LocGara(int l, int c, float y) {
    float width, height;
    // centrul:
    width = DimPatrat * ColoaneMediu * 0.5f;
    height = DimPatrat * LiniiMediu * 0.5f;
    // centrul casutei in care vreau sa adaug noua gara:
    float x, z;
    x = c * DimPatrat - width + DimPatrat / 2.0f;
    z = l * DimPatrat - height + DimPatrat / 2.0f;
    return glm::vec3(x, y, z);
}

glm::vec3 Tema2::AlegePozSina(int l, int c, float y) {
    float width, height;
    width = DimPatrat * ColoaneMediu * 0.5f;
    height = DimPatrat * LiniiMediu * 0.5f;
    float x, z;
    x = c * DimPatrat - width + DimPatrat / 2.0f;
    z = l * DimPatrat - height + DimPatrat / 2.0f;
    return glm::vec3(x, y, z);
}
// functie careia ii zic: vreau sa trag o sina de la pozitia asta din grid la pozitia asta, si eu o adaug in vector
void Tema2::AdaugaSina(int l1, int l2, int c1, int c2) {
    glm::vec3 poz1, poz2;
    TipMediu tip1, tip2;
    poz1 = AlegePozSina(l1, c1);
    poz2 = AlegePozSina(l2, c2);
    tip1 = AlegeMediu(l1, c1);
    tip2 = AlegeMediu(l2, c2);
    // mi am calculat pozitiile centrelor casutelor intre care vreau sa trag sina
    Rail r;
    if (l1 == l2) // orizontala!!
        r.orientare = OrientareSine::ORIZ;
    else r.orientare = OrientareSine::VERT;
    if (tip1 == TipMediu::MUNTE || tip2 == TipMediu::MUNTE)
        r.tip = TipSine::TUNEL;
    else if (tip1 == TipMediu::APA || tip2 == TipMediu::APA)
        r.tip = TipSine::POD;
    else r.tip = TipSine::NORMALE;
    // sina asta merge de aici pana aici(din mijl pana in mijl):
    r.start = poz1;
    r.end = poz2;
    rails.push_back(r);
    // de urmatorul element: next/children ma ocup abia in mom in care chiar adaug sinele
}

void Tema2::CreeazaSinaNormala(Rail& r) {
    // sina normala = paralelipiped simplu gri
    // ma fol de shader ul meu din lab, creat in init:
    Shader* sh = shaders["LabShader"];
    glUseProgram(sh->program);

    GLint locatieUse;
    locatieUse = glGetUniformLocation(sh->program, "folColor");
    glUniform1i(locatieUse, 1); // vreau sa foloseasca culoarea

    GLint locatieColor;
    locatieColor = glGetUniformLocation(sh->program, "u_color");
    glUniform3f(locatieColor, 0.15f, 0.15f, 0.15f); // ii trimit culoarea gri inchis

    glm::vec3 poz;
    poz = (r.start + r.end) / 2.0f; // vreau camijlocul sinei sa fie pus in centrul dintre start si end
    float lg, lat, h;
    lg = DimPatrat;
    lat = 0.5f;
    h = 0.1f;
    glm::mat4 modelMatrix = glm::mat4(1);
    modelMatrix = glm::translate(modelMatrix, poz);
    // cazurile(cum asez sina):
    if (r.orientare == OrientareSine::ORIZ)
        modelMatrix = glm::scale(modelMatrix, glm::vec3(lg, h, lat));
    else modelMatrix = glm::scale(modelMatrix, glm::vec3(lat, h, lg));
    RenderSimpleMesh(meshes["box"], sh, modelMatrix);
    glUniform1i(locatieUse, 0); // revin la default pentru urmatoarele
}

void Tema2::CreeazaSinaPod(Rail& r) {
    // pod = dungi gri/ albe longitudinal
    Shader* sh = shaders["LabShader"];
    glUseProgram(sh->program);

    GLint locatieUse;
    locatieUse = glGetUniformLocation(sh->program, "folColor");
    glUniform1i(locatieUse, 1);

    GLint locatieColor;
    locatieColor = glGetUniformLocation(sh->program, "u_color");
    // am pregatit locatia sa trimit culoarea, dar asta o sa fac pe rand, pt ca sunt 2 culori

    glm::vec3 poz;
    poz = (r.start + r.end) / 2.0f; // unde ii dau translate, in rest doar dimensiunile ma interes.
    float lg, lat, h, bucata;
    lg = DimPatrat;
    lat = 0.5f; // latimea totala
    h = 0.1f;
    bucata = lat / 5.0f; // ce latime ar trebui sa aiba fiecare din cele 5 bucati (impart egal)

    for (int i = 0; i <= 4; i++) { // parcurg toate cele 5 segmente: ce e par e gri
        if (i % 2 == 0)
            glUniform3f(locatieColor, 0.25f, 0.25f, 0.25f); // ii trimit gri
        else glUniform3f(locatieColor, 0.9f, 0.9f, 0.9f); // alb
        // imi fac o variabila care sa mi zica cu cat sa ma misc fata de centru in functie de bucata la care sunt:
        float misca;
        misca = (i - 2) * bucata; // scad 2, 1, 0 bucati, sau adaug 1, 2
        glm::mat4 modelMatrix = glm::mat4(1); // elementul curent, voi avea 5 matrici
        modelMatrix = glm::translate(modelMatrix, poz); // prima oara o pun in centru
        // dupa ma intereseaza in functie de orientare daca o mut cu dimensiunea "misca" pe x sau pe z
        if (r.orientare == OrientareSine::ORIZ) {
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0, misca));
            modelMatrix = glm::scale(modelMatrix, glm::vec3(lg, h, bucata));
        }
        else {
            modelMatrix = glm::translate(modelMatrix, glm::vec3(misca, 0, 0));
            modelMatrix = glm::scale(modelMatrix, glm::vec3(bucata, h, lg));
        }
        RenderSimpleMesh(meshes["box"], sh, modelMatrix);
    }
    glUniform1i(locatieUse, 0);
}

void Tema2::CreeazaSinaTunel(Rail& r) {
    // e efectiv CreeazaSinaPod copiata, modif doar unde e cazul
    // tunel = dungi gri/ albe transversal: aici voi pune 5 gen gri, alb, gri, alb, gri
    Shader* sh = shaders["LabShader"];
    glUseProgram(sh->program);

    GLint locatieUse;
    locatieUse = glGetUniformLocation(sh->program, "folColor");
    glUniform1i(locatieUse, 1);

    GLint locatieColor;
    locatieColor = glGetUniformLocation(sh->program, "u_color");
    // am pregatit locatia sa trimit culoarea, dar asta o sa fac pe rand, pt ca sunt 2 culori

    glm::vec3 poz;
    poz = (r.start + r.end) / 2.0f; // unde ii dau translate, in rest doar dimensiunile ma interes.
    float lg, lat, h, bucata;
    lg = DimPatrat;
    lat = 0.5f; // latimea totala
    h = 0.1f;
    bucata = lg / 5.0f; // ce latime ar trebui sa aiba fiecare din cele 5 bucati (impart egal)

    for (int i = 0; i <= 4; i++) { // parcurg toate cele 5 segmente: ce e par e gri
        if (i % 2 == 0)
            glUniform3f(locatieColor, 0.25f, 0.25f, 0.25f); // ii trimit gri
        else glUniform3f(locatieColor, 0.9f, 0.9f, 0.9f); // alb
        // imi fac o variabila care sa mi zica cu cat sa ma misc fata de centru in functie de bucata la care sunt:
        float misca;
        misca = (i - 2) * bucata; // scad 2, 1, 0 bucati, sau adaug 1, 2
        glm::mat4 modelMatrix = glm::mat4(1); // elementul curent, voi avea 5 matrici
        modelMatrix = glm::translate(modelMatrix, poz); // prima oara o pun in centru
        // dupa ma intereseaza in functie de orientare daca o mut cu dimensiunea "misca" pe x sau pe z
        if (r.orientare == OrientareSine::ORIZ) {
            modelMatrix = glm::translate(modelMatrix, glm::vec3(misca, 0, 0));
            modelMatrix = glm::scale(modelMatrix, glm::vec3(bucata, h, lat));
        }
        else {
            modelMatrix = glm::translate(modelMatrix, glm::vec3(0, 0, misca));
            modelMatrix = glm::scale(modelMatrix, glm::vec3(lat, h, bucata));
        }
        RenderSimpleMesh(meshes["box"], sh, modelMatrix);
    }
    glUniform1i(locatieUse, 0);
}

void Tema2::DeseneazaSine(Rail& r) {
    if (r.tip == TipSine::NORMALE)
        CreeazaSinaNormala(r);
    else if (r.tip == TipSine::POD)
        CreeazaSinaPod(r);
    else if (r.tip == TipSine::TUNEL)
        CreeazaSinaTunel(r);
}

bool Tema2::continua(glm::vec3& a, glm::vec3& b) {
    // cu functia asta verific daca doua sine sunt vecine, se continua, ca sa pot
    // initializa variabilele next/children
    float dif;
    dif = 0.01f;
    // modul = fabs!!!
    if (fabs(a.x - b.x) < dif && fabs(a.y - b.y) < dif && fabs(a.z - b.z) < dif)
        return true;
    return false;
}

void Tema2::AdaugaDublu(int l1, int l2, int c1, int c2) {
    // ca sa nu adaug mereu in dublu sens, apelez direct o functie care sa mi puna ambele 
    // reprezentari in vector
    AdaugaSina(l1, l2, c1, c2);
    AdaugaSina(l2, l1, c2, c1);
}

void Tema2::GestioneazaLegaturi() {
    // functia asta o sa stea sa imi faca toate legaturile dupa ce am adaugat eu in vector tot ce imi trebuie
    // sta sa vada care e diferenta intre next si children, le gestioneaza in parte, cauta care vecini exista
    // ATENTIE!!!!: eu am AdaugaDublu => exista mereu sina inversa
    // deci nu e intersectie daca am 2 vecini si unul e inversul, aia e doar continuare normala
    // mai intai ma asigur ca nu am nicio valoare legata de vecini in niciun element de tipul structurii rail:
    // refac toate legaturile dintre sine

    for (auto& r : rails) {
        r.next = -1;
        r.children.clear();
    }
    for (int i = 0; i < (int)rails.size(); i++) {
        std::vector<int> vecini;
        // adun toti vecinii sinei retinute pe poz i:
        for (int j = 0; j < (int)rails.size(); j++)
            // vecin = incepe fix unde se termina asta
            if (i != j && continua(rails[i].end, rails[j].start) == true)
                vecini.push_back(j);
        // sincer, nu cred ca intra vreodata aici, dar de control:
        if (vecini.size() == 0) {
            rails[i].next = -1;
            rails[i].children.clear();
            continue;
        }
        // scot inversul, ca ala nu inseamna intersectie
        int inv = CautaInvers(i);
        if (inv != -1) // sterg inv din lista vecinilor
            for (int k = 0; k < (int)vecini.size(); k++)
                if (vecini[k] == inv) {
                    vecini.erase(vecini.begin() + k);
                    break;
                }
        // dupa ce am scos inversul, am cazuri:
        // 0 vecini => e capat(doar inapoi exista), deci ma intorc automat
        // 1 vecin => continuare normala
        // peste 2 vecini =>  am intersectie reala
        if (vecini.size() == 0) {
            rails[i].next = -1;
            rails[i].children.clear();
        }
        else if (vecini.size() == 1) {
            rails[i].next = vecini[0];
            rails[i].children.clear();
        }
        else {
            rails[i].next = -1;
            rails[i].children = vecini;
        }
    }
}

// mesh ul pentru cilindru il fac eu de la 0:
Mesh* Tema2::CreeazaMeshCilindru(const std::string& nume, float r, float h) {
    std::vector<VertexFormat> vertecsi;
    std::vector<unsigned int> indecsi;
    float yJos, ySus; // imi calc coord pe y in functie de h
    yJos = -h / 2.0f;
    ySus = h / 2.0f;
    // creez cercurile de sus si jos
    for (int i = 0; i <= 99; i++) {
        float a = 2.0f * (float)M_PI * (float)i / 100.0;
        float x = r * cos(a);
        float z = r * sin(a);
        // nici nu ma intereseaza culoarea sau normala, le las default:
        // adaug pas cu pas fiecare punct de pe ambele cercuri
        vertecsi.push_back(VertexFormat(glm::vec3(x, yJos, z)));
        vertecsi.push_back(VertexFormat(glm::vec3(x, ySus, z)));
    }
    for (int i = 0; i <= 99; i++) {
        int j = (i + 1) % 100;
        int jos0 = 2 * i;
        int sus0 = jos0 + 1;
        int jos1 = 2 * j;
        int sus1 = jos1 + 1;

        indecsi.push_back(jos0);
        indecsi.push_back(sus0);
        indecsi.push_back(sus1);

        indecsi.push_back(jos0);
        indecsi.push_back(sus1);
        indecsi.push_back(jos1);
    }
    // pana aici am facut marginea, inele lipite unul de altul
    // urmeaza capacele:
    int cJos, cSus;
    cJos = vertecsi.size();
    vertecsi.push_back(VertexFormat(glm::vec3(0, yJos, 0), glm::vec3(0), glm::vec3(0, -1, 0)));
    cSus = vertecsi.size();
    vertecsi.push_back(VertexFormat(glm::vec3(0, ySus, 0), glm::vec3(0), glm::vec3(0, 1, 0)));
    for (int i = 0; i <= 99; i++) {
        int i0 = 2 * i;
        int i2 = 2 * ((i + 1) % 100);
        // capac jos: am normala in jos
        indecsi.push_back(cJos);
        indecsi.push_back(i2);
        indecsi.push_back(i0);

        int i1 = 2 * i + 1;
        int i3 = 2 * ((i + 1) % 100) + 1;
        // capac sus
        indecsi.push_back(cSus);
        indecsi.push_back(i1);
        indecsi.push_back(i3);
    }
    return CreateMesh(nume.c_str(), vertecsi, indecsi);
}

void Tema2::DeseneazaLocomotiva(glm::vec3 pos, float gradeY)
{
    // folosesc shader ul meu simplu cu u_color
    Shader* sh = shaders["LabShader"];
    glUseProgram(sh->program);

    // mereu randam cu culoare setata din cod
    GLint locatieUse;
    locatieUse = glGetUniformLocation(sh->program, "folColor");
    glUniform1i(locatieUse, 1);
    GLint locatieColor;
    locatieColor = glGetUniformLocation(sh->program, "u_color");

    // dimensiuni(reglaje ale modelului calculate de mine, ca sa arate ok pe sine)
    float lung = 2.20f;
    float lat = 0.75f;
    float hBaza = 0.08f;
    float rRoata = 0.17f;
    float grosRoata = 0.06f;
    float ecart = 0.23f; // cat spatiu sa am intre rotile din stanga si din dreapta
    float cabX = 0.70f;
    float cabY = 0.65f;
    float cabZ = 0.55f;
    float rCazan = 0.28f; // cilindrul din fata
    // sina e un box cu h = 0.1 si pos.y e la nivelul sinelor(cum am in UpdateTrain)
    // de aia pun roata deasupra sinei, sa nu intre in ea
    float ySusSina = pos.y + 0.1f;
    float yRoata = ySusSina + rRoata;
    // baza locomotivei sta deasupra rotilor(2 raze)
    float yBaza = ySusSina + 2.0f * rRoata + hBaza * 0.5f;
    // cabina e pe spate(negativ pe axa x)
    float xCabina = -lung * 0.5f + cabX * 0.5f;
    float yCabina = (yBaza + hBaza * 0.5f) + cabY * 0.5f;

    // cilindrul din fata: il pun intre cabina si botul bazei
    float xBotBaza = lung * 0.5f;
    float xBotCab = xCabina + cabX * 0.5f;
    float lungCazan = xBotBaza - xBotCab;
    if (lungCazan < 0.2f)
        lungCazan = 0.2f;
    float xCazan = xBotCab + lungCazan * 0.5f;
    float yCazan = (yBaza + hBaza * 0.5f) + rCazan;
    // pregatesc matricea ca sa stiu unde si in ce sens se afla locomotiva
    glm::mat4 M = glm::mat4(1);
    M = glm::translate(M, glm::vec3(pos.x, 0.0f, pos.z));
    M = glm::rotate(M, gradeY, glm::vec3(0, 1, 0));
    // apoi desenez toate partile cu ce am calculat:
    // baza: paralelipiped galben
    glUniform3f(locatieColor, 1.0f, 0.85f, 0.2f);
    {
        glm::mat4 A = M;
        A = glm::translate(A, glm::vec3(0, yBaza, 0));
        A = glm::scale(A, glm::vec3(lung, hBaza, lat));
        RenderSimpleMesh(meshes["box"], sh, A);
    }
    // cabina: box verde, pe spatele bazei
    glUniform3f(locatieColor, 0.12f, 0.55f, 0.12f);
    {
        glm::mat4 A = M;
        A = glm::translate(A, glm::vec3(xCabina, yCabina, 0));
        A = glm::scale(A, glm::vec3(cabX, cabY, cabZ));
        RenderSimpleMesh(meshes["box"], sh, A);
    }

    // cazanul= cilindru albastru, rotit ca sa fie pus pe lungime
    glUniform3f(locatieColor, 0.05f, 0.12f, 0.55f);
    {
        glm::mat4 A = M;
        A = glm::translate(A, glm::vec3(xCazan, yCazan, 0));
        // cilindrul meu e pe axa Y (din mesh), deci il culc pe X
        A = glm::rotate(A, RADIANS(90.0f), glm::vec3(0, 0, 1));
        A = glm::scale(A, glm::vec3(rCazan, lungCazan, rCazan)); // lungcazan e deja full, nu half
        RenderSimpleMesh(meshes["cil"], sh, A);
    }
    // rotile: la locom. am 7 perechi. sunt rosii:
    glUniform3f(locatieColor, 0.9f, 0.1f, 0.1f);
    {
        // le distribui pe lungimea bazei, dar las un mic offset la capete sa nu iasa din locomotiva!!
        float xStart = -lung * 0.5f + 0.25f;
        float pas = (lung - 0.5f) / 6.0f; // 7 roti inseamna 6 intervale
        for (int i = 0; i <= 6; i++) {
            // la fiecare pas vad unde vine pusa roata crt.
            float x = xStart + i * pas;
            // roata stanga:
            glm::mat4 A = M;
            A = glm::translate(A, glm::vec3(x, yRoata, -ecart));
            // roata e in plan xz, deci rotesc cilindrul ca sa arate ca o roata
            A = glm::rotate(A, RADIANS(90.0f), glm::vec3(1, 0, 0));
            A = glm::scale(A, glm::vec3(rRoata, grosRoata, rRoata));
            RenderSimpleMesh(meshes["cil"], sh, A);

            // roata dreapta  e cam aceeasi transformare, doar semnul pe Z e opus
            A = M;
            A = glm::translate(A, glm::vec3(x, yRoata, ecart));
            A = glm::rotate(A, RADIANS(90.0f), glm::vec3(1, 0, 0));
            A = glm::scale(A, glm::vec3(rRoata, grosRoata, rRoata));
            RenderSimpleMesh(meshes["cil"], sh, A);
        }
    }
    glUniform1i(locatieUse, 0);
}

void Tema2::DeseneazaVagon(glm::vec3 pos, float gradeY) {
    Shader* sh = shaders["LabShader"];
    glUseProgram(sh->program);

    GLint locatieUse;
    locatieUse = glGetUniformLocation(sh->program, "folColor");
    glUniform1i(locatieUse, 1);

    GLint locatieColor;
    locatieColor = glGetUniformLocation(sh->program, "u_color");

    float lung = 1.85f;
    float lat = 0.75f;
    float hBaza = 0.08f;
    float rRoata = 0.17f;
    float grosRoata = 0.06f;
    float ecart = 0.23f;
    float hSina = 0.10f;
    float ySusSina = pos.y + hSina;
    float yRoata = ySusSina + rRoata;
    // baza sta deasupra rotilor(2 raze), exact ca la locomotiva
    float yBaza = ySusSina + 2.0f * rRoata + hBaza * 0.5f;
    // corpul e un box mai mic pus peste baza
    float corpY = 0.55f;
    float yCorp = (yBaza + hBaza * 0.5f) + corpY * 0.5f;
    // distanta in spatele locomotivei:
    float lungLoco = 2.20f;
    float gap = 0.22f; // mi o setez eu, ca sa stea mereu una dupa alta la o mica dist.
    float d = (lungLoco * 0.5f) + gap + (lung * 0.5f);

    // vagonul e in spatele locomotivei pe axa x, deci dupa rotatie il mut cu -d pe x
    glm::mat4 M = glm::mat4(1);
    M = glm::translate(M, glm::vec3(pos.x, 0.0f, pos.z));
    M = glm::rotate(M, gradeY, glm::vec3(0, 1, 0));
    M = glm::translate(M, glm::vec3(-d, 0.0f, 0.0f));
    // baza:
    glUniform3f(locatieColor, 1.0f, 0.85f, 0.2f);
    {
        glm::mat4 A = M;
        A = glm::translate(A, glm::vec3(0, yBaza, 0));
        A = glm::scale(A, glm::vec3(lung, hBaza, lat));
        RenderSimpleMesh(meshes["box"], sh, A);
    }

    // corp: e un box verde, putin mai ingust pe z ca sa arate mai clean
    glUniform3f(locatieColor, 0.12f, 0.55f, 0.12f);
    {
        glm::mat4 A = M;
        A = glm::translate(A, glm::vec3(0, yCorp, 0));
        A = glm::scale(A, glm::vec3(lung, corpY, lat * 0.92f));
        RenderSimpleMesh(meshes["box"], sh, A);
    }

    // rotile: doar 2 perechi( una spate si una fata), ca e vagon simplu
    glUniform3f(locatieColor, 0.9f, 0.1f, 0.1f);
    {
        float xSpate = -lung * 0.5f + 0.30f;
        float xFata = lung * 0.5f - 0.30f;
        // perechea din spate: (ambele)
        glm::mat4 A = M;
        A = glm::translate(A, glm::vec3(xSpate, yRoata, -ecart));
        A = glm::rotate(A, RADIANS(90.0f), glm::vec3(1, 0, 0));
        A = glm::scale(A, glm::vec3(rRoata, grosRoata, rRoata));
        RenderSimpleMesh(meshes["cil"], sh, A);

        A = M;
        A = glm::translate(A, glm::vec3(xSpate, yRoata, ecart));
        A = glm::rotate(A, RADIANS(90.0f), glm::vec3(1, 0, 0));
        A = glm::scale(A, glm::vec3(rRoata, grosRoata, rRoata));
        RenderSimpleMesh(meshes["cil"], sh, A);

        // si perechea din fata
        A = M;
        A = glm::translate(A, glm::vec3(xFata, yRoata, -ecart));
        A = glm::rotate(A, RADIANS(90.0f), glm::vec3(1, 0, 0));
        A = glm::scale(A, glm::vec3(rRoata, grosRoata, rRoata));
        RenderSimpleMesh(meshes["cil"], sh, A);

        A = M;
        A = glm::translate(A, glm::vec3(xFata, yRoata, ecart));
        A = glm::rotate(A, RADIANS(90.0f), glm::vec3(1, 0, 0));
        A = glm::scale(A, glm::vec3(rRoata, grosRoata, rRoata));
        RenderSimpleMesh(meshes["cil"], sh, A);
    }
    glUniform1i(locatieUse, 0);
}

float Tema2::LungimeSina(int id) {
    glm::vec3 a, b;
    a = rails[id].start;
    b = rails[id].end;
    float len;
    // exista functia de distance care imi da direct dist intre 2 poz
    len = glm::distance(a, b);
    if (len < 0.01f)
        len = 1.0f;
    return len;
}

glm::vec3 Tema2::DirectieSina(int id) {
    glm::vec3 a, b;
    a = rails[id].start;
    b = rails[id].end;
    glm::vec3 d = b - a;
    float len;
    len = glm::distance(a, b);
    if (len < 0.01f)
        return glm::vec3(1, 0, 0);
    return d / len;
}

// imi da toate sinele care pleaca din capatul segmentului curent, vecinii
// dar ignor segmentul inapoi(inversul celui curent)
std::vector<int> Tema2::IesiriDinNod(int crt) { // crt e indexul curent
    // culeg din toti vecinii doar ce nu e invers
    std::vector<int> v;
    int inv;
    inv = CautaInvers(crt); // asta imi intoarce inversul
    glm::vec3 nod;
    nod = rails[crt].end;
    for (int j = 0; j < (int)rails.size(); j++)
        if (continua(nod, rails[j].start) == true && j != inv) // end ul curent se leaga de start ul de la index j
            v.push_back(j);
    return v;
}

// hotarasc, in functie de sina de pozitia de start si pozitia de end a sinei curente,
// in ce parte sa orientez trenul. functia imi va zice: roteste trenul cu cate grade am ret eu, in jurul axei y
float Tema2::CalculeazaGrade(glm::vec3 start, glm::vec3 end) {
    float dif;
    dif = 0.01f; // o setez mica, pt ca poate nu mi da mereu 0 diferenta
    float dx, dz; // distantele calc intre start si end
    dx = end.x - start.x;
    dz = end.z - start.z;
    // pe x:
    if (fabs(dx) > fabs(dz)) {
        if (dx > dif)
            return RADIANS(0.0f); // x
        if (dx < -dif)
            return RADIANS(180.0f); // -x
    }

    // acum pe z:
    if (fabs(dz) > fabs(dx)) {
        if (dz > dif)
            return RADIANS(-90.0f); // z
        if (dz < -dif)
            return RADIANS(90.0f); //-z
    }
    return RADIANS(0.0f);
}

int Tema2::CautaInvers(int crt) {
    // eu am AdaugaDublu, deci ar trebui sa existe mereu inversul
    glm::vec3 a, b;
    a = rails[crt].start;
    b = rails[crt].end;
    for (int i = 0; i < (int)rails.size(); i++)
        if (i != crt && continua(rails[i].start, b) == true && continua(rails[i].end, a) == true) // e fix pe dos => inversa
            return i;
    return -1;
}

int Tema2::AlegeCopilWASD(int key)
{
    if (train.indexRail < 0)
        return -1;

    // iau iesirile reale din nod(fara inapoi)
    std::vector<int> iesiri = IesiriDinNod(train.indexRail);
    if (iesiri.size() < 2)
        return -1;
    int vX = 0, vZ = 0;
    if (key == GLFW_KEY_W)
        vZ = -1;
    if (key == GLFW_KEY_S)
        vZ = 1;
    if (key == GLFW_KEY_A)
        vX = -1;
    if (key == GLFW_KEY_D)
        vX = 1;
    if (vX == 0 && vZ == 0)
        return -1;
    float dif = 0.01f;
    for (int idx : iesiri) {
        glm::vec3 s = rails[idx].start;
        glm::vec3 e = rails[idx].end;
        float dx = e.x - s.x;
        float dz = e.z - s.z;
        // vad iar in ce directie e vecinul pe care merg, ca sa aleg index ul celui care e in directia aleasa
        if (vX != 0 && fabs(dx) > fabs(dz) && fabs(dx) > dif) {
            if (vX == 1 && dx > dif)
                return idx;
            if (vX == -1 && dx < -dif)
                return idx;
        }
        if (vZ != 0 && fabs(dz) > fabs(dx) && fabs(dz) > dif) {
            if (vZ == 1 && dz > dif)
                return idx;
            if (vZ == -1 && dz < -dif)
                return idx;
        }
    }
    return -1;
}

void Tema2::InitTrain() {
    // iau gara centrala(e prima din vector)
    glm::vec3 gara = vectGari[0].poz;
    // ideea de baza:
    // vreau ca trenul sa stea in dreapta garii centrale, pe o sina care merge spre x in sens poz,
    // fara sa se inters cu gara(nici locomotiva, nici vagonul): tot calcule..
    float halfGara = 0.5f * 1.5f; // gara centrala e box scalat 1.5
    float gapGara = 0.2f; // un mic spatiu intre gara si tren, ca sa nu fie lipite
    // dimensiuni din desenele mele(aceleasi ca in locomotiva/vagon)
    float halfLoco = L_loco / 2.0f; // jumatate din locomotiva pe lungime
    float lungVagon = 1.85f;
    float halfVagon = lungVagon / 2.0f;
    float gapCuplaj = 0.22f; // distanta dintre locom si vagon (cum am folosit in vagon)
    // distanta dintre centrul locomotivei si centrul vagonului
    float distLocoVagon = halfLoco + gapCuplaj + halfVagon;
    // cat e fundul trenului in spate fata de centrul locomotivei(mijl loco):
    // (centrul loco -> centrul vagon) + (centrul vagon -> spatele vagonului)
    float distLocoLaCoada = distLocoVagon + halfVagon;
    // cat e trenul total pe directia mersului:
    // (bot loco fata de centru) + (coada trenului fata de centru)
    float distBotLaCoada = halfLoco + distLocoLaCoada;
    // impun ca spatele vagonului(coada) sa fie in dreapta garii
    float coadaX = gara.x + halfGara + gapGara;
    // daca trenul merge spre x in sens poz, atunci botul trebuie sa fie coada + lungimea trenului
    // mai la dreapta, deci adunat
    float botX = coadaX + distBotLaCoada;
    // aleg o sina care merge pe x poz si care e cat mai aproape de gara centrala
    int best = -1;
    float bestScore = 999999.0f;
    for (int i = 0; i < (int)rails.size(); i++) {
        glm::vec3 a = rails[i].start;
        glm::vec3 b = rails[i].end;
        float dx = b.x - a.x;
        float dz = b.z - a.z;
        // vreau doar segm orientate pe x poz
        if (fabs(dx) > fabs(dz) && dx > 0.01f) {
            // scor simplu: cat de aproape e de gara(si fac score ul mai defavorabil dc e pe alta linie z)
            float score;
            score = glm::distance(a, gara) + 0.5f * fabs(a.z - gara.z);
            if (score < bestScore) {
                bestScore = score;
                best = i;
            }
        }
    }

    // initializez starea trenului
    train.indexRail = best; // il asez unde am gasit initial
    train.prevRail = -1;
    train.progress = 0.0f;
    train.pornit = false;
    train.asteaptaAlegere = false;
    // imping botul trenului pe sine, trecand peste segmente, pana ajung la botx dorit
    // aici lucrez cu botul locomotivei:
    while (true) {
        Rail& r = rails[train.indexRail];
        // vreau sa raman doar pe segm care merg pe x in sens poz (de control)
        glm::vec3 dv = r.end - r.start;
        if (fabs(dv.x) <= fabs(dv.z) || dv.x <= 0.01f) // dist pe z sau acelasi segm
            break;
        float len;
        len = LungimeSina(train.indexRail);
        // pozitia botului pe segmentul curent
        glm::vec3 cap = r.start + (r.end - r.start) * train.progress;
        // daca deja am botul suficient de in dreapta, ma opresc
        if (cap.x >= botX - 0.0001f)
            break;
        // cat mai am pana la end-ul segmentului curent
        float distPanaLaEnd = (1.0f - train.progress) * len;
        // cat mai am nevoie sa merg pe x pana la botx
        float needX = botX - cap.x;
        // daca botx e in interiorul segmentului curent, setez progress exact cat trebuie si gata
        if (needX <= distPanaLaEnd + 0.0001f) {
            train.progress += needX / len;
            if (train.progress > 1.0f)
                train.progress = 1.0f;
            break;
        }
        // altfel, consum segmentul complet si trec pe urmatorul
        train.progress = 1.0f;
        int nxt;
        nxt = rails[train.indexRail].next;
        if (nxt == -1)
            break; // daca nu am next nu am unde sa mai merg
        train.prevRail = train.indexRail;
        train.indexRail = nxt;
        train.progress = 0.0f;
    }
    // dupa ce am pus botul unde trebuie, calculez centrul locomotivei
    // (centru = bot - directie * halfLoco)
    {
        Rail& r = rails[train.indexRail];
        glm::vec3 dir = DirectieSina(train.indexRail);
        glm::vec3 cap = r.start + (r.end - r.start) * train.progress;
        train.pozitie = cap - dir * halfLoco;
        train.gradeY = CalculeazaGrade(r.start, r.end);
    }
}

void Tema2::RecalculeazaPozitiaTrenului() {
    // aici tin sincronizat progres cap: pozitie (centrul loco) + rotatie
    // cam calculul pe care l am gandit si in inittrain
    Rail& r = rails[train.indexRail];
    glm::vec3 dir = DirectieSina(train.indexRail);
    glm::vec3 cap = r.start + (r.end - r.start) * train.progress;
    train.pozitie = cap - dir * (L_loco * 0.5f);
    train.gradeY = CalculeazaGrade(r.start, r.end);
}

void Tema2::UpdateTrain(float dt) {
    // daca sunt blocat la intersectie, doar tin trenul unde e
    // tot astept pana se intampla ceva
    if (train.asteaptaAlegere == true) {
        RecalculeazaPozitiaTrenului();
        return;
    }
    // daca trenul nu e pornit, tot doar tin pozitia corecta
    if (train.pornit == false) {
        RecalculeazaPozitiaTrenului();
        return;
    }
    // miscarea o fac pe distanta reala pe sina
    float dist = dt * train.speed * DimPatrat;
    // pot traversa mai multe segmente intr-un singur frame daca dist e mare:
    while (dist > 0.0001f) {
        float len;
        len = LungimeSina(train.indexRail);
        // cat mai am pana la nodul de la capatul segmentului
        float distPanaLaEnd;
        distPanaLaEnd = (1.0f - train.progress) * len;
        // iesiri din nod(fara intoarcerea invers):
        std::vector<int> iesiri = IesiriDinNod(train.indexRail);
        // intersectie reala = am cel putin 2 variante in cont.
        if (iesiri.size() >= 2) {
            // la intersectie vreau sa opresc fix in nod, ca sa aleg cu w, a, s, d
            if (dist >= distPanaLaEnd) {
                train.progress = 1.0f; // capul ajunge in nod
                train.asteaptaAlegere = true; // de aici nu mai misc pana nu aleg
                break;
            }
            // nu ajung in nod inca
            train.progress += dist / len;
            break;
        }
        // daca nu ajung la capatul segmentului, doar avansez pe el
        if (dist < distPanaLaEnd) {
            train.progress += dist / len;
            break;
        }
        // ajung in nodul de la finalul segmentului si mai am distanta de consumat
        train.progress = 1.0f;
        dist -= distPanaLaEnd;
        // daca am o singura iesire, continui automat
        if (iesiri.size() == 1) {
            train.prevRail = train.indexRail;
            train.indexRail = iesiri[0];
            train.progress = 0.0f; // capul il pun pe start ul noii sine
            continue;
        }
        // daca nu am iesire in fata, inseamna capat si ma intorc la 180 de grade
        if (iesiri.size() == 0) {
            int inv = CautaInvers(train.indexRail);
            train.prevRail = train.indexRail;
            train.indexRail = inv;
            train.progress = 0.0f;
            continue;
        }
        // daca am ajuns aici, inseamna ca de fapt sunt in intersectie
        train.asteaptaAlegere = true;
        break;
    }
    // dupa ce am terminat miscarea, refac pozitia centrului si rotatia, in functie de unde am aj
    RecalculeazaPozitiaTrenului();
}

void Tema2::InitResources() {
    resInfo.clear();
    resInfo.resize(3);
    // r1 e sfera:
    resInfo[0].tip = TipResursa::R1;
    resInfo[0].col = glm::vec3(0.2f, 0.7f, 1.0f);
    resInfo[0].mesh = "sphere";
    resInfo[0].scale = 0.35f;

    // ceainicul
    resInfo[1].tip = TipResursa::R2;
    resInfo[1].col = glm::vec3(1.0f, 0.4f, 0.2f);
    resInfo[1].mesh = "teapot";
    resInfo[1].scale = 0.35f;

    // cubul
    resInfo[2].tip = TipResursa::R3;
    resInfo[2].col = glm::vec3(0.8f, 0.2f, 0.9f);
    resInfo[2].mesh = "box";
    resInfo[2].scale = 0.35f;

    // starile garilor ca resurse: vector cu elemente in care retin starea garilor pentru resursele coresp.
    stateGariRes.clear();
    stateGariRes.resize(3);
    stateGariRes[0].tip = TipResursa::R1;
    stateGariRes[1].tip = TipResursa::R2;
    stateGariRes[2].tip = TipResursa::R3;
    // universal: toate sunt disponibile la inc, niciuna nu are timp ramas de cooldown
    for (int i = 0; i <= 2; i++) {
        stateGariRes[i].disponibila = true;
        stateGariRes[i].cooldown = 0.0f;
    }
}

void Tema2::GenereazaComandaNoua() {
    // imi pun in vectorul de comenzi cele 5 resurse, alese random
    comanda.clear();
    for (int i = 0; i <= 4; i++) {
        int r;
        r = rand() % 3; // intre 0 si 2, ca sa fie una din cele 3
        if (r == 0)
            comanda.push_back(TipResursa::R1);
        else if (r == 1)
            comanda.push_back(TipResursa::R2);
        else if (r == 2)
            comanda.push_back(TipResursa::R3);
    }
    timpRamas = timpTotal; // incep scurgerea timpului
    comandaCompleta = false;
}

void Tema2::DeseneazaComanda() {
    if (gameOver == true) // daca am pierdut nu mai am ce desena
        return;
    if (comanda.size() == 0)
        return;
    // pozitie langa gara centrala
    // de unde incep desenarea listei de resurse
    glm::vec3 baza = vectGari[0].poz + glm::vec3(-1.2f, 1.2f, 0.0f); // in stanga usor, deasupra
    // dist intre ele:
    float step;
    step = 0.65f;
    Shader* sh = shaders["LabShader"];
    glUseProgram(sh->program);

    GLint locatieUse;
    locatieUse = glGetUniformLocation(sh->program, "folColor");
    glUniform1i(locatieUse, 1);

    for (int i = 0; i < (int)comanda.size(); i++) {
        int id;
        id = (int)comanda[i]; // R1=0, R2=1, R3=2
        // extrag informatia din vectorul de comenzi, de la index ul actual:
        ResourceInfo& inf = resInfo[id];

        GLint locatieColor;
        locatieColor = glGetUniformLocation(sh->program, "u_color");
        glUniform3f(locatieColor, inf.col.x, inf.col.y, inf.col.z);

        glm::mat4 M = glm::mat4(1);
        glm::vec3 p = baza + glm::vec3(i * step, 0.0f, 0.0f); // fiecare calc in functie de index cu cat ma mut pe x
        M = glm::translate(M, p);
        M = glm::scale(M, glm::vec3(inf.scale));
        RenderSimpleMesh(meshes[inf.mesh], sh, M);
    }
    glUniform1i(locatieUse, 0);
}

glm::vec3 Tema2::CuloareGaraCentralaDinTimp() {
    glm::vec3 baza = vectGari[0].col; // galbenul meu/ baza de la care plec
    glm::vec3 rosu = glm::vec3(1.0f, 0.0f, 0.0f);
    float t;
    t = 0.0f;
    // t e un fel de "procent" de cat mai am pana la rosu
    if (timpTotal > 0.01f)
        t = 1.0f - (timpRamas / timpTotal); // 0 la start, 1 la final
    if (t < 0.0f)
        t = 0.0f;
    if (t > 1.0f)
        t = 1.0f;
    return baza * (1.0f - t) + rosu * t; // procent de cat mai am din rosu + proc de cat mai am din galben
}

Tema2::AABB Tema2::AABBGara(int idGara) {
    // aproximare simpla: box centrat in pozitia garii
    Gara& g = vectGari[idGara];
    // parametri in care trebuie sa intre trenul ca sa consid ca am aj la gara
    float halfXZ = 0.35f * g.scale;
    float halfY = 1.0f * g.scale;
    AABB b;
    b.minv = g.poz - glm::vec3(halfXZ, halfY, halfXZ); // spate, stanga jos
    b.maxv = g.poz + glm::vec3(halfXZ, halfY, halfXZ); // fata, dreapta sus
    return b;
}

Tema2::AABB Tema2::AABBTrain() {
    AABB b;
    glm::vec3 c = train.pozitie + glm::vec3(0.0f, 1.0f, 0.0f); // ridic centrul pe y putin ca sa prinda locomotiva
    b.minv = c - halfTrainAABB;
    b.maxv = c + halfTrainAABB;
    return b;
}

bool Tema2::IntersectAABB(AABB& a, AABB& b) {
    // mai bine iau manual cazurile in care nu se inters.
    if (a.maxv.x < b.minv.x || a.minv.x > b.maxv.x)
        return false;
    if (a.maxv.y < b.minv.y || a.minv.y > b.maxv.y)
        return false;
    if (a.maxv.z < b.minv.z || a.minv.z > b.maxv.z)
        return false;
    return true;
}

void Tema2::IntoarceTrenulPeInvers() {
    // vreau sa intorc pe drumul pe care am venit:
    // daca am prevrail valid, atunci inapoi e inversul lui prevrail, start e end si end e start
    // altfel fac ca inainte pe inversul curentului
    int inv = -1;
    if (train.prevRail != -1)
        inv = CautaInvers(train.prevRail);
    else
        inv = CautaInvers(train.indexRail); // daca e singura sina, inversul e al ei(caz degeaba)
    // pun capul fix in nodul unde intorc(end ul segmentului curent)
    glm::vec3 nod = rails[train.indexRail].end;
    train.prevRail = train.indexRail; // mai intai asta, sa nu l pierd
    train.indexRail = inv;
    // dupa ce schimb segmentul de sina, pun capul exact in nod(progress e iar 0 pe segmentul nou)
    train.progress = 0.0f;
    train.asteaptaAlegere = false;
}
// mereu update ca sa imi treaca cooldown ul cand trebuie, sa pot lua iar resursa!!
void Tema2::UpdateCooldownGari(float dt) {
    for (int i = 0; i <= 2; i++)
        if (stateGariRes[i].disponibila == false) {
            stateGariRes[i].cooldown -= dt; // scad cu cat a trecut
            // cat nu a primit cooldown, pot sa iau, cooldow e 0
            if (stateGariRes[i].cooldown <= 0.0f) {
                stateGariRes[i].cooldown = 0.0f;
                stateGariRes[i].disponibila = true;
            }
        }
}

void Tema2::VerificaColiziuniStatii(float dt)
{
    // ideea e ca vreau sa declansez logica de statie o singura data cand intru in box,
    // nu in fiecare frame cat timp stau in ea(altfel se intoarce 180 la infinit)
    AABB tren = AABBTrain(); // box ul aabb in care e trenul
    int statie = -1;
    for (int i = 0; i <= 3; i++) // iau toate garile pe rand sa vad daca am inters cu vreuna
        if (IntersectAABB(tren, AABBGara(i)) != false) {
            statie = i;
            break;
        }
    // daca nu mai sunt in nicio statie, rearmez sistemul
    // asta imi permite ca data viitoare cand intru sa se declanseze iar
    if (statie == -1) {
        eramInStatie = false;
        statieCurenta = -1;
        return;
    }
    // daca sunt in aceeasi statie ca frame ul trecut, nu fac nimic
    // practic asta e un fel de trigger la inceput: actionez doar la intrare, nu cat stau inauntru
    if (eramInStatie == true && statieCurenta == statie)
        return;
    // aici inseamna ca am intrat acum intr-o statie noua
    eramInStatie = true;
    statieCurenta = statie;
    // daca am terminat comanda, singura statie care conteaza e gara centrala
    // doar acolo fac sa primesc o comanda noua
    if (comanda.size() == 0) {
        comandaCompleta = true;
        if (statie == 0) {
            GenereazaComandaNoua();
            // dupa livrare vreau sa se intoarca pe unde a venit
            IntoarceTrenulPeInvers();
            // reset manual aici ca sa nu ramana fixata starea in cazul in care trenul sta fix in cutie
            eramInStatie = false;
            statieCurenta = -1;
        }
        return;
    }
    // daca am ajuns la gara centrala dar comanda nu e completa, nu fac nimic
    if (statie == 0) // nu mai am cazul favorabil, l am luat mai devreme
        return;
    // aici stiu sigur ca e una din statiile de resurse
    GaraResursaState& info = stateGariRes[statie - 1];
    // iau resursa doar daca statia e disponibila (adica nu e in cooldown)
    if (info.disponibila == true) {
        for (int i = 0; i <= comanda.size() - 1; i++) {
            if (comanda[i] == info.tip) {
                // am gasit o aparitie in comanda, o consum
                // nu am mai stat sa fac si chestia cu ordinea, desi era mai usor
                comanda.erase(comanda.begin() + i);
                // pun statia pe cooldown ca sa nu mai pot lua prea curand vreo resursa
                info.disponibila = false;
                info.cooldown = 5.0f;
                break;
            }
        }
    }
    // indiferent daca a fost buna sau nu resursa, trenul se intoarce la 180 si pleaca inapoi
    // asa am ales eu
    IntoarceTrenulPeInvers();
}

/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Tema2::OnInputUpdate(float deltaTime, int mods)
{
    // Add key press event
}


void Tema2::OnKeyPress(int key, int mods)
{
    // Add key press event
    // space = pornesc/ opresc trenul
    if (key == GLFW_KEY_SPACE) {
        train.pornit = !train.pornit;
        return;
    }
    if (key == GLFW_KEY_R) {
        // setez toate val ca sa o pot lua efectiv de la capat
        gameOver = false;
        GenereazaComandaNoua();
        InitTrain();
        train.pornit = false;
        return;
    }
    // daca sunt la intersectie, aleg cu WASD
    if (train.asteaptaAlegere == true) {
        int ales;
        ales = AlegeCopilWASD(key); // asta imi zice care e id ul din vector al sinei pe care trebuie sa o iau
        if (ales != -1) {
            train.prevRail = train.indexRail;
            train.indexRail = ales; // continui pe id ul ales
            // pornesc de pe start ul noului segment(capul exact in nod)
            train.progress = 0.0f;
            train.asteaptaAlegere = false;
        }
    }
}


void Tema2::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event
}


void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
}


void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Tema2::OnWindowResize(int width, int height)
{
    float aspect;
    aspect = (float)width / (float)height;
    projectionMatrix = glm::perspective(RADIANS(60.0f), aspect, 0.01f, 200.0f); // o resetez in functie de dim ferestrei
}
