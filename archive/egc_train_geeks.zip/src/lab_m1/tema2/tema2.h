#pragma once

#include <vector>

#include "components/simple_scene.h"


namespace m1
{
    class Tema2 : public gfxc::SimpleScene
    {
     public:
        Tema2();
        ~Tema2();

        void Init() override;

        Mesh *CreateMesh(const char *name, const std::vector<VertexFormat> &vertices, const std::vector<unsigned int> &indices);

     private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix);

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;
        // variabile specifice temei 2:
        // un enum prin care specific ce tip de mediu am in fiecare casuta(cum am fct si in tema 1):
        enum class TipMediu {
            CAMPIE,
            APA,
            MUNTE
        };
        void CreeazaMeshMediu(int linii, int col, float size);
        glm::vec3 CuloareMediu(TipMediu tip); //ii zic tip si imi ret culoarea care ii coresp.
        TipMediu AlegeMediu(int l, int c); // imi aleg inauntru indicii intre care vreau fiecare tip de mediu
        // parametri mediu efectiv, cate patrate vreau pe linie/ coloana
        int LiniiMediu = 23, ColoaneMediu = 23;
        float DimPatrat = 1.0f;
        glm::mat4 projectionMatrix;
        // toate tipurile care imi trebuie pentru gari:
        enum class TipGara { // o gara principala, 3 secundare
            PRINC,
            SEC1,
            SEC2,
            SEC3
        };
        struct Gara {
            TipGara tip;
            glm::vec3 poz;
            glm::vec3 col;
            float scale = 1.0f;
            std::string mesh; // ce tip de mesh e, retinut ca un cuvant
        };
        std::vector<Gara> vectGari;
        glm::vec3 LocGara(int l, int c, float y = 0.1f); // mereu la inaltimea y pun forma, o mai schimb
        // Mesh* CreeazaPiramida(); nu mai fac piramida daca am in meshes 3 deja existente, pun teapot
        // ce mi trebuie pentru sine si tren:
        enum class TipSine {
            NORMALE,
            POD,
            TUNEL
        };
        // in momentul in care pun un segment de sine pe harta e foarte relevant sa stiu daca e st-dr sau sus-jos orientata
        enum class OrientareSine {
            ORIZ, // st-dr
            VERT // sus-jos: e greu:)))
        };
        struct Rail {
            TipSine tip;
            OrientareSine orientare;
            glm::vec3 start;
            glm::vec3 end;
            int next; // iar asta imi zice care e urmatorul segment de sine
            std::vector<int> children; // asta imi zice daca am intersectie sau nu => o pot lua in mai multe dir.
        };
        std::vector<Rail> rails;
        // acelasi lucru ca LocGara:
        glm::vec3 AlegePozSina(int l, int c, float y = 0.0f);
        void AdaugaSina(int l1, int l2, int c1, int c2);
        void CreeazaSinaNormala(Rail& r); // ii trimit un elem din vectorul de rails si il desenez efectiv
        void CreeazaSinaPod(Rail& r);
        void CreeazaSinaTunel(Rail& r);
        void DeseneazaSine(Rail& r);
        void AdaugaDublu(int l1, int l2, int c1, int c2);
        void GestioneazaLegaturi();
        bool continua(glm::vec3& x, glm::vec3& y);
        // tot ce e pentru tren:
        struct Train {
            int indexRail = -1;
            // progress imi zice unde e CAPUL locomotivei pe segment(0 = start, 1 = end)!!
            float progress = 0.0f;
            // viteza in patrate pe secunda
            float speed;
            bool pornit = false;
            bool asteaptaAlegere = false;
            glm::vec3 pozitie = glm::vec3(0); // asta ramane CENTRUL locomotivei - ma ajut de el la desen
            float gradeY = 0.0f; // imi descrie directia pe care e orientat trenul in raport cu axa y
            int prevRail = -1; // tin minte segmentul pe care eram inainte(pt intersectii)
        };
        Train train;
        // lungimea locomotivei
        float L_loco = 2.20f;
        float cap_loco = 1.10f; // jumatate din L_loco(cat e capul fata de centru)
        Mesh* CreeazaMeshCilindru(const std::string& nume, float r, float h);
        void DeseneazaLocomotiva(glm::vec3 pozitie, float gradeY);
        void DeseneazaVagon(glm::vec3 pozitie, float gradeY);
        void InitTrain(); // pun trenul pe o sina initiala(in dreapta garii princ.)
        void UpdateTrain(float dt); // misc trenul automat, cu cazuri in fct de unde sunt
        void RecalculeazaPozitiaTrenului();
        float CalculeazaGrade(glm::vec3 start, glm::vec3 end); // ii trim un segment, descrierea lui, si imi ret ce unghi are pe y segm
        int CautaInvers(int crt); // gasesc segm invers pt intoarcere
        int AlegeCopilWASD(int key); // la intersectie, aleg in functie de w, a, s, d
        // dimensiuni simple pt locomotiva mea(le folosesc la oprire in intersectie)
        float LungimeSina(int id);
        glm::vec3 DirectieSina(int id);
        std::vector<int> IesiriDinNod(int crt);

        // tot ce imi tb pentru logica jocului in sine:
        enum class TipResursa {
            R1 = 0, // sfera
            R2 = 1, // teapot
            R3 = 2 // box
        };
        struct ResourceInfo { // descrierea fiecarui tip de resursa
            TipResursa tip;
            glm::vec3 col;
            std::string mesh;
            float scale;
        };
        // pt intersectii, aabb ca in tema 1, doar ca aici 3d(cuburi)
        struct AABB {
            glm::vec3 minv; // stanga jso spate
            glm::vec3 maxv; // dreapta sus fata
        };
        struct GaraResursaState { // starea garii coresp unei resurse
            TipResursa tip;
            bool disponibila = true;
            float cooldown = 0.0f; // secunde ramase pana regenereaza
        };
        // vector global ce imi contine informatiile
        std::vector<ResourceInfo> resInfo;
        // mapare gara in tip resursa(doar pt cele 3 gari secundare)
        std::vector<GaraResursaState> stateGariRes; // index 1, 2, 3 din vectGari
        std::vector<TipResursa> comanda;
        // timer comanda
        float timpRamas = 60.0f;
        float timpTotal = 60.0f;
        bool gameOver = false;
        bool comandaCompleta = false; // true cand comanda e goala
        // pentru un fel de anti spam la coliziuni (sa nu declanseze de 60 ori pe sec)
        bool eramInStatie = false;
        int statieCurenta = -1;
        // aabb pentru tren(aprox locomotiva)
        glm::vec3 halfTrainAABB = glm::vec3(1.1f, 0.8f, 0.6f);
        void InitResources();
        void GenereazaComandaNoua();
        void DeseneazaComanda();
        // functii pt coliziuni
        AABB AABBGara(int idxGara);
        AABB AABBTrain();
        bool IntersectAABB(AABB& a, AABB& b);
        // logica statii + colectare:
        void UpdateCooldownGari(float dt);
        void VerificaColiziuniStatii(float dt);
        void IntoarceTrenulPeInvers(); // se intoarce la 180
        // pt gara centrala, sa se faca rosieL
        glm::vec3 CuloareGaraCentralaDinTimp();
    };
}   // namespace m1
