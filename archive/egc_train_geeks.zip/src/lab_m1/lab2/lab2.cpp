﻿#include "lab_m1/lab2/lab2.h"

#include <vector>
#include <iostream>

#include "core/engine.h"
#include "utils/gl_utils.h"

using namespace std;
using namespace m1;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Lab2::Lab2()
{
}


Lab2::~Lab2()
{
}

void Lab2::Init()
{
    cullFace = GL_BACK;
    polygonMode = GL_FILL;
    {
        Mesh* mesh = new Mesh("box");
        mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
        meshes[mesh->GetMeshID()] = mesh;
    }

    // cubul generat manual
    {
        std::vector<VertexFormat> vertices{
            // z = +1
            VertexFormat(glm::vec3(-1, -1,  1), glm::vec3(1, 0, 0)), // 0
            VertexFormat(glm::vec3(1, -1,  1), glm::vec3(0, 1, 0)), // 1
            VertexFormat(glm::vec3(-1,  1,  1), glm::vec3(0, 0, 1)), // 2
            VertexFormat(glm::vec3(1,  1,  1), glm::vec3(1, 1, 0)), // 3
            // z = -1
            VertexFormat(glm::vec3(-1, -1, -1), glm::vec3(1, 0, 1)), // 4
            VertexFormat(glm::vec3(1, -1, -1), glm::vec3(0, 1, 1)), // 5
            VertexFormat(glm::vec3(-1,  1, -1), glm::vec3(1, 1, 1)), // 6
            VertexFormat(glm::vec3(1,  1, -1), glm::vec3(1, 0.5f, 0)) // 7
        };

        std::vector<unsigned int> indices{
            // fata(z = +1)
            0, 1, 2,
            1, 3, 2,
            // dreapta(x = +1)
            1, 5, 3,
            5, 7, 3,
            // stanga(x = -1)
            4, 0, 6,
            0, 2, 6,
            // spate(z = -1)
            5, 4, 7,
            4, 6, 7,
            // jos(y = -1)
            4, 5, 0,
            5, 1, 0,
            // sus(y = +1)
            2, 3, 6,
            3, 7, 6
        };

        meshes["cube_A"] = new Mesh("generated cube 1");
        meshes["cube_A"]->InitFromData(vertices, indices);
        CreateMesh("cube_B", vertices, indices); // varianta ceruta (VAO/VBO/IBO)
    }
    // aici am tetraedru:
    {
        std::vector<VertexFormat> tVerts{
            VertexFormat(glm::vec3(0.0f,  1.0f,  0.0f), glm::vec3(1, 0, 0)), // v0
            VertexFormat(glm::vec3(-1.0f, -1.0f,  1.0f), glm::vec3(0, 1, 0)), // v1
            VertexFormat(glm::vec3(1.0f, -1.0f,  1.0f), glm::vec3(0, 0, 1)), // v2
            VertexFormat(glm::vec3(0.0f, -1.0f, -1.2f), glm::vec3(1, 1, 0))  // v3
        };
        std::vector<unsigned int> tIdx{
            0,1,2,   // fata 1
            0,2,3,   // fata 2
            0,3,1,   // fata 3
            1,3,2    // baza
        };
        CreateMesh("tetra", tVerts, tIdx);
    }

    // patrat din 2 triunghiuri
    // cu winding opus:
    {
        float z = 0.0f;
        std::vector<VertexFormat> sVerts{
            VertexFormat(glm::vec3(-1.0f, -1.0f, z), glm::vec3(1, 0, 0)), // 0
            VertexFormat(glm::vec3(1.0f, -1.0f, z), glm::vec3(0, 1, 0)), // 1
            VertexFormat(glm::vec3(1.0f,  1.0f, z), glm::vec3(0, 0, 1)), // 2
            VertexFormat(glm::vec3(-1.0f,  1.0f, z), glm::vec3(1, 1, 0))  // 3
        };
        std::vector<unsigned int> sIdx{
            0, 2, 1,   // CCW
            0, 2, 3    // CW, adica opus f.d primul
        };
        CreateMesh("square_opp", sVerts, sIdx);
    }
}


void Lab2::CreateMesh(const char* name,
    const std::vector<VertexFormat>& vertices,
    const std::vector<unsigned int>& indices)
{
    // VAO:
    unsigned int VAO = 0;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);

    // VBO:
    unsigned int VBO = 0;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER,
        sizeof(VertexFormat) * vertices.size(),
        vertices.data(),
        GL_STATIC_DRAW);

    // IBO/EBO:
    unsigned int IBO = 0;
    glGenBuffers(1, &IBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int) * indices.size(), indices.data(), GL_STATIC_DRAW);

    // layout atribute
    // position (location = 0)
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)0);

    // normal(location = 1): offset dupa pos.
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(sizeof(glm::vec3)));

    // texcoord(location = 2): dupa position + normal
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3)));
    // color(location = 3)
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
    // unbind VAO:
    glBindVertexArray(0);

    // creez Mesh din VAO si nr indici
    meshes[name] = new Mesh(name);
    meshes[name]->InitFromBuffer(VAO, static_cast<unsigned int>(indices.size()));
}

void Lab2::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glm::ivec2 resolution = window->GetResolution();

    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
}


void Lab2::Update(float deltaTimeSeconds)
{
    glLineWidth(3);
    glPointSize(5);
    glPolygonMode(GL_FRONT_AND_BACK, polygonMode);
    glEnable(GL_CULL_FACE);
    glCullFace(cullFace);   // GL_BACK/GL_FRONT => aici schimbarea cu f2

    // box cu culori
    RenderMesh(meshes["box"], shaders["VertexNormal"], glm::vec3(0, 0.5f, -1.5f), glm::vec3(0.75f));

    // cubul generat cu InitFromData
    RenderMesh(meshes["cube_A"], shaders["VertexColor"], glm::vec3(-1.5f, 0.5f, 0.0f), glm::vec3(0.25f));

    // cubul prin VAO/VBO/IBO
    RenderMesh(meshes["cube_B"], shaders["VertexColor"], glm::vec3(1.5f, 0.5f, 0.0f), glm::vec3(0.25f));

    // tertaedru:
    RenderMesh(meshes["tetra"], shaders["VertexColor"], glm::vec3(0.0f, 0.5f, 1.5f), glm::vec3(0.6f));

    RenderMesh(meshes["square_opp"], shaders["VertexColor"], glm::vec3(0.0f, 0.01f, -3.0f), glm::vec3(0.6f));

    // Disable face culling: asa tb:
    glDisable(GL_CULL_FACE);
}



void Lab2::FrameEnd()
{
    DrawCoordinateSystem();
}


/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Lab2::OnInputUpdate(float deltaTime, int mods)
{
}


void Lab2::OnKeyPress(int key, int mods)
{
    // Toggle culling face: GL_BACK <-> GL_FRONT
    if (key == GLFW_KEY_F2)
    {
        cullFace = (cullFace == GL_BACK) ? GL_FRONT : GL_BACK;
    }

    if (key == GLFW_KEY_SPACE)
    {
        switch (polygonMode)
        {
        case GL_POINT: polygonMode = GL_FILL; break;
        case GL_LINE:  polygonMode = GL_POINT; break;
        default:       polygonMode = GL_LINE; break;
        }
    }
}



void Lab2::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Lab2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event
}


void Lab2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
}


void Lab2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Lab2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Lab2::OnWindowResize(int width, int height)
{
}
