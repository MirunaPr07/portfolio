#pragma once

#include "lab_m1/lab1/lab1.h"
#include "lab_m1/lab2/lab2.h"
#include "lab_m1/lab3/lab3.h"
#include "lab_m1/lab3/lab3_vis2D.h"
#include "lab_m1/lab4/lab4.h"
#include "lab_m1/lab5/lab5.h"
#include "lab_m1/lab6/lab6.h"
#include "lab_m1/lab7/lab7.h"
#include "lab_m1/lab8/lab8.h"
#include "lab_m1/lab9/lab9.h"
#include "lab_m1/Tema1/Tema1.h"
#include "lab_m1/Tema2/Tema2.h"
