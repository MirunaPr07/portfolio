﻿#include "lab_m1/tema1/tema1.h"
#include "lab_m1/lab3/object2D.h"
#include "lab_m1/lab3/transform2D.h"
#include <cmath> 
#include <queue>
#include "components/text_renderer.h"


#include <vector>
#include <iostream>

using namespace std;
using namespace m1;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Tema1::Tema1()
{
    // TODO(student): Never forget to initialize class variables!
    clearColor = glm::vec3(0.0f);
    clearPalette = {
        glm::vec3(0.0f, 0.0f, 0.0f),
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        glm::vec3(0.0f, 0.0f, 1.0f),
        glm::vec3(1.0f, 1.0f, 0.0f),
        glm::vec3(0.2f, 0.2f, 0.2f)
    };
    clearIdx = 0;
    objPos = glm::vec3(0.0f, 0.5f, 0.0f);
    objScale = glm::vec3(0.6f);
    moveSpeed = 2.0f;
    meshCycle = { "box", "sphere", "teapot" };
    meshIdx = 0;
    activeMeshId = meshCycle[meshIdx];
    angle = 0.0f;
}


Tema1::~Tema1()
{
}


void Tema1::Init()
{
    // imi setez camera ortografica:
    glm::ivec2 res = window->GetResolution();
    auto camera = GetSceneCamera();
    camera->SetOrthographic(0, (float)res.x, 0, (float)res.y, 0.01f, 400);
    camera->SetPosition(glm::vec3(0, 0, 50));
    camera->SetRotation(glm::vec3(0));
    camera->Update();
    GetCameraInput()->SetActive(false);

    // imi setez culorile pe care le voi folosi in editor:
    colGreen = glm::vec3(0.20f, 0.75f, 0.30f);
    colRed = glm::vec3(0.85f, 0.20f, 0.25f);
    colBlue = glm::vec3(0.20f, 0.45f, 0.95f);
    colOrange = glm::vec3(0.95f, 0.35f, 0.20f);
    colGrey = glm::vec3(0.5f, 0.5f, 0.5f);
    colWhite = glm::vec3(1.0f, 1.0f, 1.0f);

    origTipuri = glm::vec2(80.0f, 230.0f); // asta e originea pt partea din stanga cu elementele

    origMatrice = glm::vec2(res.x - (float) coloane * dimCasute - 350.0f, 100.0f);
    matrice.assign(linii * coloane, Celule{});

    origBara = glm::vec2(res.x - 11 * dimensiune - 500, res.y - 90.0f);
    origStart = glm::vec2(origBara.x + 10 * dimensiune + 10 * gapBara, origBara.y);

    // ce fol in joc efectiv:

    lgCaramida = res.x / 12.0f;
    colRoz1 = glm::vec3(0.85f, 0.3f, 0.5f);
    colRoz2 = glm::vec3(0.9f, 0.45f, 0.65f);
    colRoz3 = glm::vec3(0.95f, 0.6f, 0.75f);
    colRoz4 = glm::vec3(0.98f, 0.75f, 0.85f);
    colRoz5 = glm::vec3(0.99f, 0.88f, 0.9f);
    lgCaramida = (res.x - (colCaramizi - 1) * gapCaramizi) / colCaramizi;

    // mesh-uri efectiv:
    Mesh* chenarRosu = object2D::CreateRectangle("chenarRosu", glm::vec3(0, 0, 0), 1.0f, 1.0f, colRed, false);
    AddMeshToList(chenarRosu);

    Mesh* chenarAlbastru = object2D::CreateRectangle("chenarAlbastru", glm::vec3(0, 0, 0), 1.0f, 1.0f, colBlue, false);
    AddMeshToList(chenarAlbastru);

    Mesh *patratGri = object2D::CreateSquare("patratGri", glm::vec3(0, 0, 0), 1.0f, colGrey, true);
    AddMeshToList(patratGri);

    Mesh *patratVerde = object2D::CreateSquare("patratVerde", glm::vec3(0, 0, 0), 1.0f, colGreen, true);
    AddMeshToList(patratVerde);

    Mesh *patratRosu = object2D::CreateSquare("patratRosu", glm::vec3(0, 0, 0), 1.0f, colRed, true);
    AddMeshToList(patratRosu);

    Mesh *patratAlbastru = object2D::CreateSquare("patratAlbastru", glm::vec3(0, 0, 0), 1.0f, colBlue, true);
    AddMeshToList(patratAlbastru);

    Mesh *patratPortocaliu = object2D::CreateSquare("patratPortocaliu", glm::vec3(0, 0, 0), 1.0f, colOrange, true);
    AddMeshToList(patratPortocaliu);

    Mesh* linieRosie = object2D::CreateRectangle("linieRosie", glm::vec3(0, 0, 0), 1.0f, 0.02f, colRed, true);
    AddMeshToList(linieRosie);

    std::vector<VertexFormat> vTri = {
        VertexFormat(glm::vec3(0, 0, 0), glm::vec3(0, 0, 0)),
        VertexFormat(glm::vec3(1, 0, 0), glm::vec3(0, 0, 0)),
        VertexFormat(glm::vec3(0.5, 1, 0), glm::vec3(0, 0, 0)),
    };
    std::vector<unsigned int> iTri = {0, 1, 2};
    Mesh *triBlack = new Mesh("triBlack");
    triBlack->InitFromData(vTri, iTri);
    AddMeshToList(triBlack);


    std::vector<VertexFormat> vTriF = {
        VertexFormat(glm::vec3(0, 0, 0), glm::vec3(1.0f, 0.85f, 0.1f)),
        VertexFormat(glm::vec3(1, 0, 0), glm::vec3(1.0f, 0.85f, 0.1f)),
        VertexFormat(glm::vec3(0.5, 1, 0), glm::vec3(1.0f, 0.85f, 0.1f)),
    };
    std::vector<unsigned int> iTriF = {0, 1, 2};
    Mesh* triFlame = new Mesh("triFlame");
    triFlame->InitFromData(vTriF, iTriF);
    AddMeshToList(triFlame);

    // mesh uri joc:
    Mesh* caramida1 = object2D::CreateRectangle("caramida1", glm::vec3(0, 0, 0), 1.0f, 1.0f, colRoz1, true);
    AddMeshToList(caramida1);
    Mesh* caramida2 = object2D::CreateRectangle("caramida2", glm::vec3(0, 0, 0), 1.0f, 1.0f, colRoz2, true);
    AddMeshToList(caramida2);
    Mesh* caramida3 = object2D::CreateRectangle("caramida3", glm::vec3(0, 0, 0), 1.0f, 1.0f, colRoz3, true);
    AddMeshToList(caramida3);
    Mesh* caramida4 = object2D::CreateRectangle("caramida4", glm::vec3(0, 0, 0), 1.0f, 1.0f, colRoz4, true);
    AddMeshToList(caramida4);
    Mesh* caramida5 = object2D::CreateRectangle("caramida5", glm::vec3(0, 0, 0), 1.0f, 1.0f, colRoz5, true);
    AddMeshToList(caramida5);

    caramida_crt[0] = "caramida1";
    caramida_crt[1] = "caramida2";
    caramida_crt[2] = "caramida3";
    caramida_crt[3] = "caramida4";
    caramida_crt[4] = "caramida5";
    // un vector cu identificatorii tuturor caramizilor, ca sa imi fie mai usor cand le creez!!!


    textRenderer = new gfxc::TextRenderer(window->props.selfDir, res.x, res.y);
    std::string fontPath = PATH_JOIN(window->props.selfDir, RESOURCE_PATH::FONTS, "Hack-Bold.ttf");
    textRenderer->Load(fontPath, 26);

    // mesh pt bila:
    // ma gandesc sa fac 100 de triunghiuri lipite intr un fan ca sa simulez un cerc cat mai rotund:)
    std::vector<VertexFormat> vBila;
    std::vector<unsigned int> iBila;
    vBila.push_back(VertexFormat(glm::vec3(0, 0, 0), colWhite));
    float unghi;
    for (int i = 0; i <= 99; i++) {
        unghi = i * 2 * M_PI / 99;
        vBila.push_back(VertexFormat(glm::vec3(sin(unghi), cos(unghi), 0), colWhite));
    }
    for (int i = 0; i <= 99; i++) {
        iBila.push_back(0);
        iBila.push_back(i);
        iBila.push_back(i + 1);
    }
    Mesh* bila = new Mesh("bila");
    bila->InitFromData(vBila, iBila);
    AddMeshToList(bila);

    InitCaramizi();

}


void Tema1::FrameStart()
{
}


void Tema1::Update(float deltaTimeSeconds)
{
    glm::ivec2 resolution = window->props.resolution;

    // Sets the clear color for the color buffer

    glClearColor(clearColor.r, clearColor.g, clearColor.b, 1.0f);

    // Clears the color buffer (using the previously set color) and depth buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glDisable(GL_DEPTH_TEST); // aveam probleme aici si nu mi se vedea triunghiul negru!!!

    // Sets the screen area where to draw
    glViewport(0, 0, resolution.x, resolution.y);
    if (game == true) {
        // logica din spatele fizicii bilei:
        if (misca == true) {
            origBila += glm::vec2(vitezaBila.x * deltaTimeSeconds, vitezaBila.y * deltaTimeSeconds);
            // coliziunile cu marginile:
            if (origBila.x + razaBila > resolution.x) {
                origBila.x = resolution.x - razaBila;
                vitezaBila.x = -vitezaBila.x;
            }
            if (origBila.x - razaBila < 0) {
                origBila.x = razaBila;
                vitezaBila.x = -vitezaBila.x;
            }
            if (origBila.y + razaBila > resolution.y) {
                origBila.y = resolution.y - razaBila;
                vitezaBila.y = -vitezaBila.y;
            }
            if (origBila.y + razaBila < rachetaY) {
                lives--;
                misca = false;
                if (lives == 0)
                    game = false;
                else rachetaInceput = false;
            }
            // coliziunile cu racheta:
            for (int i = 0; i <= racheta.size() - 1; i++) {
                if (origBila.x + razaBila >= racheta[i].min.x && origBila.x + razaBila < racheta[i].max.x && origBila.y <= racheta[i].max.y && origBila.y >= racheta[i].min.y) {
                    origBila.x = racheta[i].min.x - razaBila;
                    vitezaBila.x = -vitezaBila.x;
                    vitezaBila.y = -vitezaBila.y;
                    break;
                }
                if (origBila.x - razaBila > racheta[i].min.x && origBila.x - razaBila <= racheta[i].max.x && origBila.y <= racheta[i].max.y && origBila.y >= racheta[i].min.y) {
                    origBila.x = racheta[i].max.x + razaBila;
                    vitezaBila.x = -vitezaBila.x;
                    vitezaBila.y = -vitezaBila.y;
                    break;
                }
                if (origBila.y - razaBila <= racheta[i].max.y && origBila.y - razaBila > racheta[i].min.y && origBila.x >= racheta[i].min.x && origBila.x <= racheta[i].max.x) {
                    origBila.y = racheta[i].max.y + razaBila;
                    //unghi = (y_bila - y_paletă) / (h_paletă / 2)
                    //v_x_bila = viteza_bila * cos(unghi)
                    //v_y_bila = viteza_bila * sin(unghi)
                    float angle;
                    angle = (origBila.x - (rachetaX + rachetaLg / 2.0f)) / (rachetaLg / 2.0f);
                    vitezaBila.x = vitInitBila * sin(angle);
                    vitezaBila.y = vitInitBila * cos(angle);
                    break;
                }
            }
            // coliziunile cu caramizile:
            for (auto& c : caramizi) {
                if (c.hp > 0) {
                    if (origBila.y + razaBila >= c.pos.y && origBila.y + razaBila < c.pos.y + c.latime && origBila.x >= c.pos.x && origBila.x <= c.pos.x + c.lungime) {
                        origBila.y = c.pos.y - razaBila;
                        vitezaBila.y = -vitezaBila.y;
                        score++;
                        c.hp--;
                        if (c.hp == 0) {
                            c.tip = TipCaramida::None;
                            c.shrink = true;
                        }
                        else
                            c.tip = vectTipuri[randCaramizi + 1 - c.hp];
                        break;
                    }
                    if (origBila.y - razaBila <= c.pos.y + c.latime && origBila.y - razaBila > c.pos.y && origBila.x >= c.pos.x && origBila.x <= c.pos.x + c.lungime) {
                        origBila.y = c.pos.y + c.latime + razaBila;
                        vitezaBila.y = -vitezaBila.y;
                        score++;
                        c.hp--;
                        if (c.hp == 0) {
                            c.tip = TipCaramida::None;
                            c.shrink = true;
                        }
                        else
                            c.tip = vectTipuri[randCaramizi + 1 - c.hp];
                        break;
                    }
                    if (origBila.x + razaBila >= c.pos.x && origBila.x + razaBila < c.pos.x + c.lungime && origBila.y >= c.pos.y && origBila.y <= c.pos.y + c.latime) {
                        origBila.x = c.pos.x - razaBila;
                        vitezaBila.x = -vitezaBila.x;
                        score++;
                        c.hp--;
                        if (c.hp == 0) {
                            c.tip = TipCaramida::None;
                            c.shrink = true;
                        }
                        else
                            c.tip = vectTipuri[randCaramizi + 1 - c.hp];
                        break;
                    }
                    if (origBila.x - razaBila <= c.pos.x + c.lungime && origBila.x - razaBila > c.pos.x && origBila.y >= c.pos.y && origBila.y <= c.pos.y + c.latime) {
                        origBila.x = c.pos.x + c.lungime + razaBila;
                        vitezaBila.x = -vitezaBila.x;
                        score++;
                        c.hp--;
                        if (c.hp == 0) {
                            c.tip = TipCaramida::None;
                            c.shrink = true;
                        }
                        else
                            c.tip = vectTipuri[randCaramizi + 1 - c.hp];
                        break;
                    }
                }
            }
        }
        for (auto& c : caramizi)
            if (c.shrink == true) {
                c.scale -= 2.5f * deltaTimeSeconds;
                if (c.scale <= 0.0f) {
                    c.scale = 0.0f;
                    c.shrink = false;
                }
            }
        RenderGame();
    }
    else RenderEditor();

}

void Tema1::DrawRedFrame(glm::vec2 bl, float width, float height)
{
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(bl.x, bl.y);
    modelMatrix *= transform2D::Scale(width, height);
    RenderMesh2D(meshes["chenarRosu"], shaders["VertexColor"], modelMatrix);
}

void Tema1::DrawBlueFrame(glm::vec2 bloc, float width, float height)
{
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(bloc.x, bloc.y);
    modelMatrix *= transform2D::Scale(width, height);
    RenderMesh2D(meshes["chenarAlbastru"], shaders["VertexColor"], modelMatrix);
}


void Tema1::DrawSquareInside(const std::string& meshId, glm::vec2 bl, float size)
{
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(bl.x, bl.y);
    modelMatrix *= transform2D::Scale(size, size);
    RenderMesh2D(meshes[meshId], shaders["VertexColor"], modelMatrix);
}

void Tema1::DrawTriangle(const std::string& meshId, glm::vec2 bloc, float width, float height, float radians)
{
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(bloc.x, bloc.y);
    modelMatrix *= transform2D::Rotate(radians);
    modelMatrix *= transform2D::Scale(width, height);
    modelMatrix *= transform2D::Translate(-0.5f, -1.0f);
    RenderMesh2D(meshes[meshId], shaders["VertexColor"], modelMatrix);
}

void Tema1::DrawEngine(glm::vec2 bloc, float size) {
    // imi pastrez aceeasi logica, originea motorului in stanga jos a patratului
    DrawSquareInside("patratPortocaliu", bloc, size);

    // pun flacarile:
    float width = size * 0.16f;
    float height = size * 0.38f;
    float x1 = size * 0.2f;
    float x2 = size * 0.5f;
    float x3 = size * 0.8f;
    glm::vec2 a1 = glm::vec2(bloc.x + x1, bloc.y - height);
    glm::vec2 a2 = glm::vec2(bloc.x + x2, bloc.y - height);
    glm::vec2 a3 = glm::vec2(bloc.x + x3, bloc.y - height);
    DrawTriangle("triFlame", a1, width, height, M_PI);
    DrawTriangle("triFlame", a2, width, height, M_PI);
    DrawTriangle("triFlame", a3, width, height, M_PI);
}

void Tema1::DrawBrick(glm::vec2 bl, float width, float height, int id) {
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(bl.x, bl.y);
    modelMatrix *= transform2D::Scale(width, height);
    RenderMesh2D(meshes[caramida_crt[id]], shaders["VertexColor"], modelMatrix);
}

void Tema1::DrawBall(glm::vec2 bl, float radius) {
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(bl.x, bl.y);
    modelMatrix *= transform2D::Scale(radius, radius);
    RenderMesh2D(meshes["bila"], shaders["VertexColor"], modelMatrix);
}

glm::vec2 Tema1::SetMouse(int mousex, int mousey) {
    glm::ivec2 res = window->GetResolution();
    glm::vec2 mousePos = glm::vec2((float)mousex, (float)res.y - mousey);
    return mousePos;
}

bool Tema1::VerifInside(glm::vec2 mouse, glm::vec2 origDreptunghi, int width, int height) {
    if (mouse.x >= origDreptunghi.x && mouse.y >= origDreptunghi.y && mouse.x <= origDreptunghi.x + width && mouse.y <= origDreptunghi.y + height)
        return true;
    else return false;
}

bool Tema1::AlegeTip(glm::vec2 mouse, TipBloc& tip) {
    for (int i = 0; i <= 1; i++) { // uitasem ca origTipuri la mine e fix originea tipului de jos!!!!
        glm::vec2 origineCrt = origTipuri + glm::vec2(0.0f, i * spatiuTipuri);
        if (VerifInside(mouse, origineCrt, dimTip, dimTip) == true) {
            if (i == 0)
                tip = TipBloc::Solid;
            else tip = TipBloc::Engine;
            return  true;
        }
    }
    return false;
}

bool Tema1::AlegeCasuta(glm::vec2 mouse, int& linieCelula, int& coloanaCelula) {
    if (VerifInside(mouse, origMatrice, coloane * dimCasute + (coloane - 1) * gapCasute, linii * dimCasute + (linii - 1) * gapCasute) == false)
        return false;
    glm::vec2 aux;
    aux = mouse - origMatrice; // cu cat sunt in sus si in dr fata de originea matr.
    int col, lin;
    col = (int)floor(aux.x / (dimCasute + gapCasute));
    lin = (int)floor(aux.y / (dimCasute + gapCasute));
    // calc cate casute + gap incap in stanga jos relativ la unde sunt
    float auxx, auxy;
    auxx = aux.x - col * (dimCasute + gapCasute);
    auxy = aux.y - lin * (dimCasute + gapCasute);
    // am fct oarecum o translatie la prima casuta din stanga jos
    if (auxx > dimCasute || auxy > dimCasute)
        return false;
    else {
        linieCelula = lin;
        coloanaCelula = col;
        return true;
    }
}

void Tema1::InitCaramizi() {
    caramizi.clear();
    glm::ivec2 res = window->GetResolution();
    float start_y = res.y - 90.0f;
    for (int i = 0; i <= randCaramizi - 1; i++)
        for (int j = 0; j <= colCaramizi - 1; j++) {
            glm::vec2 origCaramida = glm::vec2(j * (lgCaramida + gapCaramizi), start_y - i * (latCaramida + gapCaramizi));
            Caramida c;
            c.hp = randCaramizi - i;
            c.lungime = lgCaramida;
            c.latime = latCaramida;
            c.pos = origCaramida;
            c.tip = vectTipuri[i + 1]; // am pus none la 0
            c.shrink = false;
            c.scale = 1;
            caramizi.push_back(c);
        }
}

bool Tema1::VerifConstrangeri() {
    // retin index urile blocurilor care ma intereseaza:
    std::vector<glm::ivec2> blocuri;
    std::vector<glm::ivec2> motoare;

    int nr_casute;
    nr_casute = 0;
    for (int i = 0; i <= linii - 1; i++)
        for (int j = 0; j <= coloane - 1; j++) {
            TipBloc t;
            t = matrice[Index(i, j)].type;
            if (t != TipBloc::None) { // ma intereseaza blocurile adaugate
                nr_casute++;
                blocuri.push_back({i, j});
                if (t == TipBloc::Engine)
                    motoare.push_back({i, j});
            }
        }
    if (nr_casute == 0 || nr_casute > 10)
        return false;

    for (auto& m : motoare)
        for (auto& b : blocuri)
            if (b.y == m.y && b.x < m.x) // pt ca mie imi creste x de jos in sus
                return false;

    // partea cea mai complexa: conexitate?
    bool conex;
    conex = true;

    if (blocuri.empty() == false) {
        // retin "indecsii unde am blocuri"
        std::vector<bool> isBlock(linii * coloane, false); // putin ineficient
        for (const auto &b : blocuri)
            isBlock[Index(b.x, b.y)] = true;

        // tb facut un BFS
        // asa ca imi tb si un vector care imi spune despre fiecare element adaugat in isBlock daca e vizitat pana acum sau nu
        std::vector<bool> vis(linii * coloane, false);
        std::queue<glm::ivec2> Q;

        Q.push(blocuri[0]);
        vis[Index(blocuri[0].x, blocuri[0].y)] = true;

        int atinse;
        atinse = 0; // numar in cate elemente am ajuns prin bfs
        // vectori de directii, ca in liceu:
        int vectX[4] = {-1, 1, 0, 0};
        int vectY[4] = {0, 0,-1, 1};
        while (Q.empty() == false) {
            glm::ivec2 v = Q.front(); // caut "vecinii" primului elem
            Q.pop();
            atinse++;
            for (int k = 0; k <= 3; k++) {
                int vecinx, veciny;
                // x = linie, y = coloana!!!!!!!!!
                vecinx = v.x + vectX[k];
                veciny = v.y + vectY[k];
                if (vecinx >= 0 && vecinx <= linii - 1 && veciny >= 0 && veciny <= coloane - 1) {
                    int idx = Index(vecinx, veciny);
                    if (isBlock[idx] == true && vis[idx] == false) {
                        vis[idx] = true;
                        Q.push({vecinx, veciny});
                    }
                }
            }
        }
        if (atinse != (int)blocuri.size())
            return false;
    }

    return true;
}

void Tema1::RenderEditor() {
    start = VerifConstrangeri();
    // desenez partea cu tipurile:
    // aici partea de chenar rosu:


    float padding;
    padding = 70.0f; // spatiul dintre elemente si chenar efectiv
    glm::vec2 origChenar = origTipuri + glm::vec2(-padding, -padding);
    DrawRedFrame(origChenar, dimTip + 2 * padding, dimTip + 2 * padding + spatiuTipuri);

    // linia rosie la mijlocul chenarului:
    float mijl;
    mijl = origChenar.y + (dimTip + 2 * padding + spatiuTipuri) / 2.0f;
    glm::vec2 linie = {origChenar.x, mijl - 2.0f * 0.5f};
    modelMatrix = glm::mat3(1);
    modelMatrix *= transform2D::Translate(linie.x, linie.y);
    modelMatrix *= transform2D::Scale(dimTip + 2 * padding, 2.0f);
    RenderMesh2D(meshes["linieRosie"], shaders["VertexColor"], modelMatrix);


    for (int i = 0; i <= 1; i++) {
        glm::vec2 bloc = origTipuri + glm::vec2(0.0f, i * spatiuTipuri);
        char* meshId;
        if (i == 0)
            DrawSquareInside("patratGri", bloc, dimTip);
        else
            DrawEngine(bloc, dimTip);
    }


    // matricea:
    for (int i = 0; i <= linii - 1; i++) {
        for (int j = 0; j <= coloane - 1; j++) {
            glm::vec2 bloc = origMatrice + glm::vec2(j * (dimCasute + gapCasute), i * (dimCasute + gapCasute));
            TipBloc t = matrice[Index(i, j)].type;
            if (t == TipBloc::Solid)
                DrawSquareInside("patratGri", bloc - glm::vec2(gapCasute / 2.0f, gapCasute / 2.0f), dimTip);
            else if (t == TipBloc::Engine)
                DrawEngine(bloc - glm::vec2(gapCasute / 2.0f, gapCasute / 2.0f), dimTip);
            else DrawSquareInside("patratAlbastru", bloc, dimCasute);
        }
    }
    // animatia la hover peste elementele matricei
    if (linHover != -1 && colHover != -1 && matrice[Index(linHover, colHover)].type == TipBloc::None) {
        glm::vec2 blHover = origMatrice + glm::vec2(colHover * (dimCasute + gapCasute), linHover * (dimCasute + gapCasute));
        DrawBlueFrame(blHover, dimCasute, dimCasute);
    }

    //chenarul albastru din jurul matricei:
    float paddingx;
    paddingx = 90.0f;
    glm::vec2 origChenarBlue = origMatrice + glm::vec2(-paddingx, -paddingx);
    DrawBlueFrame(origChenarBlue, 2 * paddingx + coloane * dimCasute + gapCasute * (coloane - 1), 2 * paddingx + linii * dimCasute + gapCasute * (linii - 1));


    // bara de sus de patrate verzi
    int ramase;
    ramase = maxBlocuri - blocuriExista;
    for (int i = 0; i <= ramase - 1; i++) {
        glm::vec2 bloc = origBara + glm::vec2(i * (dimensiune + gapBara), 0.0f);
        DrawSquareInside("patratVerde", bloc, dimensiune);
    }

    // partea asta se ocupa de adaugarea elementelor din stanga in matrice:

    if (drag == true && tipDrag != TipBloc::None) {
        // pun originea blocului pe cursor
        glm::vec2 blocPrev = pozMouse - glm::vec2(dimTip / 2.0f, dimTip / 2.0f);
        if (tipDrag == TipBloc::Solid)
            DrawSquareInside("patratGri", blocPrev, dimTip);
        else if (tipDrag == TipBloc::Engine)
            DrawEngine(blocPrev, dimTip);
    }

    // butonul de start:
    char* startMesh;
    if (start == true)
        startMesh = "patratVerde";
    else startMesh = "patratRosu";
    DrawSquareInside(startMesh, origStart, dimensiune);

    // triunghiul lipsa din patratul de start:
    // vreau sa rotesc triunghiul la 90 de grade
    DrawTriangle("triBlack", origStart + glm::vec2(dimensiune * 0.5f, dimensiune * 0.5f), dimensiune, dimensiune * 0.5f, M_PI / 2.0f);
}

void Tema1::RenderGame() {
    glm::ivec2 res = window->GetResolution();

    // textul facut cu text renderer pt score si lives:
    if (textRenderer != nullptr) {
        std::string scoreText = "Score: " + std::to_string(score);
        std::string livesText = "Lives: " + std::to_string(lives);
        textRenderer->RenderText(scoreText, 20.0f, res.y - 700.0f, 0.8f, glm::vec3(1.0f));
        textRenderer->RenderText(livesText, res.x - 120.0f, res.y - 700.0f, 0.8f, glm::vec3(1.0f));
    }


    // desenarea matricei de caramizi acum ca am initializat vectorul de caramizi:
    for (int i = 0; i <= caramizi.size() - 1; i++) {
        int id;
        if (caramizi[i].hp == 0)
            id = 4;
        else id = randCaramizi - caramizi[i].hp;
        if (caramizi[i].scale > 0)
            DrawBrick(caramizi[i].pos, caramizi[i].lungime * caramizi[i].scale, caramizi[i].latime * caramizi[i].scale, id);
    }

    listaSolid.clear();
    listaMotor.clear();

    // mai intai gandesc cum sa aduc nava, asa cum am creat o, in joc:
    for (int i = 0; i <= linii - 1; i++)
        for (int j = 0; j <= coloane - 1; j++)
            if (matrice[Index(i, j)].type == TipBloc::Solid)
                listaSolid.push_back({i, j});
            else
                if (matrice[Index(i, j)].type == TipBloc::Engine)
                    listaMotor.push_back({i, j});
    // pt ca indecsii retinuti in listamotor si listasolid sunt retinute in ordinea in care le am gasit,
    // adica parcurgerea matricei de jos in sus, de la stanga la dreapta, mereu minimul dintre primul x din solid
    // si primul x din motor si minimul dintre primul y din solid si primul y din motor reprez. blocul din st jos
    // si pot face o shiftare cu minime, ca sa am loc in matrice sa merg cat vreau in dreapta si in sus
    int minx, miny;
    minx = 1000;
    miny = 1000;
    if (listaMotor.empty() == false)
        minx = listaMotor[0].x, miny = listaMotor[0].y;
    if (listaSolid.empty() == false && listaSolid[0].x < minx)
        minx = listaSolid[0].x;
    if (listaSolid.empty() == false && listaSolid[0].y < miny)
        miny = listaSolid[0].y;


    int maxy;
    maxy = 0;
    for (auto& aux : listaMotor)
        if (aux.y > maxy)
            maxy = aux.y;
    for (auto& aux : listaSolid)
        if (aux.y > maxy)
            maxy = aux.y;
    int maxx;
    maxx = 0;
    for (auto& aux : listaMotor)
        if (aux.x > maxx)
            maxx = aux.x;
    for (auto& aux : listaSolid)
        if (aux.x > maxx)
            maxx = aux.x;

    for (auto& aux : listaMotor)
        aux.x -= minx, aux.y -= miny;
    for (auto& aux : listaSolid)
        aux.x -= minx, aux.y -= miny;

    rachetaLg = (maxy - miny + 1) * dimTip;
    if (rachetaInceput == false) { // ca sa o setez doar cand tb. la mijl.
        rachetaY = 70.0f;
        rachetaX = res.x / 2.0f - rachetaLg / 2.0f;
        rachetaInceput = true;
    }


    glm::vec2 loc = glm::vec2(rachetaX, rachetaY);

    racheta.clear();
    // DIMTIP/DIMCASUTE???? care arata mai bine
    for (auto& aux : listaSolid) {
        glm::vec2 origCrt;
        origCrt = loc + glm::vec2(aux.y * dimTip, aux.x * dimTip);
        DrawSquareInside("patratGri", origCrt, dimTip);
        // il adaug si in vectorul de aabb-uri:
        AABB blCrt;
        blCrt.min = origCrt; // aici aveam un bug!!! il faceam loc
        blCrt.max = origCrt + glm::vec2(dimTip, dimTip);
        racheta.push_back(blCrt);
    }
    for (auto& aux : listaMotor) {
        glm::vec2 origCrt;
        origCrt = loc + glm::vec2(aux.y * dimTip, aux.x * dimTip);
        DrawEngine(origCrt, dimTip);
        AABB blCrt;
        blCrt.min = origCrt;
        blCrt.max = origCrt + glm::vec2(dimTip, dimTip);
        racheta.push_back(blCrt);
    }

    // desenez bila:
    if (misca == false) {
        int maxBila = 0;
        if ((maxy - miny + 1) % 2 == 1) {
            // mai usor => am doar un bloc la mijl.
            int mijl = (maxy - miny) / 2.0;
            for (auto& aux : listaSolid)
                if (aux.y == mijl && aux.x > maxBila)
                    maxBila = aux.x;
            for (auto& aux : listaMotor)
                if (aux.y == mijl && aux.x > maxBila)
                    maxBila = aux.x;
        }
        else {
            // de luat si stanga si dreapta in calcul:
            int mijl = (maxy - miny) / 2.0;
            for (auto& aux : listaSolid)
                if ((aux.y == mijl || aux.y == mijl + 1) && aux.y > maxBila)
                    maxBila = aux.x;
            for (auto& aux : listaMotor)
                if ((aux.y == mijl || aux.y == mijl + 1) && aux.y > maxBila)
                    maxBila = aux.x;
        }
        origBila = glm::vec2(res.x / 2, rachetaY + (maxBila + 1) * dimTip + razaBila);
    }
    DrawBall(origBila, razaBila);

}

void Tema1::FrameEnd()
{
    // mi am sters standardul 3D pe care il aveam din laborator
}


/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Tema1::OnInputUpdate(float deltaTime, int mods)
{
    // Treat continuous update based on input

    // TODO(student): Add some key hold events that will let you move
    // a mesh instance on all three axes. You will also need to
    // generalize the position used by `RenderMesh`.


    //float d;
    //d = moveSpeed* deltaTime;
    //if (window->KeyHold(GLFW_KEY_W))
    //    objPos += glm::vec3(0.0f, 0.0f, -d);
    //if (window->KeyHold(GLFW_KEY_S))
    //    objPos += glm::vec3(0.0f, 0.0f, d);
    //if (window->KeyHold(GLFW_KEY_A))
    //    objPos += glm::vec3(-d, 0.0f, 0.0f);
    //if (window->KeyHold(GLFW_KEY_D))
    //    objPos += glm::vec3(d, 0.0f, 0.0f);
    //if (window->KeyHold(GLFW_KEY_Q))
    //    objPos += glm::vec3(0.0f, -d, 0.0f);
    //if (window->KeyHold(GLFW_KEY_E))
    //    objPos += glm::vec3(0.0f, d, 0.0f);

    if (game == true) {
        float d;
        d = rachetaViteza * deltaTime;
        if (listaMotor.empty() == false)
            d += 200 * deltaTime;
        if (window->KeyHold(GLFW_KEY_LEFT))
            rachetaX -= d;
        if (window->KeyHold(GLFW_KEY_RIGHT))
            rachetaX += d;
        // ca sa ma asigur ca nu ies din ecran:
        if (rachetaX < 0)
            rachetaX = 0;
        if (rachetaX + rachetaLg > window->GetResolution().x)
            rachetaX = window->GetResolution().x - rachetaLg;
    }
}


void Tema1::OnKeyPress(int key, int mods)
{
    // Add key press event
    //if (key == GLFW_KEY_F) {
        // TODO(student): Change the values of the color components.
        //clearIdx = (clearIdx + 1) % (int)clearPalette.size();
        //clearColor = clearPalette[clearIdx];
    //}
    if (game == true && misca == false && key == GLFW_KEY_SPACE) {
        float angle = M_PI / 4.0f;
        vitezaBila = glm::vec2(vitInitBila * cos(angle), vitInitBila * sin(angle));
        misca = true;
    }

}


void Tema1::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event
    pozMouse = SetMouse(mouseX, mouseY);
    if (drag == true) {
        linHover = colHover = -1;
        return;
    }
    int l, c;
    if (AlegeCasuta(pozMouse, l, c) == true)
        linHover = l, colHover = c;
    else linHover = colHover = -1;
}


void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
    glm::vec2 mouse = SetMouse(mouseX, mouseY);
    if (button == 1) {
        // start drag din partea de tipuri:
        TipBloc t;
        if (AlegeTip(mouse, t) == true) {
            drag = true;
            tipDrag = t;
            pozMouse = mouse;
            linHover = colHover = -1;
            return;
        }

        // daca dau click pe start cand e totul ok
        if (VerifInside(mouse, origStart, dimensiune, dimensiune) == true) {
            if (start == true) { // <=>constrangerile sunt ok + butonul e verde
                game = true; // <=> in update, cand game = true, inseamna ca pot da start + am dat click stanga pe start
                nava = matrice;
            }
            return;
        }
    }

    if (button == 2) {
        // sterg bloc din matrice daca exista
        int l, c;
        if (AlegeCasuta(mouse, l, c) == true) {
            if (matrice[Index(l, c)].type != TipBloc::None) {
                matrice[Index(l, c)].type = TipBloc::None;
                if (blocuriExista > 0)
                    blocuriExista--;
            }
        }
    }
}


void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event

    if (button == 1 && drag == true) {
        glm::vec2 mouse = SetMouse(mouseX, mouseY);
        int l, c;
        if (AlegeCasuta(mouse, l, c) == true) {
            // limita de 10 blocuri
            if (blocuriExista < maxBlocuri) {
                if (matrice[Index(l, c)].type == TipBloc::None) {
                    matrice[Index(l, c)].type = tipDrag;
                    blocuriExista++;
                }
                else
                    matrice[Index(l, c)].type = tipDrag;
            }
        }
        drag = false;
        tipDrag = TipBloc::None;
        // o iau de la capat
    }

}


void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
    // Treat mouse scroll event
}


void Tema1::OnWindowResize(int width, int height)
{
    // Treat window resize event
}
