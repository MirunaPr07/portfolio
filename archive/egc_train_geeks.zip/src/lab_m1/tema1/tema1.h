#pragma once

#include "components/simple_scene.h"
#include "components/text_renderer.h"


namespace m1
{
    class Tema1 : public gfxc::SimpleScene
    {
     public:
        Tema1();
        ~Tema1();

        void Init() override;

     private:
        void FrameStart() override;
        void Update(float deltaTimeSeconds) override;
        void FrameEnd() override;

        void OnInputUpdate(float deltaTime, int mods) override;
        void OnKeyPress(int key, int mods) override;
        void OnKeyRelease(int key, int mods) override;
        void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
        void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
        void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
        void OnWindowResize(int width, int height) override;

        // TODO(student): Class variables go here
    private:
        // culoare de clear
        glm::vec3 clearColor;
        std::vector<glm::vec3> clearPalette;
        int clearIdx;

        // obiect controlat din taste
        glm::vec3 objPos;
        glm::vec3 objScale;
        float moveSpeed;

        // lista de mesh uri intre care ciclam
        std::vector<std::string> meshCycle;
        int meshIdx;
        std::string activeMeshId;
        float angle;

        // tot ce am nev. pt matrice:
        // tipurile pe care le pot folosi la construirea navei:
        enum class TipBloc {
            None,
            Solid,
            Engine
        };
        struct Celule {
            TipBloc type = TipBloc::None; // default, celulele din "matrice" sunt none
        };
        float dimCasute = 31.0f;
        float gapCasute = 12.0f;
        int linii = 9, coloane = 17;
        glm::vec2 origMatrice;
        std::vector<Celule> matrice;
        inline int Index(int l, int c)
        {
            return l * coloane + c;
        }

        //tot ce am nev pt partea din care aleg elem:
        glm::vec2 origTipuri;
        float dimTip = 43.0f; // ca cea din matrice
        float spatiuTipuri = 220.0f;


        // tot pt bara de sus:
        float dimensiune = 45.0f;
        int maxBlocuri = 10, blocuriExista = 0;
        bool start = true; // deocamdata nu pot da start, nu se resp conditiile
        glm::vec2 origBara;
        float gapBara = 40.0f;



        void RenderEditor();
        void DrawSquareInside(const std::string& meshId, glm::vec2 bloc, float size);
        void DrawRedFrame(glm::vec2 bloc, float width, float height);
        void DrawBlueFrame(glm::vec2 bloc, float width, float height);
        void DrawTriangle(const std::string& meshId, glm::vec2 bloc, float width, float height, float radians = 0.0f);
        void DrawEngine(glm::vec2 bloc, float size);
        void RenderGame();
        void DrawBrick(glm::vec2 bloc, float width, float height, int id);
        void DrawBall(glm::vec2 bloc, float radius);



        glm::vec3 colGreen, colRed, colBlue, colOrange, colGrey, colWhite;
        glm::mat3 modelMatrix; // ca in lab3


        // aici ce am nev pt functionalitate efectiv:
        
        // gestionarea drag ului unui tip:
        bool drag = false; // default nu dau drag la nimic
        TipBloc tipDrag = TipBloc::None;
        glm::vec2 pozMouse = glm::vec2(0.0f);
        int linHover = -1, colHover = -1; // celula peste care e cursorul: -1 inseamna ca nu e in matrice

        bool game = false; // nu dau start
        glm::vec2 origStart;
        std::vector<Celule> nava; // in el imi retin nava pentru in joc


        glm::vec2 SetMouse(int mousex, int mousey);
        bool VerifInside(glm::vec2 mouse, glm::vec2 origDreptunghi, int width, int height);
        bool AlegeTip(glm::vec2 mouse, TipBloc& tip);
        bool AlegeCasuta(glm::vec2 mouse, int& linieCelula, int& coloanaCelula);
        bool VerifConstrangeri();
        void InitCaramizi();

        // declarari pt joc:
        std::vector<glm::ivec2> listaSolid;
        std::vector<glm::ivec2> listaMotor;

        enum class TipCaramida {
            None = 0,
            Roz1, // cel mai inchis => puternic
            Roz2,
            Roz3,
            Roz4,
            Roz5 // cel mai deschis => slab
        };
        std::vector<TipCaramida> vectTipuri = { TipCaramida::None, TipCaramida::Roz1, TipCaramida::Roz2, TipCaramida::Roz3, TipCaramida::Roz4, TipCaramida::Roz5 };
        
        struct Caramida {
            TipCaramida tip;
            glm::vec2 pos;
            float lungime;
            float latime;
            int hp;
            bool shrink;
            float scale;
        };

        std::vector<Caramida> caramizi; // matricea de caramizi, ca cea de patrate din editor
        float lgCaramida;
        float latCaramida = 40.0f;
        int colCaramizi = 14;
        int randCaramizi = 5;
        float gapCaramizi = 2.0f;

        glm::vec3 colRoz1, colRoz2, colRoz3, colRoz4, colRoz5;
        std::string caramida_crt[5];

        // lives si score, cu text renderer ca in enunt:
        gfxc::TextRenderer* textRenderer = nullptr;
        int score = 0;
        int lives = 3;

        // bila:
        glm::vec2 origBila; // aici o sa ma raportez la centrul bilei!!!
        float razaBila = 14.0f;
        bool misca = false;
        glm::vec2 vitezaBila;
        float vitInitBila = 350.0f;

        // fac o structura de aabb ca sa aproximez blocurile din nava,
        // cum zice in enunt:
        struct AABB {
            glm::vec2 min; // coltul stanga jos
            glm::vec2 max; // coltul dreapta sus
        };
        std::vector<AABB> racheta;
        float rachetaX, rachetaY, rachetaLg, rachetaViteza = 350.0f;
        bool rachetaInceput = false;


    };
}   // namespace m1
