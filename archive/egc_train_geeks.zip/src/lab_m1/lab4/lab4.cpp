#include "lab_m1/lab4/lab4.h"

#include <vector>
#include <string>
#include <iostream>

#include "lab_m1/lab4/transform3D.h"

using namespace std;
using namespace m1;


/*
 *  To find out more about `FrameStart`, `Update`, `FrameEnd`
 *  and the order in which they are called, see `world.cpp`.
 */


Lab4::Lab4()
{
}


Lab4::~Lab4()
{
}


void Lab4::Init()
{
    polygonMode = GL_FILL;

    Mesh* mesh = new Mesh("box");
    mesh->LoadMesh(PATH_JOIN(window->props.selfDir, RESOURCE_PATH::MODELS, "primitives"), "box.obj");
    meshes[mesh->GetMeshID()] = mesh;

    // Initialize tx, ty and tz (the translation steps)
    translateX = 0;
    translateY = 0;
    translateZ = 0;

    // Initialize sx, sy and sz (the scale factors)
    scaleX = 1;
    scaleY = 1;
    scaleZ = 1;

    // Initialize angular steps
    angularStepOX = 0;
    angularStepOY = 0;
    angularStepOZ = 0;

    // Sets the resolution of the small viewport
    glm::ivec2 resolution = window->GetResolution();
    miniViewportArea = ViewportArea(50, 50, resolution.x / 5.f, resolution.y / 5.f);
}

void Lab4::FrameStart()
{
    // Clears the color buffer (using the previously set color) and depth buffer
    glClearColor(0, 0, 0, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Lab4::RenderScene() {
    modelMatrix = glm::mat4(1);
    modelMatrix *= transform3D::Translate(-2.5f, 0.5f, -1.5f);
    modelMatrix *= transform3D::Translate(translateX, translateY, translateZ);
    RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);

    modelMatrix = glm::mat4(1);
    modelMatrix *= transform3D::Translate(0.0f, 0.5f, -1.5f);
    modelMatrix *= transform3D::Scale(scaleX, scaleY, scaleZ);
    RenderMesh(meshes["box"], shaders["Simple"], modelMatrix);

    modelMatrix = glm::mat4(1);
    modelMatrix *= transform3D::Translate(2.5f, 0.5f, -1.5f);
    modelMatrix *= transform3D::RotateOX(angularStepOX);
    modelMatrix *= transform3D::RotateOY(angularStepOY);
    modelMatrix *= transform3D::RotateOZ(angularStepOZ);
    RenderMesh(meshes["box"], shaders["VertexNormal"], modelMatrix);
}

void Lab4::Update(float deltaTimeSeconds)
{
    glLineWidth(3);
    glPointSize(5);
    glPolygonMode(GL_FRONT_AND_BACK, polygonMode);

    // Sets the screen area where to draw
    glm::ivec2 resolution = window->GetResolution();
    glViewport(0, 0, resolution.x, resolution.y);

    RenderScene();
    DrawCoordinateSystem();

    glClear(GL_DEPTH_BUFFER_BIT);
    glViewport(miniViewportArea.x, miniViewportArea.y, miniViewportArea.width, miniViewportArea.height);

    // TODO(student): render the scene again, in the new viewport
    RenderScene(); // randez din nou aceleasi obiecte
    DrawCoordinateSystem();
}

void Lab4::FrameEnd()
{
}


/*
 *  These are callback functions. To find more about callbacks and
 *  how they behave, see `input_controller.h`.
 */


void Lab4::OnInputUpdate(float deltaTime, int mods)
{
    // TODO(student): Add transformation logic
    const float moveSpeed = 2.0f;
    const float scaleSpeed = 1.0f;
    const float angSpeed = 2.0f;

    // comenzile pentru primul cub: wasd si r, f pt miscare pe toate axele
    if (window->KeyHold(GLFW_KEY_W))
        translateZ -= moveSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_S))
        translateZ += moveSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_A))
        translateX -= moveSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_D))
        translateX += moveSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_R))
        translateY += moveSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_F))
        translateY -= moveSpeed * deltaTime;

    // pt al doilea cub: scalare (micsorare si marire dupa 1 si 2), UNIFORM:
    if (window->KeyHold(GLFW_KEY_1)) {
        float s;
        s = 1.0f + scaleSpeed * deltaTime;
        scaleX *= s;
        scaleY *= s;
        scaleZ *= s;
    }
    if (window->KeyHold(GLFW_KEY_2)) {
        float s;
        s = 1.0f - scaleSpeed * deltaTime;
        scaleX *= s;
        scaleY *= s;
        scaleZ *= s;
        // tin cont sa nu ajunga la 0 sau chiar sub:
        scaleX = std::max(scaleX, 0.05f);
        scaleY = std::max(scaleY, 0.05f);
        scaleZ = std::max(scaleZ, 0.05f);
    }

    // rotatiile pentru al treilea cub
    // 3-4: rot. pe Ox; 5-6: pe Oy; 7-8: Oz
    if (window->KeyHold(GLFW_KEY_3))
        angularStepOX += angSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_4))
        angularStepOX -= angSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_5))
        angularStepOY += angSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_6))
        angularStepOY -= angSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_7))
        angularStepOZ += angSpeed * deltaTime;
    if (window->KeyHold(GLFW_KEY_8))
        angularStepOZ -= angSpeed * deltaTime;
}


void Lab4::OnKeyPress(int key, int mods)
{
    // Add key press event
    if (key == GLFW_KEY_SPACE)
    {
        switch (polygonMode)
        {
        case GL_POINT:
            polygonMode = GL_FILL;
            break;
        case GL_LINE:
            polygonMode = GL_POINT;
            break;
        default:
            polygonMode = GL_LINE;
            break;
        }
    }
    
    // TODO(student): Add viewport movement and scaling logic
    const int step = 20; // pixeli
    if (key == GLFW_KEY_I)
        miniViewportArea.y += step;
    if (key == GLFW_KEY_K)
        miniViewportArea.y -= step;
    if (key == GLFW_KEY_J)
        miniViewportArea.x -= step;
    if (key == GLFW_KEY_L)
        miniViewportArea.x += step;
    if (key == GLFW_KEY_U) {
        miniViewportArea.width = std::max(20.0f, miniViewportArea.width * 0.9f);
        miniViewportArea.height = std::max(20.0f, miniViewportArea.height * 0.9f);
    }
    if (key == GLFW_KEY_O) {
        miniViewportArea.width *= 1.1f;
        miniViewportArea.height *= 1.1f;
    }
}


void Lab4::OnKeyRelease(int key, int mods)
{
    // Add key release event
}


void Lab4::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
    // Add mouse move event
}


void Lab4::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button press event
}


void Lab4::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
    // Add mouse button release event
}


void Lab4::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}


void Lab4::OnWindowResize(int width, int height)
{
}
