/* PRUNOIU Miruna-Alessandra-311CB */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
typedef struct nod {
	int nod_ad, nr_tronsoane, sursa, nr_drum, distanta;
	float degradari[100];
	struct nod *urm;
} TCelula, *TLista;

void ambele_noi(TLista graf[100], char *orase[100], int *nr_orase, char *sir1, char *sir2, FILE *fis_intrare, int index_drum) {
	int j;
	orase[*nr_orase] = calloc(100, sizeof(char));
	orase[*nr_orase + 1] = calloc(100, sizeof(char)); // imi aloc memorie in vectorul de siruri
	strcpy(orase[*nr_orase], sir1);
	graf[*nr_orase] = calloc(1, sizeof(TCelula)); // imi aloc memorie pt o noua celula
	if (graf[*nr_orase] == NULL) {
		printf("err");
		return;
	}
	graf[*nr_orase]->nod_ad = *nr_orase + 1; // pozitia nodului adiacent e nr_orase + 1
	fscanf(fis_intrare, "%d", &graf[*nr_orase]->nr_tronsoane); // citesc nr. de tronsoane
	for (j = 0; j <= graf[*nr_orase]->nr_tronsoane - 1; j++)
		fscanf(fis_intrare, "%f", &graf[*nr_orase]->degradari[j]); // citesc degradarile
	//pana aici mi am alocat memorie pentru un nou nod
	//si mi am pus informatia necesara in el
	graf[*nr_orase]->sursa = 0; // sursa imi arata din care nod plec si in care ajung
	graf[*nr_orase]->urm = NULL;
	graf[*nr_orase]->nr_drum = index_drum; // imi retin numarul rutei la care sunt, ca sa ma folosesc de asta la afisare
	//daca intre lisabona si madrid am o muchie, tb sa pun informatia
	//corespunzatoare acesteia in reprezentarea grafului si pentru nodul
	//coresp. lisabona si pt cel coresp. madrid, pt a face inteles faptul ca
	//graful nu e orientat
	//in lista corespunzatoare nodului din care plec, sursa e 0, iar in cea a celui in care ajung e 1
	strcpy(orase[*nr_orase + 1], sir2);
	graf[*nr_orase + 1] = calloc(1, sizeof(TCelula));
	if (graf[*nr_orase + 1] == NULL) {
		printf("err");
		return;
	}
	graf[*nr_orase + 1]->nod_ad = *nr_orase;
	graf[*nr_orase + 1]->nr_tronsoane = graf[*nr_orase]->nr_tronsoane;
	for (j = 0; j <= graf[*nr_orase]->nr_tronsoane - 1; j++)
		graf[*nr_orase + 1]->degradari[j] = graf[*nr_orase]->degradari[j];
	graf[*nr_orase + 1]->urm = NULL;
	graf[*nr_orase + 1]->sursa = 1;
	graf[*nr_orase + 1]->nr_drum = index_drum;
	// fac aceleasi modif pt urm celula
	*nr_orase += 2; //cresc numarul oraselor cu 2
}

void una_noua(TLista graf[100], char *orase[100], int *nr_orase, int index, char *sir, FILE *fis_intrare, int indicator, int index_drum) {
	TLista p;
	int j;
	orase[*nr_orase] = calloc(100, sizeof(char));
	p = graf[index];
	while (p->urm != NULL)
		p = p->urm;
	// ma mut cu p pe ultima celula a listei si creez o noua celula
	p->urm = calloc(1, sizeof(TCelula));
	if (p->urm == NULL) {
		printf("err");
		return;
	}
	p->urm->nod_ad = *nr_orase;
	fscanf(fis_intrare, "%d", &p->urm->nr_tronsoane);
	for (j = 0; j <= p->urm->nr_tronsoane - 1; j++)
		fscanf(fis_intrare, "%f", &p->urm->degradari[j]);
	p->urm->urm = NULL;
	p->urm->nr_drum = index_drum;
	strcpy(orase[*nr_orase], sir);
	graf[*nr_orase] = calloc(1, sizeof(TCelula));
	if (graf[*nr_orase] == NULL) {
		printf("err");
		return;
	}
	graf[*nr_orase]->nod_ad = index;
	graf[*nr_orase]->nr_tronsoane = p->urm->nr_tronsoane;
	for (j = 0; j <= p->urm->nr_tronsoane - 1; j++)
		graf[*nr_orase]->degradari[j] = p->urm->degradari[j];
	graf[*nr_orase]->urm = NULL;
	graf[*nr_orase]->nr_drum = index_drum;
	if (indicator == 0) { // de indicator ma folosesc aici ca sa stiu din ce nod plec
		p->urm->sursa = 0;
		graf[*nr_orase]->sursa = 1;
	}
	else {
		p->urm->sursa = 1;
		graf[*nr_orase]->sursa = 0;
	}
	*nr_orase += 1;
}

void ambele_vechi (TLista graf[100], int index1, int index2, FILE *fis_intrare, int index_drum) {
	TLista p1, p2;
	int j;
	p1 = graf[index1];
	while (p1->urm != NULL)
		p1 = p1->urm;
	p2 = graf[index2];
	while (p2->urm != NULL)
		p2 = p2->urm;
	p1->urm = calloc(1, sizeof(TCelula));
	p2->urm = calloc(1, sizeof(TCelula));
	if (p1->urm == NULL || p2->urm == NULL) {
		printf("err");
		return;
	}
	p1->urm->nod_ad = index2;
	p2->urm->nod_ad = index1;
	fscanf(fis_intrare, "%d", &p1->urm->nr_tronsoane);
	p2->urm->nr_tronsoane = p1->urm->nr_tronsoane;
	for (j = 0; j <= p1->urm->nr_tronsoane - 1; j++) {
		fscanf(fis_intrare, "%f", &p1->urm->degradari[j]);
		p2->urm->degradari[j] = p1->urm->degradari[j];
	}
	p1->urm->urm = NULL;
	p2->urm->urm = NULL;
	p1->urm->sursa = 0;
	p2->urm->sursa = 1;
	p1->urm->nr_drum = index_drum;
	p2->urm->nr_drum = index_drum;
}

float urmator(TLista p, TLista graf[100], int index) {
	TLista q, r;
	float maxim;
	maxim = 0;
	q = graf[p->nod_ad];
	while (q != NULL) {
		if (q->nod_ad != index) { // caut celula care are nodul adiacent coresp. egal cu indexul
			if (q->sursa == 1 && q->degradari[q->nr_tronsoane - 1] > maxim)
				maxim = q->degradari[q->nr_tronsoane - 1];
			else if (q->sursa == 0) { // asta e modificat, il caut pe cel cu sursa 1
				r = graf[q->nod_ad];
				while (r->nod_ad != p->nod_ad)
					r = r->urm;
				if (r->degradari[0] > maxim)
					maxim = r->degradari[0];
			}
			// calculez maximul dintre toate primele degradari ale tuturor nodurilor adiacente
			// (trebuie sa le iau doar pe cele care pleaca din nodul curent)
		}
		q = q->urm;
	}
	return maxim;
}

float anterior(TLista p, TLista graf[100], int index) {
	float maxim;
	TLista q;
	maxim = 0;
	q = graf[index];
	while (q != NULL) {
		if (q != p) {
			if (q->sursa == 1 && q->degradari[q->nr_tronsoane - 1] > maxim)
				maxim = q->degradari[q->nr_tronsoane - 1];
			else if (q->sursa == 0) { // ii caut corespondentul cu 1
					TLista r;
					r = graf[q->nod_ad];
					while (r != NULL) {
						if (r->sursa == 1 && r->nod_ad == index) {
							if (r->degradari[0] > maxim)
								maxim = r->degradari[0];
							break;
						}
						r = r->urm;
					}
					// calculez maximul dintre toate ultimele degradari ale tuturor nodurilor adiacente
					// (trebuie sa le iau doar pe cele care intra in nodul curent)
				}
		}
		q = q->urm;
	}
	return maxim;
}

float ant_neschimbat (TLista graf[100], TLista p, int index_vector, int index_oras) {
	TLista q;
	q = graf[p->nod_ad];
	while (q != NULL && q->nod_ad != index_oras)
		q = q->urm;
	return q->degradari[index_vector];
	// functia imi returneaza cat era inainte pe pozitia trimisa ca param.
}

void modif_degradari(TLista graf[100], int nr_orase, int nr_ani) {
	int i, j, k;
	TLista p, q;
	for (i = 1; i <= nr_ani; i++) { // aplic modif. de cati ani tb.
		for (j = 0; j <= nr_orase - 1; j++) {
			p = graf[j]; // pt fiecare nod ii parcurg lista de ad.
			while (p != NULL) {
				if (p->sursa == 0) { // aplic modificarile doar pe celulele cu sursa 0, de cele cu 1 ma fol. ca sa aflu val inainte de modif.
					for (k = 0; k <= p->nr_tronsoane - 1; k++) {
						if (p->degradari[k] != 0) { // dc valoarea nu e nula
							if (p->degradari[k] * 2 > 100)
								p->degradari[k] = 100;
							else
								p->degradari[k] *= 2; // o dublez
						}
						else {
							if (k == 0) { // dc e primul tronson si degradarea e 0
								if (p->nr_tronsoane == 1) { // caz separat dc am un sg tronson
									if (anterior(p, graf, j) > urmator(p, graf, j))
										p->degradari[k] = anterior(p, graf, j) / 2;
									else
										p->degradari[k] = urmator(p, graf, j) / 2; // val mea devine 1/2 din maximul anterior si maximul urmator
								}
								else {
									if (anterior(p, graf, j) > p->degradari[k + 1]) // urmatorul element din degradari nu s a modif inca
										p->degradari[k] = anterior(p, graf, j) / 2;
									else
										p->degradari[k] = p->degradari[k + 1] / 2;
								}
							}
							else
								if (k == p->nr_tronsoane - 1) { // daca sunt pe ultima poz din vect de degradari
									if (ant_neschimbat(graf, p, k - 1, j) > urmator(p, graf, j))
										p->degradari[k] = ant_neschimbat(graf, p, k - 1, j) / 2;
									else
										p->degradari[k] = urmator(p, graf, j) / 2;
								}
								else { // daca nu sunt nici pe prima, nici pe ultima poz.
									// elementul ar tb sa devina max(p->degradari[k - 1], p->degradari[k + 1]) / 2,
									// dar elementul de pe poz anterioara e deja modif
									if (ant_neschimbat(graf, p, k - 1, j) > p->degradari[k + 1]) // urmatorul elem nu s a modif inca
										p->degradari[k] = ant_neschimbat(graf, p, k - 1, j) / 2;
									else
										p->degradari[k] = p->degradari[k + 1] / 2;
								}
						}
					}
				}
				p = p->urm;
			}
		}
		// aici modificarea pt cele cu 1
		// celulele cu sursa 1 iau valorile calculate in vectorul de degradari al celor cu sursa 0
		for (j = 0; j <= nr_orase - 1; j++) {
			p = graf[j];
			while (p != NULL) {
				if (p->sursa == 1) {
					q = graf[p->nod_ad];
					while (q->nod_ad != j)
						q = q->urm;
					for (k = 0; k <= p->nr_tronsoane - 1; k++)
						p->degradari[k] = q->degradari[k];
				}
				p = p->urm;
			}
		}
	}
}


int minindex(int distante[100], int vizitat[100], int nr_orase) {
	// functia asta imi parcurge toate nodurile si imi returneaza indexul
	// aceluia care nu a fost inca vizitat si care are distanta cea mai mica
	int minim, poz_min, i;
	minim = INT_MAX;
	poz_min = 0;
	for (i = 0; i <= nr_orase - 1; i++)
		if (vizitat[i] == 0 && distante[i] < minim) {
			minim = distante[i];
			poz_min = i;
		}
	return poz_min;
}

void dijkstra(TLista graf[100], int nr_orase, int nmax_rute, char *orase[100], FILE *fis_iesire) {
	int vizitat[100], distante[100], i, index, pleaca[100], ajunge[100], ordine_citire[100], ordine_noduri[100];
	// pleaca reprezinta nodul din care pleaca ultima muchie din drumul cel mai scurt catre un nod
	// in vectorul ajunge retin efectiv indicele initial al nodului, ma va ajuta la sortari si afisare
	TLista p;
	for (i = 0; i <= nr_orase - 1; i++) {
		vizitat[i] = 0;
		distante[i] = INT_MAX;
	}
	// am initializat vectorii de vizitat si distante
	distante[0] = 0;
	pleaca[0] = 0;
	for (i = 0; i <= nr_orase - 1; i++) {
		index = minindex(distante, vizitat, nr_orase); // fol indicele cu distanta cea mai mica si nevizitat
		vizitat[index] = 1; // vizitez nodul respectiv
		for (p = graf[index]; p != NULL; p = p->urm) // ii parcurg lista de adiacenta
			if (vizitat[p->nod_ad] == 0 && distante[p->nod_ad] > distante[index] + p->distanta) { // daca nodul curent adiacent nu e vizitat si am gasit o distanta mai mica
				distante[p->nod_ad] = distante[index] + p->distanta; // retin noua distanta
				pleaca[p->nod_ad] = index; // retin numarul nodului din care a plecat ultima muchie catre nodul adiacent
				ajunge[p->nod_ad] = p->nod_ad; // ajunge[nr] = nr
			}
	}
	for (i = 1; i <= nr_orase - 1; i++) {
		p = graf[i];
		while (p != NULL) {
			if (p->nod_ad == pleaca[i])
				break;
			p = p->urm;
		}
		ordine_citire[i] = p->nr_drum;
		ordine_noduri[i] = p->sursa;
	}
	// in vectorul ordine_citire retin indexul drumurilor, ca sa le stiu ordinea
	// de vectorul de ordine_noduri ma folosesc ca sa stiu in ce ordine afisez cele doua orase
	//sortare crescatoare dupa distante, in care rearanjez toti vectorii
	int ok;
	do {
		ok = 1;
		for (i = 1; i <= nr_orase - 2; i++)
			if (distante[i] > distante[i + 1]) {
				int aux;
				aux = distante[i];
				distante[i] = distante[i + 1];
				distante[i + 1] = aux;
				aux = pleaca[i];
				pleaca[i] = pleaca[i + 1];
				pleaca[i + 1] = aux;
				aux = ajunge[i];
				ajunge[i] = ajunge[i + 1];
				ajunge[i + 1] = aux;
				aux = ordine_citire[i];
				ordine_citire[i] = ordine_citire[i + 1];
				ordine_citire[i + 1] = aux;
				aux = ordine_noduri[i];
				ordine_noduri[i] = ordine_noduri[i + 1];
				ordine_noduri[i + 1] = aux;
				ok = 0;
			}
	} while (ok == 0);
	// acum sortez primele nmax_rute de care am nevoie dupa vectorul de ordine_citire
	// stiu ordinea in care afisez rutele
	do {
		ok = 1;
		for (i = 1; i <= nr_orase - 2 && i <= nmax_rute - 1; i++)
			if (ordine_citire[i] > ordine_citire[i + 1]) {
				int aux;
				aux = pleaca[i];
				pleaca[i] = pleaca[i + 1];
				pleaca[i + 1] = aux;
				aux = ajunge[i];
				ajunge[i] = ajunge[i + 1];
				ajunge[i + 1] = aux;
				aux = ordine_citire[i];
				ordine_citire[i] = ordine_citire[i + 1];
				ordine_citire[i + 1] = aux;
				aux = ordine_noduri[i];
				ordine_noduri[i] = ordine_noduri[i + 1];
				ordine_noduri[i + 1] = aux;
				ok = 0;
			}
	} while (ok == 0);
	// afisez cate rute am
	if (nmax_rute < nr_orase - 1)
		fprintf(fis_iesire, "%d\n", nmax_rute);
	else
		fprintf(fis_iesire, "%d\n", nr_orase - 1);
	for (i = 1; i <= nr_orase - 1 && i <= nmax_rute; i++)
		if (ordine_noduri[i] == 0) { // aici ma fol de ordine_noduri ca sa stiu ce nume de oras afisez primul
			fprintf(fis_iesire, "%s ", orase[ajunge[i]]);
			fprintf(fis_iesire, "%s\n", orase[pleaca[i]]);
		}
		else {
			fprintf(fis_iesire, "%s ", orase[pleaca[i]]);
			fprintf(fis_iesire, "%s\n", orase[ajunge[i]]);
		}
}

int main(int argc, char *argv[]) {
	int nr_rute, nr_ani, grad_uzura, nr_orase, i, j, index1, index2, k, indici[100], nr_indici, nmax_rute;
	char *orase[100], *sir1, *sir2, aux, sir_aux[2];
	float suma;
	TLista graf[100], p, q;
	// tratez ficare element din vectorul graf ca o lista de sine statatoare
	FILE *fis_intrare, *fis_iesire;
	sir_aux[0] = '1';
	sir_aux[1] = 0;
	fis_intrare = fopen("tema3.in", "r");
	fis_iesire = fopen("tema3.out", "w");
	if (strcmp(argv[1], sir_aux) == 0) { // daca am primul task
		fscanf(fis_intrare, "%d%d%d", &nr_rute, &nr_ani, &grad_uzura);
		fscanf(fis_intrare, "%c", &aux); // citesc terminatorul de sir
		nr_orase = 0; // initial nu am orase
		sir1 = calloc(100, sizeof(char));
		sir2 = calloc(100, sizeof(char));
		if (sir1 == NULL || sir2 == NULL) {
			printf("err");
			return 0;
		}
		for (i = 0; i <= nr_rute - 1; i++) {
			fscanf(fis_intrare, "%s", sir1);
			index1 = -1; // presupun initial ca nu exista in vectorul de orase
			for (j = 0; j <= nr_orase - 1; j++)
				if (strcmp(sir1, orase[j]) == 0) {
					index1 = j;
					j = nr_orase - 1;
				}
			// pentru primul sir citit tb sa caut daca mai exista nodul coresp. pana in punctul asta
			fscanf(fis_intrare, "%c", &aux); // spatiu
			fscanf(fis_intrare, "%s", sir2);
			index2 = -1;
			for (j = 0; j <= nr_orase - 1; j++)
				if (strcmp(sir2, orase[j]) == 0) {
					index2 = j;
					j = nr_orase - 1;
				}
			if (index1 == -1 && index2 == -1) // cazul in care ambele siruri apar pt prima data (indecsii au ramas -1)
				ambele_noi(graf, orase, &nr_orase, sir1, sir2, fis_intrare, i);
			else if (index2 == -1) // daca doar al doilea sir e nou
					una_noua(graf, orase, &nr_orase, index1, sir2, fis_intrare, 0, i);
				else if (index1 == -1) // doar primul sir e nou
						una_noua(graf, orase, &nr_orase, index2, sir1, fis_intrare, 1, i);
					else ambele_vechi(graf, index1, index2, fis_intrare, i); // ambele exista deja
		}
		modif_degradari(graf, nr_orase, nr_ani); // modific degradarile dupa regulile specificate
		int ok, l;
		nr_indici = 0, k = 0;
		for (l = 0; l <= nr_rute - 1; l++) { // caut fiecare ruta citita, ca sa le afisez pe rand
			ok = 0; // nu am gasit inca ruta cu numarul dorit
			for (i = 0; i <= nr_orase - 1 && ok == 0; i++) {
				p = graf[i];
				while (p != NULL && ok == 0) {
					if (p->nr_drum == l && p->sursa == 0) {
						ok = 1; // odata ce am gasit ruta dorita ies din for
						k++; // in k retin nr de rute ale caror medii imi convin
						fprintf(fis_iesire, "%s ", orase[i]);
						fprintf(fis_iesire, "%s ", orase[p->nod_ad]); // afisez numele oraselor capete
						fprintf(fis_iesire, "%d ", p->nr_tronsoane); // si nr de tronsoane pt fiecare
						suma = 0;
						for (j = 0; j <= p->nr_tronsoane - 1; j++) {
							fprintf(fis_iesire, "%.02f ", p->degradari[j]);
							suma += p->degradari[j]; // afisez degradarile si fac suma tronsoanelor dintre cele 2 simultan
						}
						suma /= p->nr_tronsoane; // suma devine media
						if (suma < grad_uzura) // daca am media degradarilor mai mica pun indicele coresp. in vect. de indici
							indici[nr_indici++] = k;
						fprintf(fis_iesire, "\n");
					}
					p = p->urm;
				}
			}
		}
		for (i = 0; i <= nr_indici - 1; i++)
			fprintf(fis_iesire, "%d ", indici[i]); // in final afisez vectorul de indici buni
		if (nr_indici != 0)
			fprintf(fis_iesire, "\n");
	}
	else {
		nr_orase = 0;
		orase[0] = calloc(100, sizeof(char)); // imi aloc memorie pt primul oras
		// aici consider primul oras cel din care incepe calcularea drumurilor de lg max
		if (orase[0] == NULL) {
			printf("err");
			return 0;
		}
		nr_orase++; // am adaugat un oras
		sir1 = calloc(100, sizeof(char));
		sir2 = calloc(100, sizeof(char));
		if (sir1 == NULL || sir2 == NULL) {
			printf("err");
			return 0;
		}
		fscanf(fis_intrare, "%s", orase[0]);
		graf[0] = NULL;
		fscanf(fis_intrare, "%d", &nmax_rute);
		fscanf(fis_intrare, "%d", &nr_rute);
		for (i = 0; i <= nr_rute - 1; i++) {
			fscanf(fis_intrare, "%s", sir1);
			fscanf(fis_intrare, "%c", &aux); // spatiu
			fscanf(fis_intrare, "%s", sir2);
			index1 = -1, index2 = -1;
			for (j = 0; j <= nr_orase - 1; j++)
				if (strcmp(orase[j], sir1) == 0) {
					index1 = j;
					j = nr_orase;
				}
			for (j = 0; j <= nr_orase - 1; j++)
				if (strcmp(orase[j], sir2) == 0) {
					index2 = j;
					j = nr_orase;
				}
			// caut dc mai exista sirurile citite in vectorul de orase sau nu
			if (index1 == -1 && index2 == -1) { // dc niciunul nu exista
				orase[nr_orase] = calloc(100, sizeof(char));
				orase[nr_orase + 1] = calloc(100, sizeof(char));
				if (orase[nr_orase] == NULL || orase[nr_orase + 1] == NULL) {
					printf("err");
					return 0;
				}
				strcpy(orase[nr_orase], sir1);
				strcpy(orase[nr_orase + 1], sir2);
				graf[nr_orase] = calloc(1, sizeof(TCelula));
				if (graf[nr_orase] == NULL) {
					printf("err");
					return 0;
				}
				graf[nr_orase]->nod_ad = nr_orase + 1;
				fscanf(fis_intrare, "%d", &graf[nr_orase]->distanta);
				graf[nr_orase]->nr_drum = i;
				graf[nr_orase]->sursa = 0;
				graf[nr_orase]->urm = NULL;
				graf[nr_orase + 1] = calloc(1, sizeof(TCelula));
				if (graf[nr_orase + 1] == NULL) {
					printf("err");
					return 0;
				}
				graf[nr_orase + 1]->nod_ad = nr_orase;
				graf[nr_orase + 1]->distanta = graf[nr_orase]->distanta;
				graf[nr_orase + 1]->nr_drum = i;
				graf[nr_orase + 1]->sursa = 1;
				graf[nr_orase + 1]->urm = NULL;
				nr_orase += 2;
			}
			else
				if (index1 == -1) { // dc primul nu exista
					orase[nr_orase] = calloc(100, sizeof(char));
					if (orase[nr_orase] == NULL) {
						printf("err");
						return 0;
					}
					strcpy(orase[nr_orase], sir1);
					graf[nr_orase] = calloc(1, sizeof(TCelula));
					if (graf[nr_orase] == NULL) {
						printf("err");
						return 0;
					}
					graf[nr_orase]->nod_ad = index2;
					fscanf(fis_intrare, "%d", &graf[nr_orase]->distanta);
					graf[nr_orase]->sursa = 0;
					graf[nr_orase]->nr_drum = i;
					graf[nr_orase]->urm = NULL;
					p = calloc(1, sizeof(TCelula));
					if (p == NULL) {
						printf("err");
						return 0;
					}
					p->nod_ad = nr_orase;
					p->sursa = 1;
					p->nr_drum = i;
					p->urm = NULL;
					if (graf[index2] == NULL)
						graf[index2] = p;
					else {
						q = graf[index2];
						while (q->urm != NULL)
							q = q->urm;
						q->urm = p;
					}
					nr_orase++;
				}
				else
					if (index2 == -1) { // dc al doilea nu exista
						orase[nr_orase] = calloc(100, sizeof(char));
						if (orase[nr_orase] == NULL) {
							printf("err");
							return 0;
						}
						strcpy(orase[nr_orase], sir2);
						p = calloc(1, sizeof(TCelula));
						if (p == NULL) {
							printf("err");
							return 0;
						}
						p->nod_ad = nr_orase;
						fscanf(fis_intrare, "%d", &p->distanta);
						p->sursa = 0;
						p->nr_drum = i;
						p->urm = NULL;
						if (graf[index1] == NULL)
							graf[index1] = p;
						else {
							q = graf[index1];
							while (q->urm != NULL)
								q = q->urm;
							q->urm = p;
						}
						graf[nr_orase] = calloc(1, sizeof(TCelula));
						if (graf[nr_orase] == NULL) {
							printf("err");
							return 0;
						}
						graf[nr_orase]->nod_ad = index1;
						graf[nr_orase]->distanta = p->distanta;
						graf[nr_orase]->sursa = 1;
						graf[nr_orase]->nr_drum = i;
						graf[nr_orase]->urm = NULL;
						nr_orase++;
					}
					else {
						// aici exista ambele siruri
						p = calloc(1, sizeof(TCelula));
						if (p == NULL) {
							printf("err");
							return 0;
						}
						p->nod_ad = index2;
						fscanf(fis_intrare, "%d", &p->distanta);
						p->sursa = 0;
						p->nr_drum = i;
						p->urm = NULL;
						if (graf[index1] == NULL)
							graf[index1] = p;
						else {
							q = graf[index1];
							while (q->urm != NULL)
								q = q->urm;
							q->urm = p;
						}
						p = calloc(1, sizeof(TCelula));
						if (p == NULL) {
							printf("err");
							return 0;
						}
						p->nod_ad = index1;
						p->distanta = q->urm->distanta;
						p->sursa = 1;
						p->nr_drum = i;
						p->urm = NULL;
						if (graf[index2] == NULL)
							graf[index2] = p;
						else {
							q = graf[index2];
							while (q->urm != NULL)
								q = q->urm;
							q->urm = p;
						}
					}
		}
		// pana aici am aprox. aceleasi adaugari in graf si in vectorul de orase ca la task ul 1
		// doar ca aici am citiri diferite
		dijkstra(graf, nr_orase, nmax_rute, orase, fis_iesire); // aplic dijkstra pe graf
	}
	//valgrind ul:
	free(sir1);
	free(sir2);
	for (i = 0; i <= nr_orase - 1; i++)
		free(orase[i]);
	for (i = 0; i <= nr_orase - 1; i++) {
		p = graf[i];
		while (p != NULL) {
			q = p;
			p = p->urm;
			free(q);
		}
	}
	return 0;
}