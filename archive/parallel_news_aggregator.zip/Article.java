import java.util.*;

public class Article {
    String uuid, title, author, url, text, published, language;
    List<String> categories;
    public Article(String uuid, String title, String author, String url, String text, String published, String language, List<String> categories) {
        this.uuid = uuid;
        this.title = title;
        this.author = author;
        this.url = url;
        this.text = text;
        this.published = published;
        this.language = language;
        this.categories = categories;
    }
}
