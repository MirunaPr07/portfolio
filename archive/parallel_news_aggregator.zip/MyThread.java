import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.BrokenBarrierException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class MyThread extends Thread {
    int index, nrThreads, nrArticles;
    String fisSuplim;
    List<String> dateArticles;
    // fiecare thread are lista lui de articole, asa ca nu vom avea probleme de tipul
    // accesarii resurselor simultan
    List<Article> localArticles = new ArrayList<>();
    public MyThread(int index, int nrThreads, int nrArticles, List<String> dateArticles, String fisSuplim) {
        this.index = index;
        this.nrThreads = nrThreads;
        this.nrArticles = nrArticles;
        this.fisSuplim = fisSuplim;
        this.dateArticles = dateArticles;
    }
    public void run() {
        // fiecare thread are asociati niste indecsi in lista de fisiere JSON
        // calculati cu start si end, ca in lab:
        int start, end;
        start = this.index * this.nrArticles / this.nrThreads;
        end = (this.index + 1) * this.nrArticles / this.nrThreads;
        if (end > this.nrArticles)
            end = this.nrArticles;
        JSONParser parser = new JSONParser();
        // map uri locale specifice fiecarui thread, in care retin:
        // pentru fiecare uuid, de cate ori apare, pentru fiecare titlu de cate ori apare
        // ca dupa sa nu iau in calcul niciun articol care are duplicat dupa title/uuid in var globala:
        Map<String, Integer> localUuidFrecv = DateGestionate.uuidFrecvPerThread.get(this.index);
        Map<String, Integer> localTitleFrecv = DateGestionate.titleFrecvPerThread.get(this.index);
        // ca un fel de dictionare din python in care am perechi de string si intreg
        for (int i = start; i <= end - 1; i++) {
            String pathCrt = this.dateArticles.get(i);
            try {
                // continutul fisierului json curent:
                String content = new String(Files.readAllBytes(Paths.get(pathCrt)));
                JSONArray articole = (JSONArray) parser.parse(content); // iau si parsez continutul ca un array de articole
                for (Object o : articole) {
                    JSONObject art = (JSONObject) o;
                    String uuid, title, author, url, text, published, language;
                    uuid = (String) art.get("uuid");
                    title = (String) art.getOrDefault("title", "");
                    author = (String) art.getOrDefault("author", "");
                    url = (String) art.get("url");
                    text = (String) art.getOrDefault("text", "");
                    published = (String) art.getOrDefault("published", "");
                    language = (String) art.getOrDefault("language", "");

                    JSONArray categoriiJson = (JSONArray) art.get("categories");
                    List<String> categories = new ArrayList<>();
                    if (categoriiJson != null) {
                        for (Object cat : categoriiJson)
                            categories.add((String) cat); // le trec in string uri pe rand
                    }
                    Article a = new Article(uuid, title, author, url, text, published, language, categories);
                    this.localArticles.add(a); // dupa ce am creat noul articol cu toate datele, il adaug si in struct locala
                    DateGestionate.allArticles.add(a); // si in cea globala!!
                    // apoi actualizez frecventele in local
                    localUuidFrecv.put(uuid, localUuidFrecv.getOrDefault(uuid, 0) + 1);
                    localTitleFrecv.put(title, localTitleFrecv.getOrDefault(title, 0) + 1);
                }
            } catch (IOException | ParseException e) {
                e.printStackTrace();
            }
        }
        // neap astept ca toate thread urile sa termine de extras informatia si de actualizat variabilele!!
        try {
            DateGestionate.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }
        // las ca thread ul 0 sa imi actualizeze var globale de frecvente cu ce am calculat pana acum:
        if (this.index == 0)
            DateGestionate.combineFrequencies();
        try {
            DateGestionate.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }
        // astept sa se termine de actual. si frecventele, pt ca voi avea nev de ele mai departe
        for (Article a : this.localArticles) {
            Integer u, t;
            u = DateGestionate.uuidFrecv.get(a.uuid);
            t = DateGestionate.titleFrecv.get(a.title);
            // aici ignor orice nu are frecventa de intalnire a uuid/title egala cu 1:
            if (u != null && u == 1 && t != null && t == 1) { // completez categ, limbile si cuvintele doar daca frecv e 1!!
                // actualizezi var globale pt categorii, limbi si cuv din DateGestionate:
                for (String cat : a.categories)
                    if (DateGestionate.categories.contains(cat))
                        DateGestionate.completeaza_categoriesUuid(cat, a.uuid);
                if (DateGestionate.languages.contains(a.language))
                    DateGestionate.completeaza_limbiUuid(a.language, a.uuid);
                // procesez cuvintele din articol doar daca e in engleza!!!! uitasem de verif aici!!
                if (a.language.equalsIgnoreCase("english"))
                    DateGestionate.proceseazaCuvinte(a, this.index);
            }
        }
        try {
            DateGestionate.barrier.await();
        } catch (BrokenBarrierException | InterruptedException e) {
            e.printStackTrace();
        }
        // am completat toate structurile pentru fiecare thread => pot sa actual. fisierele de iesire
        // thread ul 0 face scrierile in fisiere:
        if (this.index == 0) {
            DateGestionate.combinaCuvinte();
            DateGestionate.scrieFisiereCategorii();
            DateGestionate.scrieFisiereLimbi();
            DateGestionate.scrieFisierGlobal();
            DateGestionate.scrieFisiereWords();
            DateGestionate.scrieRaport();
        }
    }
}
