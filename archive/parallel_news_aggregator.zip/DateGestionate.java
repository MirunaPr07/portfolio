import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CyclicBarrier;

public class DateGestionate {
    public static CyclicBarrier barrier;
    // toate articolele citite: e synchronized, deci thread urile o pot actualiza simultan fara problema
    public static List<Article> allArticles = Collections.synchronizedList(new ArrayList<>());
    // frecventele globale pentru uuid si title(populate abia dupa ce se combina frecventele locale)
    // doar thread ul 0 le modifica, restul doar citesc rezultatul
    public static Map<String, Integer> uuidFrecv = new HashMap<>();
    public static Map<String, Integer> titleFrecv = new HashMap<>();
    // frecv locale organizate pe fiecare thread:
    public static List<Map<String, Integer>> uuidFrecvPerThread;
    public static List<Map<String, Integer>> titleFrecvPerThread;
    // datele populate in main, apoi folosite doar pentru citire:
    public static List<String> languages = new ArrayList<>();
    public static List<String> categories = new ArrayList<>();
    public static List<String> linking_words = new ArrayList<>();
    // set cu cuvintele de legatura, pt verif rapida
    public static Set<String> linkingWordsSet = new HashSet<>();
    // categorie: lista de uuid uri (completez din thread uri, de asta folosesc ConcurrentHashMap)
    public static ConcurrentHashMap<String, List<String>> categoriesUuid = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, List<String>> languagesUuid = new ConcurrentHashMap<>(); // tot lista de uuid uri
    // map global pentru cuvnite: pt fiecare am nr de articole bune in care apare
    // e populat dupa ce se comb map urile locale wordCountPerThread
    public static Map<String, Integer> wordCount = new HashMap<>();
    public static List<Map<String, Integer>> wordCountPerThread;

    public static void populeaza_liste(List<String> listaPaths) {
        String pathLanguage, pathCategory, pathLinking;
        pathLanguage = listaPaths.get(0);
        pathCategory = listaPaths.get(1);
        pathLinking = listaPaths.get(2);
        try (BufferedReader br = new BufferedReader(new FileReader(pathLanguage))) {
            int nrCrt;
            nrCrt = Integer.parseInt(br.readLine().trim());
            for (int i = 0; i <= nrCrt - 1; i++)
                DateGestionate.languages.add(br.readLine().trim());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedReader br = new BufferedReader(new FileReader(pathCategory))) {
            int nrCrt;
            nrCrt = Integer.parseInt(br.readLine().trim());
            for (int i = 0; i <= nrCrt - 1; i++)
                DateGestionate.categories.add(br.readLine().trim());
        } catch (IOException e) {
            e.printStackTrace();
        }
        try (BufferedReader br = new BufferedReader(new FileReader(pathLinking))) {
            int nrCrt;
            nrCrt = Integer.parseInt(br.readLine().trim());
            for (int i = 0; i <= nrCrt - 1; i++) {
                String w;
                w = br.readLine().trim().toLowerCase();
                if (w != null) {
                    DateGestionate.linking_words.add(w);
                    DateGestionate.linkingWordsSet.add(w);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    // initializez toate structurile per fiecare thread(frevente uuid/ title si word count)
    public static void initPerThreadData(int nrThreads) {
        DateGestionate.wordCountPerThread = new ArrayList<>(nrThreads);
        DateGestionate.uuidFrecvPerThread = new ArrayList<>(nrThreads);
        DateGestionate.titleFrecvPerThread = new ArrayList<>(nrThreads);

        for (int i = 0; i <= nrThreads - 1; i++) {
            DateGestionate.wordCountPerThread.add(new HashMap<>());
            DateGestionate.uuidFrecvPerThread.add(new HashMap<>());
            DateGestionate.titleFrecvPerThread.add(new HashMap<>());
        }
    }
    public static void combineFrequencies() { // combin frecventele locale in map urile globale
        // fct asta o fac sa o apeleze doar thread ul 0
        DateGestionate.uuidFrecv.clear();
        DateGestionate.titleFrecv.clear();
        for (Map<String, Integer> local : uuidFrecvPerThread)
            for (Map.Entry<String, Integer> e : local.entrySet())
                DateGestionate.uuidFrecv.merge(e.getKey(), e.getValue(), Integer::sum);
        for (Map<String, Integer> local : titleFrecvPerThread)
            for (Map.Entry<String, Integer> e : local.entrySet())
                DateGestionate.titleFrecv.merge(e.getKey(), e.getValue(), Integer::sum);
    }

    public static void completeaza_categoriesUuid(String category, String uuid) {
        // adaug perechea de categorie noua si o noua lista daca nu exista deja cheia asta
        // si daca da, adaug noul uuid in lista
        DateGestionate.categoriesUuid.computeIfAbsent(category, k -> Collections.synchronizedList(new ArrayList<>())).add(uuid);
    }
    public static void completeaza_limbiUuid(String limba, String uuid) {
        DateGestionate.languagesUuid.computeIfAbsent(limba, k -> Collections.synchronizedList(new ArrayList<>())).add(uuid);
    }

    public static void scrieFisiereCategorii() {
        for (String cat : DateGestionate.categories) {
            List<String> uuids = DateGestionate.categoriesUuid.get(cat);
            if (uuids == null || uuids.isEmpty()) // daca nu am nimic in uuids sau pentru categ asta nu am niciun uuid, sar peste
                continue;
            // ma asigur ca elimin duplicatele de uuids printr o trecere din list in set si inapoi in list
            Set<String> setUuids = new HashSet<>(uuids);
            List<String> listaUnica = new ArrayList<>(setUuids);
            Collections.sort(listaUnica); // sortare lexicografica
            String fileNew = cat.replace(",", "").trim().replaceAll("\\s+", "_");
            fileNew += ".txt";
            try (PrintWriter pw = new PrintWriter(new FileWriter(fileNew))) {
                for (String aux : listaUnica)
                    pw.println(aux);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public static void scrieFisiereLimbi() {
        for (String limba : DateGestionate.languages) {
            List<String> uuids = languagesUuid.get(limba);
            if (uuids == null || uuids.isEmpty())
                continue;
            Collections.sort(uuids);
            String fileNew = limba + ".txt";
            try (PrintWriter pw = new PrintWriter(new FileWriter(fileNew))) {
                for (String aux : uuids)
                    pw.println(aux);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void scrieFisierGlobal() {
        List<Article> lista = new ArrayList<>();
        synchronized (DateGestionate.allArticles) {
            for (Article a : DateGestionate.allArticles) {
                Integer u, t;
                u = DateGestionate.uuidFrecv.get(a.uuid);
                t = DateGestionate.titleFrecv.get(a.title);
                if (u != null && t != null && u == 1 && t == 1) // cele care nu au frecventa exact 1 nu ma intereseaza
                    lista.add(a);
            }
        }
        Collections.sort(lista, (a1, a2) -> {
            int cmp;
            cmp = a2.published.compareTo(a1.published); // descresc dupa published
            if (cmp != 0)
                return cmp;
            // la egalitate, cresc dupa uuid
            return a1.uuid.compareTo(a2.uuid);
        });
        try (PrintWriter pw = new PrintWriter(new FileWriter("all_articles.txt"))) {
            for (Article a : lista)
                pw.println(a.uuid + " " + a.published);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void combinaCuvinte() {
        DateGestionate.wordCount.clear();
        for (Map<String, Integer> local : DateGestionate.wordCountPerThread)
            for (Map.Entry<String, Integer> e : local.entrySet())
                DateGestionate.wordCount.merge(e.getKey(), e.getValue(), Integer::sum);
    }
    // procesez textul unui articol in engleza si actualizez map ul local de cuvinte
    public static void proceseazaCuvinte(Article a, int threadId) {
        if (a.text == null || a.text.isEmpty() == true)
            return;
        Map<String, Integer> localMap = DateGestionate.wordCountPerThread.get(threadId);
        String[] despartit;
        despartit = a.text.toLowerCase().split("\\s+");
        Set<String> cuvinteCrt = new HashSet<>();
        for (String s : despartit) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i <= s.length() - 1; i++) {
                char c;
                c = s.charAt(i);
                // verif doar intre caract litere mici, pt ca i am dat mai devreme tolower
                if (c >= 'a' && c <= 'z') // verif asa, nu cu isletter!!!
                    sb.append(c);
            }
            String cuv;
            cuv = sb.toString();
            // daca eliminand ce e prost nu mi a ramas nimic din cuv/ se afla pe lista de cuvinte ce tb ignorate, sar peste
            if (cuv.isEmpty() == true || DateGestionate.linkingWordsSet.contains(cuv))
                continue;
            cuvinteCrt.add(cuv);
        }
        for (String cuv : cuvinteCrt)
            localMap.put(cuv, localMap.getOrDefault(cuv, 0) + 1);
    }

    public static void scrieFisiereWords() {
        List<String> lista = new ArrayList<>(DateGestionate.wordCount.keySet());
        Collections.sort(lista, new Comparator<String>() {
            public int compare(String cuv1, String cuv2) {
                int count1, count2;
                count1 = DateGestionate.wordCount.get(cuv1);
                count2 = DateGestionate.wordCount.get(cuv2);
                if (count1 != count2) // descresc dupa nr de articole
                    return Integer.compare(count2, count1);
                return cuv1.compareTo(cuv2); // sau cresc dupa cuv la egalitate
            }
        });
        try (PrintWriter pw = new PrintWriter(new FileWriter("keywords_count.txt"))) {
            for (String cuv : lista) {
                int crtNr;
                crtNr = DateGestionate.wordCount.get(cuv);
                pw.println(cuv + " " + crtNr);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void scrieRaport() {
        List<Article> lista = new ArrayList<>(); // lista cu art unice
        synchronized (DateGestionate.allArticles) {
            for (Article a : DateGestionate.allArticles) {
                Integer u, t;
                u = DateGestionate.uuidFrecv.get(a.uuid);
                t = DateGestionate.titleFrecv.get(a.title);
                if (u != null && t != null && u == 1 && t == 1)
                    lista.add(a);
            }
        }
        int unique = lista.size();
        int duplicates = allArticles.size() - unique;

        Map<String, Integer> authorCount = new HashMap<>();
        Map<String, Integer> languageCount = new HashMap<>();
        Map<String, Integer> categoryCount = new HashMap<>();
        Article mostRecent = null;
        for (Article a : lista) {
            String author = a.author;
            String lang = a.language;
            authorCount.put(author, authorCount.getOrDefault(author, 0) + 1); // ori il creez, ori incrementez valoarea
            languageCount.put(lang, languageCount.getOrDefault(lang, 0) + 1);
            if (a.categories != null) {
                Set<String> catUnice = new HashSet<>(); // set ca sa fie unice!!
                for (String cat : a.categories)
                    if (DateGestionate.categories.contains(cat))
                        catUnice.add(cat);
                for (String cat : catUnice)
                    categoryCount.put(cat, categoryCount.getOrDefault(cat, 0) + 1);
            }
            if (mostRecent == null) {
                mostRecent = a;
            } else {
                String p1, p2;
                p1 = a.published;
                p2 = mostRecent.published;
                int cmp;
                cmp = p1.compareTo(p2);
                // vad daca merita sa il retin pe asta curent, dupa regula:
                if (cmp > 0 || (cmp == 0 && a.uuid.compareTo(mostRecent.uuid) < 0))
                    mostRecent = a;
            }
        }
        String bestAuthor = "";
        int bestAuthorCount = 0;
        boolean first = true;
        for (String a : authorCount.keySet()) {
            int c;
            c = authorCount.get(a);
            if (first == true || c > bestAuthorCount || (c == bestAuthorCount && a.compareTo(bestAuthor) < 0)) {
                bestAuthor = a;
                bestAuthorCount = c;
                first = false;
            }
        }
        String topLang = "";
        int topLangCount = 0;
        first = true;
        for (String l : languageCount.keySet()) {
            int c;
            c = languageCount.get(l);
            if (first == true || c > topLangCount || (c == topLangCount && l.compareTo(topLang) < 0)) {
                topLang = l;
                topLangCount = c;
                first = false;
            }
        }
        String topCat = "";
        int topCatCount = 0;
        first = true;
        for (String cat : categoryCount.keySet()) {
            int c;
            c = categoryCount.get(cat);
            if (first == true || c > topCatCount || (c == topCatCount && cat.compareTo(topCat) < 0)) {
                topCat = cat;
                topCatCount = c;
                first = false;
            }
        }
        if (topCat.isEmpty() == false)
            topCat = topCat.replace(",", "").trim().replaceAll("\\s+", "_");

        String topWord = "";
        int topWordCount = 0;
        first = true;
        for (String cuv : DateGestionate.wordCount.keySet()) {
            int c;
            c = DateGestionate.wordCount.get(cuv);
            if (first == true || c > topWordCount || (c == topWordCount && cuv.compareTo(topWord) < 0)) {
                topWord = cuv;
                topWordCount = c;
                first = false;
            }
        }

        try (PrintWriter pw = new PrintWriter(new FileWriter("reports.txt"))) {
            pw.println("duplicates_found - " + duplicates);
            pw.println("unique_articles - " + unique);
            pw.println("best_author - " + bestAuthor + " " + bestAuthorCount);
            pw.println("top_language - " + topLang + " " + topLangCount);
            pw.println("top_category - " + topCat + " " + topCatCount);
            pw.println("most_recent_article - " + mostRecent.published + " " + mostRecent.url);
            pw.println("top_keyword_en - " + topWord + " " + topWordCount);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
