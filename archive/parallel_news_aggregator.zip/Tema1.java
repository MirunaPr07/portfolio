import java.io.*;
import java.util.*;
import java.util.concurrent.CyclicBarrier;

public class Tema1 {
    public static void main(String[] args) {
        int nrThreads, nrArticles = 0;
        String fisArticole, fisSuplim;
        // aici salvez path urile catre fisierele JSON cu articole inauntru:
        List<String> dateArticles = new ArrayList<>();
        List<String> pathFisiereSuplim = new ArrayList<>();
        // in args[0] primesc numarul de thread uri, in args[1] path ul lui articles.txt,
        // iar in args[2] path ul lui inputs
        nrThreads = Integer.parseInt(args[0]);
        fisArticole = args[1];
        fisSuplim = args[2];
        DateGestionate.barrier = new CyclicBarrier(nrThreads);
        try (BufferedReader br = new BufferedReader(new FileReader(fisArticole))) { // citesc fisierul si constr path ul complet pentru fiecare JSON in parte
            nrArticles = Integer.parseInt(br.readLine().trim());
            File fArticol = new File(fisArticole);
            // directorul de baza al fisierului:
            String baseArtDir = fArticol.getParent();
            for (int i = 0; i <= nrArticles - 1; i++) {
                String pathCrt = br.readLine().trim();
                // mai apoi construiesc path ul relativ la directorul de baza, cel final
                File realPath = new File(baseArtDir, pathCrt);
                dateArticles.add(realPath.getPath()); // si adaug toate path urile in structura mea
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // la fel ca mai sus, ca sa accesez fisierele suplimentare:
        try (BufferedReader br = new BufferedReader(new FileReader(fisSuplim))) {
            int nrFisSuplim = Integer.parseInt(br.readLine().trim()); // nu o sa il mai fol
            File fSuplim = new File(fisSuplim);
            String baseSupDir = fSuplim.getParent();
            for (int i = 0; i <= nrFisSuplim - 1; i++) {
                String pathCrt = br.readLine().trim();
                File realPath = new File(baseSupDir, pathCrt);
                pathFisiereSuplim.add(realPath.getPath());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // am ales sa fac in main partea de populare a variabilelor globale
        DateGestionate.populeaza_liste(pathFisiereSuplim);
        DateGestionate.initPerThreadData(nrThreads); // si initializarea var. pentru fiecare thread
        MyThread[] vectThread = new MyThread[nrThreads];
        for (int i = 0; i <= nrThreads - 1; i++) {
            vectThread[i] = new MyThread(i, nrThreads, nrArticles, dateArticles, fisSuplim);
            vectThread[i].start();
        }
        for (int i = 0; i <= nrThreads - 1; i++) {
            try {
                vectThread[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
