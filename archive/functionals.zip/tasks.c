#include "functional.h"
#include "tasks.h"
#include "tests.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
// nu pot deloc for uri nici in functiile de le voi trimite ca parametru
//callee = eliberez eu in functie dupa ce apelez functionala
//caller = elibereze functionala
//mai bine ma gandesc mai tarziu la reverse

//inc functii get_passing_students
boolean trecere(void *element) {
	//elementul meu este de tip student_t
	student_t *stud;
	stud = (student_t *)element;
	if (stud->grade >= 5.0)
		return 1;
	return 0;
}

//sfarsit functii get_passing_students
//inceput functii create_number_array
void distruge_struct(void *p) {
	//distrug un element de tip number_t
	number_t *aux;
	aux = (number_t *)p;
	free(aux->string);
}

void numere(void *elem, void **p) {
	char **c;
	c = (char **)p; //c pointeaza unde pointeaza si p
	int *intr1, *intr2;
	intr1 = (int *)c[0];
	intr2 = (int *)c[1];
	//de int urile intr1 si intr2 ma folosesc ca sa creez noul element
	number_t *nou;
	nou = (number_t *)elem;
	nou->integer_part = *intr1;
	nou->fractional_part = *intr2;
	nou->string = (char *)malloc(20 * sizeof(char));
	sprintf(nou->string, "%d.%d", *intr1, *intr2);
}

//sfarsit functii create_number_array
//inc functii bigger_sum

void adunare(void *acumulator, void *elem) {
	int *acc_int, *elem_int;
	acc_int = (int *)acumulator;
	elem_int = (int *)elem;
	*acc_int = *acc_int + *elem_int;
}

void sume(void *nou, void *vechi) { //vechi reprezinta efectiv
	//un element de tip lista array_t cu int uri
	//imi modifica elementul de la pointerul nou
	//il face ceva in functie de pointerul vechi
	int acumulator;
	//voi face ca nou sa aiba valoarea acumulatorului
	acumulator = 0;
	reduce(&adunare, (void *)&acumulator, *((array_t *)vechi));
	//functia reduce imi va modifica acumulatorul
	int *nou_int;
	nou_int = (int *)nou;
	*nou_int = acumulator;
}

void diferenta(void *elem_nou, void **p) {
	//p e un vector de pointeri catre elemente
	boolean *elem_nou_bool;
	char **point;
	int *elem1, *elem2;
	elem_nou_bool = (boolean *)elem_nou;
	point = (char **)p;
	elem1 = (int *)point[0];
	elem2 = (int *)point[1];
	if (*elem1 >= *elem2)
		*elem_nou_bool = 1;
	else
		*elem_nou_bool = 0;
}

//sf functii bigger_sum
//inceput functii reverse

void consecutiv(void *elem) {
	int *current;
	current = (int *)elem;
	if (*current == 1)
		return;
	int *anterior;
	anterior = current - 1; //ma duc cu un int inapoi
	*current = *anterior + 1;
}

void acelasi(void *p) {
	int *current, *anterior;
	current = (int *)p;
	anterior = current - 1;
	if (*current == 0)
		*current = *anterior;
}

void invers(void **p) {
	char **c;
	c = (char **)p;
	int *elem_vechi, *indice, *ultim, *elem_nou;
	elem_vechi = (int *)c[0];
	indice = (int *)c[1];
	ultim = (int *)c[2];
	elem_nou = (int *)c[3];
	*elem_nou = *(elem_vechi + *ultim - 2 * (*(indice) - 1));
	//scad o data valoarea
	//de la indice -1 ca sa ma raportez la inceputul listei(primul element)
}

//sfarsit functii reverse

array_t reverse(array_t list) {
	array_t indici;
	indici.len = list.len;
	indici.elem_size = list.elem_size;
	indici.destructor = NULL;
	indici.data = (int *)calloc(list.elem_size, list.len);
	int *primul;
	primul = (int *)indici.data;
	*primul = 1;
	for_each(&consecutiv, indici);
	array_t last;
	last.destructor = NULL;
	last.elem_size = list.elem_size;
	last.len = list.len;
	last.data = (int *)calloc(list.elem_size, list.len);
	primul = (int *)last.data;
	*primul = list.len - 1;
	for_each(&acelasi, last);
	array_t new_list;
	new_list.destructor = NULL;
	new_list.elem_size = list.elem_size;
	new_list.len = list.len;
	new_list.data = (int *)calloc(list.elem_size, list.len);
	for_each_multiple(&invers, 4, list, indici, last, new_list);
	//ar trebui aici sa eliberez spatiul de la indici si last
	free(indici.data);
	free(last.data);
	return new_list;
}

//mai bine ma gandesc mai tarziu la create_number_array
array_t create_number_array(array_t integer_part, array_t fractional_part) {
	//parcurg in paralel cele doua liste si o creez pe a treia
	//folosindu ma de valorile din primele ->map_multiple
	//presupun ca atunci cand se zice ca cele doua liste sunt de intregi
	//se refera la int
	array_t new_list;
	new_list = map_multiple(&numere, sizeof(number_t), &distruge_struct,
							2, integer_part, fractional_part);
	return new_list;
	//(void)integer_part;
	//(void)fractional_part;
	//return (array_t){0};
}

array_t get_passing_students_names(array_t list) {
	//un filter ca sa creez lista in care imi raman doar
	//elem pt care e satisfacuta conditia
	//dupa un map ca sa creez o noua lista in care sa pun
	//doar o parte din argumentul listei ramase dupa filter
	//nu imi mai trebuie niciun map-> prost scris enuntul
	//returnez o lista cu elementele de tip student_t
	//si doar afiseaza ei partea de nume
	array_t elem_bune; //lista in care retin elementele bune
	elem_bune = filter(&trecere, list);
	return elem_bune;
}

array_t check_bigger_sum(array_t list_list, array_t int_list) {
	//cu map parcurg fiecare element al listei mari
	//incerc sa imi creez cu acest map o lista noua
	//ce sa contina elemente de tip int coresp. sumei
	//fiecarei mini-liste
	array_t list_sum;
	list_sum = map(&sume, sizeof(int), NULL, list_list);
	//mi am creat lista care contine sumele
	//trebuie sa verific mereu dif. intre list_sum si
	//int_list
	array_t binary;
	binary = map_multiple(&diferenta, sizeof(boolean), NULL,
						  2, list_sum, int_list);
	return binary;
}

//inceput functii even_index

void siruri_bune(void *acumulator, void **p) {
	char **current, *sir;
	int *intreg;
	current = (char **)p;
	sir = (char *)current[0];
	intreg = (int *)current[1];
	if (((*intreg) - 1) % 2 != 0) {
		//free(sir);
		return;
	}
	//acum daca e para
	//printf("%s\n", sir);
	array_t *acc;
	acc = (array_t *)acumulator;
	char *elem;
	elem = (char *)(*acc).data;
	elem += (*acc).elem_size * (*acc).len;
	strcpy(elem, sir);
	(*acc).len++;
}

void elib(void *p) {
	char **x;
	x = (char **)p;
	free(*x);
}

//sfarsit functii even_index
//pare usoara

array_t get_even_indexed_strings(array_t list) {
	array_t indici;
	indici.len = list.len;
	indici.elem_size = sizeof(int);
	indici.destructor = NULL;
	indici.data = (int *)calloc(indici.len, indici.elem_size);
	int *p;
	p = (int *)indici.data;
	*p = 1;
	for_each(&consecutiv, indici);
	array_t acumulator;
	acumulator.destructor = list.destructor;
	acumulator.elem_size = list.elem_size;
	acumulator.len = 0;
	acumulator.data = (char *)calloc(list.len, sizeof(char *));
	reduce_multiple(&siruri_bune, &acumulator, 2, list, indici);
	free(indici.data);
	//for_each(&elib, list);
	//free(list.data);
	return acumulator;
}

//inceput functii generate_square_matrix

void fiecare(void *elem_lista_mica) {
	//in functia asta sa fac doar alocarea fiecarui element mic??
	array_t *current;
	current = (array_t *)elem_lista_mica; //daca il dereferentiez
	//e chiar un elem array_t
	if ((*current).len != 0)
		return;
	//imi aloc memorie pt cea noua si vad cum pun valoarea
	array_t *anterior;
	anterior = current - 1;
	(*current).len = (*anterior).len;
	(*current).elem_size = (*anterior).elem_size;
	(*current).destructor = (*anterior).destructor;
	(*current).data = (int *)calloc(sizeof(int), (*current).len);
	int *prim, *val_ant;
	prim = (int *)((*current).data);
	val_ant = (int *)((*anterior).data);
	*prim = *val_ant + 1;
}

void distruge_arr(void *p) {
	array_t *elem;
	elem = (array_t *)p;
	free(elem->data);
}

void elemente(void *p) {
	int *current;
	current = (int *)p;
	if (*current != 0)
		return;
	int *anterior;
	anterior = current - 1; //imi trece cu un elem int mai la stanga
	*current = *(anterior) + 1;
}

void individual(void *p) {
	array_t *elem;
	elem = (array_t *)p;
	for_each(&elemente, *elem);
}

//sfarsit functii generate_square_matrix

array_t generate_square_matrix(int n) {
	array_t matrix;
	matrix.elem_size = sizeof(array_t);
	//printf("%d\n\n",matrix.elem_size);
	matrix.len = n;
	matrix.data = (array_t *)calloc(sizeof(array_t), n);
	//sa vad ce fac cu destructorul
	matrix.destructor = distruge_arr; //la fiecare element da free
	//unui elem de tipul array_t alocat ca mai sus
	//sa fac mai intai alocarea pentru primul element??
	//si sa ii pun valorile
	array_t *primul;
	primul = (array_t *)matrix.data;
	(*primul).len = n;
	(*primul).elem_size = sizeof(int);
	(*primul).data = (int *)calloc(sizeof(int), n);
	(*primul).destructor = NULL; //si aici sa vad ce fac
	int *prim_prim;
	prim_prim = (int *)(primul->data);
	*prim_prim = 1;
	for_each(&fiecare, matrix); //parcurg lista mare de liste
	for_each(&individual, matrix);
	return matrix;
	//(void)n;
	//return (array_t){0};
}
