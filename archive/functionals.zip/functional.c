#include "functional.h"
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#define MIA 1000
//#include <stdio.h>
//aici pot folosi instructiuni repetitive
void for_each(void (*func)(void *), array_t list) {
	//aceasta functie parcurge toate elementele listei
	//si le aplica in parte functia func
	char *p;
	p = (char *)list.data;//pointez la inceputul locului in
	// care stochez informatia despre elementele din lista
	for (int i = 0; i <= list.len - 1; i++) {
		(*func)((void *)p);
		p += list.elem_size;
	}
}

array_t map(void (*func)(void *, void *), int new_list_elem_size,
			void (*new_list_destructor)(void *), array_t list)
{
	//trebuie sa imi declar o variabila de tip array_t care sa aiba
	//toate elementele egale cu ceea ce rezulta daca aplic func listei vechi
	array_t new_list;
	//trebuie sa imi aloc spatiu pt elem. de dinauntrul listei noi
	new_list.len = list.len; //cele doua liste au acelasi numar de elemente
	new_list.elem_size = new_list_elem_size;
	new_list.data = malloc(list.len * new_list.elem_size);
	if (!new_list.data)
		return (array_t){0};
	//presupun ca destructor ul trimis ca parametru
	//pointeaza deja catre o functie
	new_list.destructor = new_list_destructor;
	char *p, *q, *aux; //pe p il folosesc ca sa parcurg
	//lista veche, iar pe q pt lista noua
	p = (char *)list.data;
	q = (char *)new_list.data;
	for (int i = 0; i <= list.len - 1; i++) {
		(*func)((void *)q, (void *)p);
		//dezaloc memoria de la p inainte sa il modific
		aux = p; //retin in aux locul in care pointa p si
		//cu p trec la urmatorul element
		p += list.elem_size;
		q += new_list.elem_size;
		list.destructor((void *)aux); //distrug elementul la care e pointat p
	}
	free(list.data);
	//(array_t){0} reprezinta un elem. de tip lista
	//care are toate elementele pe NULL?
	return new_list;
}

array_t filter(boolean(*func)(void *), array_t list) {
	array_t new_list;
	new_list.len = 0;
	new_list.elem_size = list.elem_size;
	new_list.destructor = list.destructor;
	new_list.data = malloc(list.elem_size * list.len);
	if (!new_list.data)
		return (array_t){0};
	char *p, *q;
	p = (char *)list.data;
	q = (char *)new_list.data;
	for (int i = 0; i <= list.len - 1; i++) {
		if ((*func)((void *)p) == 1) {
			for (int j = 0; j <= list.elem_size - 1; j++)
				*(q + j) = *(p + j);
			q += new_list.elem_size;
			new_list.len++;
		}
		p += list.elem_size;
	}
	free(list.data);
	return new_list;
}

void *reduce(void (*func)(void *, void *), void *acc, array_t list)
{
	//acumulatorul e un fel de variabila care retine ce modificari
	//am facut pana la pasul curent
	//efectiv parcurg elementele listei si pentru fiecare
	//fac func(acc,list.elem)??
	//cand apelez functia func se modifica elementul din acumulator
	char *p;
	p = (char *)list.data;
	for (int i = 0; i <= list.len - 1; i++) {
		(*func)(acc, (void *)p);
		p += list.elem_size;
	}
	return acc;
}

void for_each_multiple(void(*func)(void **), int varg_c, ...)//restul de
//elemente trimise ca parametru sunt de tip array_t
{
	//sa parcurg toate listele si sa calculez din datele
	//lor care e lungimea minima
	int minim = 10000;
	va_list args; //args reprezinta lista de parametri pe
	//care ii primeste functia
	va_start(args, varg_c); //incep parcurgerea listei de parametri
	//de la ultimul param trimis, varg_c
	array_t lista;
	for (int i = 0; i <= varg_c - 1; i++) {
		lista = va_arg(args, array_t); //trec la urmatorul element
		//din lista de parametri
		if (lista.len < minim)
			minim = lista.len;
	}
	va_end(args);
	//trebuie sa imi creez un vector ce contine pointeri catre
	//elementele de la indexul respectiv
	char **p;
	p = malloc(varg_c * sizeof(char *));
	if (!p)
		return;
	for (int i = 0; i <= minim - 1; i++) {
		va_start(args, varg_c);
		for (int j = 0; j <= varg_c - 1; j++) {
			lista = va_arg(args, array_t);
			//p[j] e de tip char *
			*(p + j) = (char *)lista.data + lista.elem_size * i;
		}
		(*func)((void **)p);
		va_end(args);
	}
	free(p);
}

//eliberare memorie
array_t map_multiple(void (*func)(void *, void **),
					 int new_list_elem_size,
					 void (*new_list_destructor)(void *),
					 int varg_c, ...)
{
	int minim = 1000;
	va_list args;
	va_start(args, varg_c);
	array_t lista;
	for (int i = 0; i <= varg_c - 1; i++) {
		lista = va_arg(args, array_t); //lista devine mereu
		//noul parametru de tip array_t
		if (lista.len < minim)
			minim = lista.len;
	}
	va_end(args);
	va_start(args, varg_c);
	array_t new_list;
	new_list.elem_size = new_list_elem_size;
	new_list.len = minim;
	new_list.destructor = new_list_destructor;
	new_list.data = malloc(new_list.elem_size * minim);
	if (!new_list.data)
		return (array_t){0};
	//vectorul pe care il creez si pe care sa il trimit
	//functiei ca al doilea parametru sa contina elemente
	//de tip void * catre elementele pe care le folosesc
	//nu e nevoie sa imi aloc memorie pentru p, e un vector
	//de pointeri catre elementele de care am nevoie
	char **p; //vector de pointeri
	//cred ca trebuie sa imi aloc pt p macar liniile
	p = malloc(varg_c * sizeof(char *));
	if (!p)
		return (array_t){0};
	for (int j = 0; j <= minim - 1; j++) {
		va_start(args, varg_c);
		for (int i = 0; i <= varg_c - 1; i++) {
			lista = va_arg(args, array_t);
			//depinde de j?? elementul
			//p[i] e de tip char *
			*(p + i) = (char *)lista.data + j * lista.elem_size;
		}
		(*func)((void *)((char *)new_list.data + j * new_list.elem_size),
				(void **)p);
		va_end(args);
	}
	va_start(args, varg_c);
	for (int i = 0; i <= varg_c - 1; i++) {
		lista = va_arg(args, array_t);
		char *c;
		c = (char *)lista.data;
		if (lista.destructor)
			for (int j = 0; j <= lista.len - 1; j++)
				lista.destructor(c + lista.elem_size * j);
		free(lista.data);
	}
	va_end(args);
	//tb sa dai free si la p
	free(p);
	return new_list;
}

void *reduce_multiple(void(*func)(void *, void **), void *acc, int varg_c, ...)
{
	int minim;
	minim = MIA;
	va_list args;
	va_start(args, varg_c);
	array_t lista;
	for (int i = 0; i <= varg_c - 1; i++) {
		lista = va_arg(args, array_t);
		if (lista.len < minim)
			minim = lista.len;
	}
	va_end(args);
	char **p;
	p = malloc(varg_c * sizeof(char *));
	if (!p)
		return NULL;
	for (int i = 0; i <= minim - 1; i++) {
		va_start(args, varg_c);
		for (int j = 0; j <= varg_c - 1; j++) {
			lista = va_arg(args, array_t);
			*(p + j) = (char *)lista.data + i * lista.elem_size;
		}
		(*func)(acc, (void **)p);
		va_end(args);
	}
	free(p);
	return acc;
}
