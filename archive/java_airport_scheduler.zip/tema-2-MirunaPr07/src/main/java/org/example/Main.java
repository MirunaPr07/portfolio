package org.example;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.nio.file.*;

public class Main {
    public static void procesare_comenzi(String linie, List<Runway<NarrowBodyAirplane>> piste_narrow, List<Runway<WideBodyAirplane>> piste_wide, String fisier_eroare, String fisier_iesire, String fisier_runway) {
        List<String> desparte;
        LocalTime time_prim;
        String comanda;
        desparte = Arrays.asList(linie.split(" - ")); // cand fac asta imi pastreaza si sirurile "-"
        // split imi returneaza un vector de string uri
        // cum nu pot folosi vectori, il convertesc intr o lista
        time_prim = LocalTime.parse(desparte.get(0));
        comanda = desparte.get(1);
        if (comanda.equals("add_runway_in_use")) { // inteleg ca aici nu ma folosesc de timestamp
            Activitatea a;
            if (desparte.get(3).equals("landing"))
                a = Activitatea.LANDING;
            else a = Activitatea.TAKEOFF;
            if (desparte.get(4).equals("wide body")) {
                Runway<WideBodyAirplane> noua_pista;
                noua_pista = new Runway<WideBodyAirplane>(desparte.get(2), a);
                piste_wide.add(noua_pista);
            }
            else {
                Runway<NarrowBodyAirplane> noua_pista;
                noua_pista = new Runway<NarrowBodyAirplane>(desparte.get(2), a);
                piste_narrow.add(noua_pista);
            }
        }
        else if (comanda.equals("allocate_plane")) {
            boolean urgenta;
            if (desparte.size() == 10 && desparte.get(9).equals("urgent"))
                urgenta = true;
            else urgenta = false;
            if (desparte.get(2).equals("wide body")) {
                try {
                    Runway<WideBodyAirplane> pista_caut;
                    if (desparte.get(6).equals("Bucharest"))
                        pista_caut = Runway.cauta_pista(piste_wide, desparte.get(8), Activitatea.LANDING, time_prim);
                    else pista_caut = Runway.cauta_pista(piste_wide, desparte.get(8), Activitatea.TAKEOFF, time_prim);
                    if (desparte.get(5).equals("Bucharest")) // pleaca
                        urgenta = false;
                    pista_caut.adauga_avioane(desparte.get(3), desparte.get(4), desparte.get(5), desparte.get(6), LocalTime.parse(desparte.get(7)), false, urgenta);
                } catch (IncorrectRunwayException e) {
                    try {
                        String mesaj; // afisare in fisiere
                        mesaj = e.getMessage() + "\r\n";
                        Files.write(Paths.get(fisier_eroare), mesaj.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
            else {
                try {
                    Runway<NarrowBodyAirplane> pista_caut;
                    if (desparte.get(6).equals("Bucharest"))
                        pista_caut = Runway.cauta_pista(piste_narrow, desparte.get(8), Activitatea.LANDING, time_prim);
                    else pista_caut = Runway.cauta_pista(piste_narrow, desparte.get(8), Activitatea.TAKEOFF, time_prim);
                    // continui sa pun un nou avion
                    if (desparte.get(5).equals("Bucharest")) // pleaca
                        urgenta = false;
                    pista_caut.adauga_avioane(desparte.get(3), desparte.get(4), desparte.get(5), desparte.get(6), LocalTime.parse(desparte.get(7)), true, urgenta);
                } catch (IncorrectRunwayException e) {
                    try {
                        String mesaj; // afisare in fisiere
                        mesaj = e.getMessage() + "\r\n";
                        Files.write(Paths.get(fisier_eroare), mesaj.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }
        else if (comanda.equals("flight_info")) {
            String mesaj;
            mesaj = Runway.afiseaza_avion(piste_wide, piste_narrow, desparte.get(2), time_prim) + "\r\n";
            try {
                Files.write(Paths.get(fisier_iesire), mesaj.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        else if (comanda.equals("runway_info")) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH-mm-ss");
            fisier_runway += "/runway_info_" + desparte.get(2) + "_" + time_prim.format(formatter).toString() + ".out";
            String mesaj;
            mesaj = Runway.afiseaza_pista(piste_wide, piste_narrow, desparte.get(2), time_prim) + "\r\n";
            try {
                Files.write(Paths.get(fisier_runway), mesaj.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
        else if (comanda.equals("permission_for_maneuver")) {
            try {
                Runway.manevra(piste_wide, piste_narrow, desparte.get(2), time_prim);
            } catch (UnavailableRunwayException e) {
                try {
                    String mesaj;
                    mesaj = e.getMessage() + "\r\n";
                    Files.write(Paths.get(fisier_eroare), mesaj.getBytes(), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
    public static void main(String[] args) {
        if (args.length > 0) {
            String fisier_intrare, fisier_eroare, fisier_iesire, fisier_runway;
            List<String> input = new ArrayList<>(); // lista de string-uri (comenzi)
            List<Runway<WideBodyAirplane>> piste_wide;
            List<Runway<NarrowBodyAirplane>> piste_narrow;
            piste_wide = new ArrayList<>();
            piste_narrow = new ArrayList<>();
            fisier_intrare = "src/main/resources/" + args[0] + "/input.in";
            fisier_eroare = "src/main/resources/" + args[0] + "/board_exceptions.out";
            fisier_iesire = "src/main/resources/" + args[0] + "/flight_info.out";
            fisier_runway = "src/main/resources/" + args[0];
            // mi am creat un string ce reprezinta numele fisierului din care imi voi citi comenzile
            try {
                input = Files.readAllLines(Paths.get(fisier_intrare));
                for (String l : input) {
                    if (l.isEmpty())
                        continue;
                    procesare_comenzi(l, piste_narrow, piste_wide, fisier_eroare, fisier_iesire, fisier_runway);
                    // consider ca e o idee mai buna sa imi creez doua liste cu elem de tip Runway
                    // una ce primeste doar avioane wide body si una doar narrow body,
                    // in loc sa imi declar pentru fiecare pista un nou status si sa le pun pe toate intr o lista
                }
            } catch (IOException e) {
                System.err.println("Eroare la citirea din fisier!!");
                e.printStackTrace();
            }
        } else {
            System.out.println("Tema2");
        }
    }
}