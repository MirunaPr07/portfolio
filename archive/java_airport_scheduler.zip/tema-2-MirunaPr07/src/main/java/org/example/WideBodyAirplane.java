package org.example;

public class WideBodyAirplane extends Airplane {
    public WideBodyAirplane(String model_nou, String ID_nou, String sursa_nou, String destinatia_nou) {
        super(model_nou, ID_nou, sursa_nou, destinatia_nou);
    }
    public String toString() {
        String aux;
        aux = "Wide Body - " + super.toString();
        return aux;
    }
}
