package org.example;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;

enum Status {
    WAITING_FOR_TAKEOFF,
    DEPARTED,
    WAITING_FOR_LANDING,
    LANDED
}
public class Airplane implements Comparable {
    String model, ID, sursa, destinatia;
    LocalTime timp_vrut, timp_real;
    Status status;
    public Airplane(String model_nou, String ID_nou, String sursa_nou, String destinatia_nou) {
        this.model = model_nou;
        this.ID = ID_nou;
        this.sursa = sursa_nou;
        this.destinatia = destinatia_nou;
        this.status = Status.WAITING_FOR_TAKEOFF;
        this.timp_real = LocalTime.of(0, 0, 0);
    }
    public int compareTo(Object o) {
        Airplane a = (Airplane) o;
        return this.getTimp_vrut().compareTo(a.getTimp_vrut());
    }
    public void setModel(String model_nou) {
        this.model = model_nou;
    }
    public void setID(String ID_nou) {
        this.ID = ID_nou;
    }
    public void setSursa(String sursa_nou) {
        this.sursa = sursa_nou;
    }
    public void setDestinatia(String destinatia_nou) {
        this.destinatia = destinatia_nou;
    }
    public void setTimp_vrut(LocalTime timp_vrut_nou) {
        this.timp_vrut = timp_vrut_nou;
    }
    public void setTimp_real(LocalTime timp_real_nou) {
        this.timp_real = timp_real_nou;
    }
    public void setStatus(Status status_nou) {
        this.status = status_nou;
    }
    public String getModel() {
        return this.model;
    }
    public String getID() {
        return this.ID;
    }
    public String getSursa() {
        return this.sursa;
    }
    public String getDestinatia() {
        return this.destinatia;
    }
    public LocalTime getTimp_vrut() {
        return this.timp_vrut;
    }
    public LocalTime getTimp_real() {
        return this.timp_real;
    }
    public Status getStatus() {
        return this.status;
    }
    public String toString() {
        String aux;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        aux = this.model + " - " + this.ID + " - " + this.sursa + " - " + this.destinatia + " - " + this.status + " - " + this.timp_vrut.format(formatter);
        if (this.timp_real != LocalTime.of(0, 0, 0))
            aux = aux + " - " + this.timp_real.format(formatter);
        return aux;
    }
}
