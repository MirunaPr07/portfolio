package org.example;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.time.format.DateTimeFormatter;
import java.time.Duration;
enum Activitatea {
    LANDING,
    TAKEOFF
}
class IncorrectRunwayException extends RuntimeException {
    public IncorrectRunwayException(String message) {
        super(message);
    }
}
class UnavailableRunwayException extends Exception {
    public UnavailableRunwayException(String message) {
        super(message);
    }
}
public class Runway<T extends Airplane>{
    String ID;
    ArrayList<T> avioane;
    ArrayList<T> urgente;
    Activitatea activitate;
    LocalTime ultim;
    Runway(String ID_nou, Activitatea activitate_nou) {
        this.ID = ID_nou;
        this.activitate = activitate_nou;
        this.avioane = new ArrayList<>();
        this.urgente = new ArrayList<>();
        this.ultim = LocalTime.of(0, 0, 0);
    }
    void setUltim(LocalTime ultim_nou) {
        this.ultim = ultim_nou;
    }
    LocalTime getUltim() {
        return this.ultim;
    }
    String getID() {
        return this.ID;
    }
    ArrayList<T> getAvioane() {
        return this.avioane;
    }
    ArrayList<T> getUrgente() {
        return this.urgente;
    }
    Activitatea getActivitate() {
        return this.activitate;
    }
    public static <T extends Airplane> Runway<T> cauta_pista(List<Runway<T>> runways, String ID_caut, Activitatea a, LocalTime timestamp) throws IncorrectRunwayException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        for (Runway<T> p : runways)
            if (p.getID().equals(ID_caut)) {
                if (p.getActivitate() == a)
                    return p;
                else throw new IncorrectRunwayException(timestamp.format(formatter) + " | The chosen runway for allocating the plane is incorrect");
            }
        return null;
    }
    public void adauga_avioane(String model, String ID, String sursa, String destinatie, LocalTime timp_dorit, boolean tip, boolean urgenta) {
        // tip = false => pista pt wide body
        // true => pista pt narrow body
        T avion; // imi declar noul avion ca fiind de tip T(general)
        if (tip == false) { // wide body
            avion = (T) new WideBodyAirplane(model, ID, sursa, destinatie);
        }
        else {
            avion = (T) new NarrowBodyAirplane(model, ID, sursa, destinatie);
        }
        avion.setTimp_vrut(timp_dorit); // aici e ori timpul dorit de aterizare, ori de plecare
        if (this.getActivitate() == Activitatea.TAKEOFF)
            avion.setStatus(Status.WAITING_FOR_TAKEOFF);
        else avion.setStatus(Status.WAITING_FOR_LANDING);
        // aici adaugarea altfel, dar e doar o verificare de control:
        // aici ar trebui sa adaug in lista de avioane avionul curent astfel incat timestamp utile sa fie crescatoare
        // gandesc dupa faza cu urgent
        if (urgenta == false) {
            this.avioane.add(avion);
            Collections.sort(this.getAvioane());
        }
        else {
            this.urgente.add(avion);
            Collections.sort(this.getUrgente());
        }
    }
    public static String afiseaza_avion(List<Runway<WideBodyAirplane>> wide_runways, List<Runway<NarrowBodyAirplane>> narrow_runways, String ID_caut, LocalTime timestamp) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        for (Runway<WideBodyAirplane> runway : wide_runways) {
            for (WideBodyAirplane airplane : runway.getAvioane()) {
                if (airplane.getID().equals(ID_caut)) {
                    String aux;
                    aux = timestamp.format(formatter) + " | " + airplane.toString();
                    return aux;
                }
            }
            for (WideBodyAirplane airplane : runway.getUrgente()) {
                if (airplane.getID().equals(ID_caut)) {
                    String aux;
                    aux = timestamp.format(formatter) + " | " + airplane.toString();
                    return aux;
                }
            }
        }
        for (Runway<NarrowBodyAirplane> runway : narrow_runways) {
            for (NarrowBodyAirplane airplane : runway.getAvioane()) {
                if (airplane.getID().equals(ID_caut)) {
                    String aux;
                    aux = timestamp.format(formatter) + " | " + airplane.toString();
                    return aux;
                }
            }
            for (NarrowBodyAirplane airplane : runway.getUrgente()) {
                if (airplane.getID().equals(ID_caut)) {
                    String aux;
                    aux = timestamp.format(formatter) + " | " + airplane.toString();
                    return aux;
                }
            }
        }
        return null;
    }
    public static String afiseaza_pista(List<Runway<WideBodyAirplane>> wide_runways, List<Runway<NarrowBodyAirplane>> narrow_runways, String ID_caut, LocalTime timestamp) {
        String sir;
        for (Runway<WideBodyAirplane> runway : wide_runways)
            if (runway.getID().equals(ID_caut)) {
                boolean ok;
                ok = false;
                sir = runway.getID();
                for (WideBodyAirplane airplane : runway.getUrgente()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_LANDING || airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        if (ok == false) {
                            ok = true;
                            Duration dif = Duration.between(runway.getUltim(), timestamp);
                            if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF && dif.toMinutes() <= 5) {
                                sir += " - OCCUPIED";
                            }
                            else if (airplane.getStatus() == Status.WAITING_FOR_LANDING && dif.toMinutes() <= 10) {
                                sir += " - OCCUPIED";
                            }
                            else sir += " - FREE";
                        }
                        sir += "\r\n" + airplane.toString();
                    }
                }
                for (WideBodyAirplane airplane : runway.getAvioane()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_LANDING || airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        if (ok == false) {
                            ok = true;
                            Duration dif = Duration.between(runway.getUltim(), timestamp);
                            if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF && dif.toMinutes() <= 5) {
                                sir += " - OCCUPIED";
                            }
                            else if (airplane.getStatus() == Status.WAITING_FOR_LANDING && dif.toMinutes() <= 10) {
                                sir += " - OCCUPIED";
                            }
                            else sir += " - FREE";
                        }
                        sir += "\r\n" + airplane.toString();
                    }
                }
                if (ok == false)
                    sir += " - FREE";
                return sir;
            }
        for (Runway<NarrowBodyAirplane> runway : narrow_runways)
            if (runway.getID().equals(ID_caut)) {
                boolean ok;
                ok = false;
                sir = runway.getID();
                for (NarrowBodyAirplane airplane : runway.getUrgente()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_LANDING || airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        if (ok == false) {
                            ok = true;
                            Duration dif = Duration.between(runway.getUltim(), timestamp);
                            if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF && dif.toMinutes() <= 5) {
                                sir += " - OCCUPIED";
                            }
                            else if (airplane.getStatus() == Status.WAITING_FOR_LANDING && dif.toMinutes() <= 10) {
                                sir += " - OCCUPIED";
                            }
                            else sir += " - FREE";
                        }
                        sir += "\r\n" + airplane.toString();
                    }
                }
                for (NarrowBodyAirplane airplane : runway.getAvioane()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_LANDING || airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        if (ok == false) {
                            ok = true;
                            Duration dif = Duration.between(runway.getUltim(), timestamp);
                            if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF && dif.toMinutes() <= 5) {
                                sir += " - OCCUPIED";
                            }
                            else if (airplane.getStatus() == Status.WAITING_FOR_LANDING && dif.toMinutes() <= 10) {
                                sir += " - OCCUPIED";
                            }
                            else sir += " - FREE";
                        }
                        sir += "\r\n" + airplane.toString();
                    }
                }
                if (ok == false)
                    sir += " - FREE";
                return sir;
            }
        return null;
    }
    public static void manevra (List<Runway<WideBodyAirplane>> wide_runways, List<Runway<NarrowBodyAirplane>> narrow_runways, String ID_caut, LocalTime timestamp) throws UnavailableRunwayException {
        // nu stiu tipul pistei, tb sa caut in ambele
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        for (Runway<WideBodyAirplane> runway : wide_runways)
            if (runway.getID().equals(ID_caut)) {
                Duration dif = Duration.between(runway.getUltim(), timestamp);
                if ((runway.getAvioane().get(0).getStatus() == Status.WAITING_FOR_TAKEOFF || runway.getAvioane().get(0).getStatus() == Status.DEPARTED) && dif.toMinutes() <= 5)
                    throw new UnavailableRunwayException(timestamp.format(formatter) + " | The chosen runway for maneuver is currently occupied");
                else if ((runway.getAvioane().get(0).getStatus() == Status.WAITING_FOR_LANDING || runway.getAvioane().get(0).getStatus() == Status.LANDED) && dif.toMinutes() <= 10)
                    throw new UnavailableRunwayException(timestamp.format(formatter) + " | The chosen runway for maneuver is currently occupied");
                for (WideBodyAirplane airplane : runway.getUrgente()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        airplane.setStatus(Status.DEPARTED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                    else if (airplane.getStatus() == Status.WAITING_FOR_LANDING) {
                        airplane.setStatus(Status.LANDED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                }
                for (WideBodyAirplane airplane : runway.getAvioane()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        airplane.setStatus(Status.DEPARTED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                    else if (airplane.getStatus() == Status.WAITING_FOR_LANDING) {
                        airplane.setStatus(Status.LANDED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                }
            }
        for (Runway<NarrowBodyAirplane> runway : narrow_runways)
            if (runway.getID().equals(ID_caut)) {
                Duration dif = Duration.between(runway.getUltim(), timestamp);
                if ((runway.getAvioane().get(0).getStatus() == Status.WAITING_FOR_TAKEOFF || runway.getAvioane().get(0).getStatus() == Status.DEPARTED) && dif.toMinutes() <= 5)
                    throw new UnavailableRunwayException(timestamp.format(formatter) + " | The chosen runway for maneuver is currently occupied");
                else if ((runway.getAvioane().get(0).getStatus() == Status.WAITING_FOR_LANDING || runway.getAvioane().get(0).getStatus() == Status.LANDED) && dif.toMinutes() <= 10)
                    throw new UnavailableRunwayException(timestamp.format(formatter) + " | The chosen runway for maneuver is currently occupied");
                for (NarrowBodyAirplane airplane : runway.getUrgente()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        airplane.setStatus(Status.DEPARTED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                    else if (airplane.getStatus() == Status.WAITING_FOR_LANDING) {
                        airplane.setStatus(Status.LANDED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                }
                for (NarrowBodyAirplane airplane : runway.getAvioane()) {
                    if (airplane.getStatus() == Status.WAITING_FOR_TAKEOFF) {
                        airplane.setStatus(Status.DEPARTED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                    else if (airplane.getStatus() == Status.WAITING_FOR_LANDING) {
                        airplane.setStatus(Status.LANDED);
                        airplane.setTimp_real(timestamp);
                        runway.setUltim(timestamp);
                        return;
                    }
                }
            }
    }
}
