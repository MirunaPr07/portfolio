package org.example;

public class NarrowBodyAirplane extends Airplane {
    public NarrowBodyAirplane(String model_nou, String ID_nou, String sursa_nou, String destinatia_nou) {
        super(model_nou, ID_nou, sursa_nou, destinatia_nou);
    }
    public String toString() {
        String aux;
        aux = "Narrow Body - " + super.toString();
        return aux;
    }
}
