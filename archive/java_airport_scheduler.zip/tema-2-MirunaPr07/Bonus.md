M-am gandit ca o functionalitate usor de implementat si adaugat in cod ar fi o statistica pentru fiecare pista. Acest lucru s-ar implementa
intr-o clasa numita poate RunwayStatistics. Ea ar retine toate datele despre fiecare pista in parte de-a lungul zilei, iar la finalul zilei
ar oferi o imagine de ansamblu asupra traficului din acea zi. As putea calcula inauntru prin intermediul anumitor metode numarul de decolari, de
aterizari pe acea pista, poate intarzierea medie a avioanelor din acea zi pe acea pista. Metoda s-ar putea numi AvarageDelay si ar calcula
intarzierea medie, dupa cum am zis, facand diferenta intre timpul dorit si timpul real pentru fiecare avion in parte si adunandu-le(si dupa
impartind valoarea la numarul de avioane intarziate). S-ar putea implementa si o metoda care sa gaseasca din vectorul de piste acea pista care
a avut cel mai mare numar de decolari si aterizari. O astfel de metoda chiar ar ajuta intr-un sistem al unui aeroport adevarat, intrucat s-ar 
afla pistele cele mai incarcate si s-ar putea eficientiza modul in care este organizat traficul aerian(poate se ia decizia construirii unei noi 
piste). Astfel, s-ar evita blocajele si intarzierile foarte mari de pe pistele supraincarcate. Cu aceste imbunatatiri, am afla informatii
importante privind un aeroport in ansamblu si pistele din el.
