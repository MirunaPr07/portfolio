Cum am ales cateva dintre colectiile folosite la tema:
1. Am folosit ArrayList pentru a stoca avioanele (pe care de fapt le-am pastrat atat in "urgente" cat si in "avioane" pentru fiecare variabila de 
tip Runway). Am hotarat sa stochez avioanele care aterizau si care aveau urgente intr-un ArrayList separat de cel in care am retinut avioanele
oarecare pentru a ma folosi mai usor de conceptul ca "avioanele care aterizeaza si au urgenta au prioritate fata de celelalte chiar daca au
timestamp ul mai devreme". Asa am ajuns sa am doua ArrayList-uri separate pentru fiecare Runway in parte. Am hotarat sa folosesc ArrayList pentru
avioane pentru ca pot accesa rapid un element in functie de index(spre deosebire de o LinkedList), stiam cum sa fac sortarea pe un ArrayList dupa
cum am folosit conceptul la laborator, astfel ca am sortat ArrayList-ul de avioane de fiecare data cand am adaugat un nou avion pe aceasta pista
cu usurinta, doar apeland functia de sortare din Collections. Astfel, am pastrat cele doua liste permanent sortate, iar in momentul adaugarii
unui nou element, sortarea din spate aproape ca este doar o parcurgere a listei. In plus, am ales ArrayList pentru ca adaugarea unui element este
extrem de usoara. Daca nu as fi ales sa construiesc o colectie separata de tip ArrayList pentru urgente, mi-ar fi fost mai greu sa fac o procesare
diferentiata a avioanelor normale si de urgenta. As fi avut o singura lista pe care mi-ar fi fost mai greu sa o sortez, probabil trebuind sa am
un status separat pentru acele avioane sau o variabila in plus careia sa ii fi dat o valoare specifica.
2. Pentru piste_wide si piste_narrow am ales sa creez doua colectii separate pentru a reduce complexitatea operatiilor de alocare si cautare. 
Acest lucru previne, de asemeni, alocarile gresite, intrucat nu pot aloca unui element din piste_narrow un element de tip WideBodyAirplane.
Ca mai devreme, pot spune ca am ales ArrayList pentru ca pot accesa rapid elementele din lista, pot adauga elemente noi usor intr-o astfel de
lista. Daca as fi folosit o unica variabila pentru a retine toate pistele, ar fi trebuit sa am tot timpul o verificare in plus si o parcurgere a 
posibil mai multe elemente din lista cand caut unul anume, lucru care ar fi complicat si mai tare implementarea.