#include <stdio.h>
#include <stdlib.h>
#include "imageprocessing.h"
#define MAXIM 255


int ***flip_horizontal(int ***image, int N, int M) {
    int i = 0, j = 0, k = 0, l = 0, aux = 0;
    for (i = 0; i <= N-1; i++)
        for (j = 0, k = M-1; j < k; j++, k--) {
            for (l = 0; l <= 2; l++) {
                aux = image[i][j][l];
                image[i][j][l] = image[i][k][l];
                image[i][k][l] = aux;
            }
        }
    return image;
}

int ***rotate_left(int ***image, int N, int M) {
    int ***cimg = NULL, i = 0, j = 0, k = 0;
    cimg = malloc(M*sizeof(int **));
    for (i = 0; i <= M-1; i++) {
        cimg[i] = malloc(N*sizeof(int *));
    }
    for (i = 0; i <= M-1; i++)
        for (j = 0; j <= N-1; j++) {
            cimg[i][j] = malloc(3*sizeof(int));
        }
    for (i = 0; i <= M-1; i++)
        for (j = 0; j <= N-1; j++)
            for (k = 0; k <= 2; k++)
                cimg[i][j][k] = image[j][M-1-i][k];
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++)
            free(image[i][j]);
    for (i = 0; i <= N-1; i++)
        free(image[i]);
    free(image);
    return cimg;
}


int ***crop(int ***image, int N, int M, int x, int y, int h, int w) {
    int ***cimg = NULL, i = 0, j = 0, k = 0;
    cimg = malloc(h*sizeof(int **));
    for (i = 0; i <= h-1; i++)
        cimg[i] = malloc(w*sizeof(int *));
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            cimg[i][j] = malloc(3*sizeof(int));
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            for (k = 0; k <= 2; k++)
                cimg[i][j][k] = image[i+y][j+x][k];
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++)
            free(image[i][j]);
    for (i = 0; i <= N-1; i++)
        free(image[i]);
    free(image);
    return cimg;
}


int ***extend(int ***image, int N, int M, int rows, int cols, int new_R, int new_G, int new_B) {
    int ***cimg = NULL, n = N+2*rows, m = M+2*cols, i = 0, j = 0, k = 0;
    cimg = malloc(n*sizeof(int **));
    for (i = 0; i <= n-1; i++)
        cimg[i] = malloc(m*sizeof(int *));
    for (i = 0; i <= n-1; i++) {
        for (j = 0; j <= m-1; j++)
            cimg[i][j] = malloc(3*sizeof(int));
    }
    for (i = 0; i <= n-1; i++) {
        for (j = 0; j <= m-1; j++) {
            cimg[i][j][0] = new_R;
            cimg[i][j][1] = new_G;
            cimg[i][j][2] = new_B;
        }
    }
    for (i = rows; i <= n-1-rows; i++)
        for (j = cols; j <= m-1-cols; j++)
            for (k = 0; k <= 2; k++)
                cimg[i][j][k] = image[i-rows][j-cols][k];
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++)
            free(image[i][j]);
    for (i = 0; i <= N-1; i++)
        free(image[i]);
    free(image);
    return cimg;
}


int ***paste(int ***image_dst, int N_dst, int M_dst, int *** image_src, int N_src, int M_src, int x, int y) {
    int i = 0, j = 0, k = 0;
    for (i = y; i <= N_dst-1 && i-y <= N_src-1; i++)
        for (j = x; j <= M_dst-1 && j-x <= M_src-1; j++)
            for (k = 0; k <= 2; k++)
                image_dst[i][j][k] = image_src[i-y][j-x][k];
    return image_dst;
}


int ***apply_filter(int ***image, int N, int M, float **filter, int filter_size) {
    float ***cimg = NULL;
    int p = 0, q = 0, i = 0, j = 0, k = 0, min1 = 0, min2 = 0, max1 = 0, max2 = 0, x = filter_size/2, y = filter_size/2;
    cimg = calloc(N, sizeof(float**));
    for (i = 0; i <= N-1; i++)
        cimg[i] = calloc(M, sizeof(float*));
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++)
            cimg[i][j] = calloc(3, sizeof(float));
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++) {
            if (i <= x)
                min1 = 0;
            else
                min1 = i-x;
            if (j <= y)
                min2 = 0;
            else
                min2 = j-y;
            if (N-i-1 <= x)
                max1 = N-1;
            else
                max1 = i+x;
            if (M-j-1 <= y)
                max2 = M-1;
            else
                max2 = j+y;
            for (p = min1; p <=max1; p++)
                for (q = min2; q <= max2; q++) {
                    for (k = 0; k <= 2; k++)
                        cimg[i][j][k]+=(float)image[p][q][k]*filter[p+x-i][q+y-j];
                }
        }
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++)
            for (k = 0; k <= 2; k++) {
                image[i][j][k] = (int)cimg[i][j][k];
                if (image[i][j][k] < 0)
                    image[i][j][k] = 0;
                if (image[i][j][k] > MAXIM)
                    image[i][j][k] = MAXIM;
            }
    for (i = 0; i <= N-1; i++)
        for (j = 0; j <= M-1; j++)
            free(cimg[i][j]);
    for (i = 0; i <= N-1; i++)
        free(cimg[i]);
    free(cimg);
    return image;
}
