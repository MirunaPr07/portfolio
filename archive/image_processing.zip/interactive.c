#include <stdio.h>
#include <stdlib.h>
#include "imageprocessing.h"
#include "bmp.h"
#define MAXIM 255
#define SUTA 100
struct structura_img {
    int N, M, ***matrix;
};
struct structura_filt {
    int size;
    float **filter;
};
void load(struct structura_img img[], int *cnt) {
    char path[SUTA];
    scanf("%d %d", &img[*cnt].N, &img[*cnt].M);
    scanf("%s", path);
    img[*cnt].matrix = malloc(img[*cnt].N*sizeof(int**));
    for (int i = 0; i <= img[*cnt].N-1; i++)
        img[*cnt].matrix[i] = malloc(img[*cnt].M*sizeof(int*));
    for (int i = 0; i <= img[*cnt].N-1; i++)
        for (int j = 0; j <= img[*cnt].M-1; j++)
            img[*cnt].matrix[i][j] = malloc(3*sizeof(int));
    read_from_bmp(img[*cnt].matrix, img[*cnt].N, img[*cnt].M, path);
    (*cnt)++;
}
void save(struct structura_img img[]) {
    int index = 0;
    char path[SUTA];
    scanf("%d", &index);
    scanf("%s", path);
    write_to_bmp(img[index].matrix, img[index].N, img[index].M, path);
}
void apph(struct structura_img img[]) {
    int index = 0, i = 0, j = 0, k = 0, l = 0, aux = 0;
    scanf("%d", &index);
    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0, k = img[index].M-1; j < k; j++, k--) {
            for (l = 0; l <= 2; l++) {
                aux = img[index].matrix[i][j][l];
                img[index].matrix[i][j][l] = img[index].matrix[i][k][l];
                img[index].matrix[i][k][l] = aux;
            }
        }
}
void appr(struct structura_img img[]) {
    int ***cimg = NULL, index = 0, i = 0, j = 0, k = 0, aux = 0;
    scanf("%d", &index);
    cimg = malloc(img[index].M*sizeof(int **));
    for (i = 0; i <= img[index].M-1; i++) {
        cimg[i] = malloc(img[index].N*sizeof(int *));
    }
    for (i = 0; i <= img[index].M-1; i++)
        for (j = 0; j <= img[index].N-1; j++) {
            cimg[i][j] = malloc(3*sizeof(int));
        }
    for (i = 0; i <= img[index].M-1; i++)
        for (j = 0; j <= img[index].N-1; j++)
            for (k = 0; k <= 2; k++)
                cimg[i][j][k] = img[index].matrix[j][img[index].M-1-i][k];
    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0; j <= img[index].M-1; j++)
            free(img[index].matrix[i][j]);
    for (i = 0; i <= img[index].N-1; i++)
        free(img[index].matrix[i]);
    free(img[index].matrix);
    aux = img[index].N;
    img[index].N = img[index].M;
    img[index].M = aux;
    img[index].matrix = malloc(img[index].N*sizeof(int **));
    for (i = 0; i <= img[index].N-1; i++) {
        img[index].matrix[i] = malloc(img[index].M*sizeof(int *));
    }
    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0; j <= img[index].M-1; j++) {
            img[index].matrix[i][j] = malloc(3*sizeof(int));
        }

    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0; j <= img[index].M-1; j++)
            for (k = 0; k <= 2; k++)
                img[index].matrix[i][j][k] = cimg[i][j][k];
    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0; j <= img[index].M-1; j++)
            free(cimg[i][j]);
    for (i = 0; i <= img[index].N-1; i++)
        free(cimg[i]);
    free(cimg);
}
void appc(struct structura_img img[]) {
    int ***cimg = NULL, i = 0, j = 0, k = 0, index = 0, x = 0, y = 0, w = 0, h = 0;
    scanf("%d %d %d %d %d", &index, &x, &y, &w, &h);
    cimg = malloc(h*sizeof(int **));
    for (i = 0; i <= h-1; i++)
        cimg[i] = malloc(w*sizeof(int *));
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            cimg[i][j] = malloc(3*sizeof(int));
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            for (k = 0; k <= 2; k++)
                cimg[i][j][k] = img[index].matrix[i+y][j+x][k];
    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0; j <= img[index].M-1; j++)
            free(img[index].matrix[i][j]);
    for (i = 0; i <= img[index].N-1; i++)
        free(img[index].matrix[i]);
    free(img[index].matrix);
    img[index].matrix = malloc(h*sizeof(int **));
    for (i = 0; i <= h-1; i++)
        img[index].matrix[i] = malloc(w*sizeof(int *));
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            img[index].matrix[i][j] = malloc(3*sizeof(int));
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            for (k = 0; k <= 2; k++)
                img[index].matrix[i][j][k] = cimg[i][j][k];
    for (i = 0; i <= h-1; i++)
        for (j = 0; j <= w-1; j++)
            free(cimg[i][j]);
    for (i = 0; i <= h-1; i++)
        free(cimg[i]);
    free(cimg);
    img[index].N = h;
    img[index].M = w;
}
void appe(struct structura_img img[]) {
    int ***cimg = NULL, index = 0, rows = 0, cols = 0, R = 0, G = 0, B = 0, n = 0, m = 0, i = 0, j = 0, k = 0;
    scanf("%d %d %d %d %d %d", &index, &rows, &cols, &R, &G, &B);
    n = img[index].N+2*rows;
    m = img[index].M+2*cols;
    cimg = malloc(n*sizeof(int **));
    for (i = 0; i <= n-1; i++)
        cimg[i] = malloc(m*sizeof(int *));
    for (i = 0; i <= n-1; i++) {
        for (j = 0; j <= m-1; j++)
            cimg[i][j] = malloc(3*sizeof(int));
    }
    for (i = 0; i <= n-1; i++) {
        for (j = 0; j <= m-1; j++) {
            cimg[i][j][0] = R;
            cimg[i][j][1] = G;
            cimg[i][j][2] = B;
        }
    }
    for (i = rows; i <= n-1-rows; i++)
        for (j = cols; j <= m-1-cols; j++)
            for (k = 0; k <= 2; k++)
                cimg[i][j][k] = img[index].matrix[i-rows][j-cols][k];
    for (i = 0; i <= img[index].N-1; i++)
        for (j = 0; j <= img[index].M-1; j++)
            free(img[index].matrix[i][j]);
    for (i = 0; i <= img[index].N-1; i++)
        free(img[index].matrix[i]);
    free(img[index].matrix);
    img[index].matrix = malloc(n*sizeof(int **));
    for (i = 0; i <= n-1; i++)
        img[index].matrix[i] = malloc(m*sizeof(int *));
    for (i = 0; i <= n-1; i++)
        for (j = 0; j <= m-1; j++)
            img[index].matrix[i][j] = malloc(3*sizeof(int));
    for (i = 0; i <= n-1; i++)
        for (j = 0; j <= m-1; j++)
            for (k = 0; k <= 2; k++)
                img[index].matrix[i][j][k] = cimg[i][j][k];
    for (i = 0; i <= n-1; i++)
        for (j = 0; j <= m-1; j++)
            free(cimg[i][j]);
    for (i = 0; i <= n-1; i++)
        free(cimg[i]);
    free(cimg);
    img[index].N = n;
    img[index].M = m;
}
void appp(struct structura_img img[]) {
    int index_dst = 0, index_src = 0, x = 0, y = 0, i = 0, j = 0, k = 0;
    scanf("%d %d %d %d", &index_dst, &index_src, &x, &y);
    for (i = y; i <= img[index_dst].N-1 && i-y <= img[index_src].N-1; i++)
        for (j = x; j <= img[index_dst].M-1 && j-x <= img[index_src].M-1; j++)
            for (k = 0; k <= 2; k++)
                img[index_dst].matrix[i][j][k] = img[index_src].matrix[i-y][j-x][k];
}
void createf(struct structura_filt filt[], int *cont) {
    int i = 0, j = 0;
    scanf("%d", &filt[*cont].size);
    filt[*cont].filter = malloc(filt[*cont].size*sizeof(float*));
    for (i = 0; i <=filt[*cont].size-1; i++)
        filt[*cont].filter[i] = malloc(filt[*cont].size*sizeof(float));
    for (i = 0; i <= filt[*cont].size-1; i++)
        for (j = 0; j <= filt[*cont].size-1; j++)
            scanf("%f", &filt[*cont].filter[i][j]);
    (*cont)++;
}
void appfilt(struct structura_img img[], struct structura_filt filt[]) {
    float ***cimg = NULL;
    int index_filter = 0, index_img = 0, p = 0, q = 0, i = 0, j = 0, k = 0;
    int min1 = 0, min2 = 0, max1 = 0, max2 = 0, x = 0, y = 0;
    scanf("%d %d", &index_img, &index_filter);
    x = y = filt[index_filter].size/2;
    cimg = calloc(img[index_img].N, sizeof(float**));
    for (i = 0; i <= img[index_img].N-1; i++)
        cimg[i] = calloc(img[index_img].M, sizeof(float*));
    for (i = 0; i <= img[index_img].N-1; i++)
        for (j = 0; j <= img[index_img].M-1; j++)
            cimg[i][j] = calloc(3, sizeof(float));
    for (i = 0; i <= img[index_img].N-1; i++)
        for (j = 0; j <= img[index_img].M-1; j++) {
            if (i <= x)
                min1 = 0;
            else
                min1 = i-x;
            if (j <= y)
                min2 = 0;
            else
                min2 = j-y;
            if (img[index_img].N-i-1 <= x)
                max1 = img[index_img].N-1;
            else
                max1 = i+x;
            if (img[index_img].M-j-1 <= y)
                max2 = img[index_img].M-1;
            else
                max2 = j+y;
            for (p = min1; p <=max1; p++)
                for (q = min2; q <= max2; q++) {
                    for (k = 0; k <= 2; k++)
                        cimg[i][j][k]+=(float)img[index_img].matrix[p][q][k]*filt[index_filter].filter[p+x-i][q+y-j];
                }
        }
    for (i = 0; i <= img[index_img].N-1; i++)
        for (j = 0; j <= img[index_img].M-1; j++)
            for (k = 0; k <= 2; k++) {
                img[index_img].matrix[i][j][k] = (int)cimg[i][j][k];
                if (img[index_img].matrix[i][j][k] < 0)
                    img[index_img].matrix[i][j][k] = 0;
                if (img[index_img].matrix[i][j][k] > MAXIM)
                    img[index_img].matrix[i][j][k] = MAXIM;
            }
    for (i = 0; i <= img[index_img].N-1; i++)
        for (j = 0; j <= img[index_img].M-1; j++)
            free(cimg[i][j]);
    for (i = 0; i <= img[index_img].N-1; i++)
        free(cimg[i]);
    free(cimg);
}
void deletefilt(struct structura_filt filt[], int *cont) {
    int index_filter = 0, i = 0, j = 0, k = 0;
    scanf("%d", &index_filter);
    for (i = index_filter; i <= (*cont)-2; i++) {
        for (j = 0; j <= filt[i].size-1; j++)
            free(filt[i].filter[j]);
        free(filt[i].filter);
        filt[i].filter = malloc(filt[i+1].size*sizeof(float*));
        for (j = 0; j <= filt[i+1].size-1; j++)
            filt[i].filter[j] = malloc(filt[i+1].size*sizeof(float));
        filt[i].size = filt[i+1].size;
        for (j = 0; j <= filt[i].size-1; j++)
            for (k = 0; k <= filt[i].size-1; k++)
                filt[i].filter[j][k] = filt[i+1].filter[j][k];
    }
    for (i = 0; i <= filt[(*cont)-1].size-1; i++)
            free(filt[(*cont)-1].filter[i]);
    free(filt[(*cont)-1].filter);
    (*cont)--;
}
void deleteimg(struct structura_img img[], int *cnt) {
    int index_img = 0, i = 0, j = 0, k = 0, l = 0;
    scanf("%d", &index_img);
    for (i = index_img; i <= (*cnt)-2; i++) {
        for (j = 0; j <= img[i].N-1; j++)
            for (k = 0; k <= img[i].M-1; k++)
                free(img[i].matrix[j][k]);
        for (j = 0; j <= img[i].N-1; j++)
            free(img[i].matrix[j]);
        free(img[i].matrix);
        img[i].matrix = malloc(img[i+1].N*sizeof(int**));
        for (j = 0; j <= img[i+1].N-1; j++)
            img[i].matrix[j] = malloc(img[i+1].M*sizeof(int*));
        for (j = 0; j <= img[i+1].N-1; j++)
            for (k = 0; k <= img[i+1].M-1; k++)
                img[i].matrix[j][k] = malloc(3*sizeof(int));
        img[i].N = img[i+1].N;
        img[i].M = img[i+1].M;
        for (j = 0; j <= img[i].N-1; j++)
            for (k = 0; k <= img[i].M-1; k++)
                for (l = 0; l <=2; l++)
                    img[i].matrix[j][k][l] = img[i+1].matrix[j][k][l];
    }
    for (j = 0; j <= img[(*cnt)-1].N-1; j++)
        for (k = 0; k <= img[(*cnt)-1].M-1; k++)
            free(img[(*cnt)-1].matrix[j][k]);
    for (j = 0; j <= img[(*cnt)-1].N-1; j++)
        free(img[(*cnt)-1].matrix[j]);
    free(img[(*cnt)-1].matrix);
    (*cnt)--;
}

void curat(int cnt, struct structura_img img[], int cont, struct structura_filt filt[]) {
    int i = 0, j = 0, k = 0;
    for (i = 0; i <= cnt-1; i++) {
        for (j = 0; j <= img[i].N-1; j++)
            for (k = 0; k <= img[i].M-1; k++)
                free(img[i].matrix[j][k]);
        for (j = 0; j <= img[i].N-1; j++)
            free(img[i].matrix[j]);
        free(img[i].matrix);
    }
    for (i = 0; i <= cont-1; i++) {
        for (j = 0; j <= filt[i].size-1; j++)
            free(filt[i].filter[j]);
        free(filt[i].filter);
    }
}
void citire() {
    char comanda[4];
    scanf("%s", comanda);
    int cnt = 0, cont = 0;
    struct structura_img img[SUTA];
    struct structura_filt filt[SUTA];
    while (comanda[0] != 'e') {
        if (comanda[0] == 'l')
            load(img, &cnt);
        else
        if (comanda[0] == 's')
            save(img);
        else
        if (comanda[1] == 'h')
            apph(img);
        else
        if (comanda[1] == 'r')
            appr(img);
        else
        if (comanda[1] == 'c')
            appc(img);
        else
        if (comanda[1] == 'e')
            appe(img);
        else
        if (comanda[1] == 'p')
            appp(img);
        else
        if (comanda[0] == 'c')
            createf(filt, &cont);
        else
        if (comanda[0] == 'a')
            appfilt(img, filt);
        else
        if (comanda[1] == 'f')
            deletefilt(filt, &cont);
        else
        if (comanda[1] == 'i')
            deleteimg(img, &cnt);
        scanf("%s", comanda);
    }
    curat(cnt, img, cont, filt);
}
int main() {
    citire();
    return 0;
}
