Pentru primul task, skyscrapers_lines, am o stare intermediara, cu care si incep. In starea aceasta, trec de orice caracter, pana ajung la primul :. 
Aici, incep verificarea daca pe linia respectiva gasesc un singur caracter 1, cu ajutorul starii caut1_l. Cand am gasit un 1, incep cautarea cu starea
gas1_l, pentru care nu iau in calcul cazul in care ar ajunge iar pe 1, acesta fiind un caz nefavorabil(am gasit doua caractere 1 pe o linie), fiind 
considerat un NO. Daca am gasit un singur 1 pe prima linie, am ajuns cu bine la primul caracter : (s-a terminat linia), si incep cautarea lui 2 pe
prima linie, dupa o logica asemanatoare, doar ca de la sfarsitul liniei la inceput. Dupa ce am terminat, daca am gasit un singur 2 pe linie, incep 
cautarea caracterului 3. In final, daca pe aceasta linie am gasit exact un 1, exact un 2 si exact un 3, este clar ca ultimul caracter ramas este 4,
astfel ca nu isi mai are rostul o verificare suplimentara. In momentul in care pe prima linie am terminat verificarea si totul este in regula, sar in
starea intermediara, iar astfel incepe aceeasi verificare pentru a doua linie, s.a.m.d. Stiu ca toate caracterele au fost diferite pe fiecare linie
daca am ajuns cu starea intermediara pe caracterul blank, iar atunci raspunsul este Y(yes).

Pentru al doilea task, skyscrapers_columns, am folosit aceeasi logica de la lines, diferenta fiind faptul ca pentru a avea verificarea pe coloane, a
trebuit sa sar intotdeauna la coloana pe care mi-o doresc, pentru a imi putea continua verificarea. Pentru prima coloana si ultima, a fost mai simplu
pentru ca nu a trebuit sa sar peste nicio coloana. Modul in care am parcurs matricea a fost urmatorul: pentru prima coloana verific ca exista un unic 1,
daca am ajuns la sfarsit si nu am intalnit vreo conditie de iesire, verific pentru ultima coloana ca exista un unic 1; am ajuns la inceput, verific ca
pe coloana 1 este un singur 2 si parcurg matricea in encodarea data de la stanga la dreapta. Daca totul a fost bine, fac aceeasi verificare pentru
existenta unui unic 2 pe coloana 4, parcurgand-o de la stanga la dreapta, s.a.m.d. Fac verificarea existentei unui unic 3 pe coloanele 1 si 4, iar pentru
caracterul 4, din nou, nu este nevoie sa mai verific. Pentru a avea aceeasi verificare ca pana acum si pentru coloanele 2 si 3, voi avea totusi nevoie de
cate o stare intermediara, cu ajutorul careia sar tot timpul peste prima, respectiv ultima coloana, iar din acea stare, sar in starea corespunzatoare
verificarii la care am ajuns, oricare ar fi caracterul pe care se afla. In momentul in care starea intermediara (cu care sar de la o linie la alta)
corespunzatoare cautarii caracterului 3 pe coloana 3 (si gasit) ajunge pe caracterul _, acela este cazul favorabil(Y).

Pentru task-ul 3, la partea de linii, am parcurs fiecare linie prima oara de la stanga la dreapta, retinand maximul gasit pana in momentul curent si
numarul de maxime gasite pana in punctul respectiv. Am cate o stare pentru fiecare combinatie, iar in momentul in care am ajuns cu starea respectiva
la un caracter : sau cand am ajuns sa gasesc maximul 4, ma intorc pana la inceputul liniei, pentru a verifica daca numarul de maxime gasite (coresp.
numelui starii) este acelasi cu numarul de vizibilitati. Dupa aceea, fac acelasi lucru pentru fiecare linie in parte, dar de la dreapta la stanga,
verificand numarul de maxime cu numarul de vizibilitati existent in dreapta. Daca verificarile vizibilitatilor pe linie au fost bune atat de la 
stanga la dreapta, cat si de la dreapta la stanga, pentru fiecare linie, incep verificarea pentru coloane. Pe scurt, pentru vizibilitatile pe coloane am 
folosit aceeasi logica ca pentru cele pe linii, doar ca am foarte multe stari intermediare de care ma folosesc pentru a sari pe coloanele de care am eu nevoie.

In task-ul 4, skyscrapers_final, am reunit codul pe care l-am scris pentru toate cele 3 probleme de mai sus. Din timpul redactarii celor 3, am tinut cont
ca numele niciunei stari sa nu se repete in 2 fisiere, pentru a nu avea probleme. In plus, am sters toate "Y, _, -" de pe parcurs, facand ca de la finalul
fiecarui task sa sar direct in starea initiala a urmatorului. Astfel, singurul moment in care se afiseaza Y este cand am ajuns cu bine la final, dupa
toate verificarile facute pentru linii, coloane si vizibilitati.

Tin sa mentionez ca tot codul meu este scris de mana. Chiar daca am folosit excesiv Ctrl+C, Ctrl+V, eu am facut fiecare modificare de care a fost nevoie. 