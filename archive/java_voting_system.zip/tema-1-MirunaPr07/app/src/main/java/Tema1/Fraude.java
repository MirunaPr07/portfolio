package Tema1;

import java.util.ArrayList;

public class Fraude {
    // am facut metoda statica, pentru a o putea apela din App direct cu Fraude.metoda
    // nu mai creez o instanta a acestei clase
    public static String fraude_vot(ArrayList<CreareAlegeri> alegeri, ArrayList<Votare> voturi, String id_caut, ArrayList<String> fraude, ArrayList<Votanti> votanti) {
        for (CreareAlegeri a : alegeri) {
            if (a.getId_alegeri().equals(id_caut)) {
                if (a.getInceput()) // eroare => nu s-a terminat votarea
                    return "EROARE: Inca nu s-a terminat votarea\n";
                String sir_bun, nume;
                nume = new String();
                sir_bun = new String();
                sir_bun = "Fraude comise:\n";
                String[] desparte;
                // am deja creat din App vectorul de fraude
                // am retinut datele de care am nevoie din momentul in care am gasit fraude in functia de votare
                if (!fraude.isEmpty()) {
                    for (int i = fraude.size() - 1; i >= 0; i--) {
                        // de la ultima frauda, la prima
                        desparte = fraude.get(i).split(" ");
                        if (desparte[0].equals(id_caut) && (i == fraude.size() - 1 || !fraude.get(i).equals(fraude.get(i + 1)))) {
                            // afisez fraudele distincte
                            for (Votanti v : votanti)
                                for (Votanti x : v.getDate_votanti())
                                    if (x.getCNP().equals(desparte[6])) {
                                        nume = x.getNume_votanti(); // caut in vectorul de votanti numele corespunzator CNP-ului retinut
                                        break;
                                    }
                            // creez sirul
                            sir_bun += "in " + desparte[1] + ": " + desparte[6] + " " + nume + "\n";
                        }
                    }
                }
                return sir_bun;
            }
        }
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
}