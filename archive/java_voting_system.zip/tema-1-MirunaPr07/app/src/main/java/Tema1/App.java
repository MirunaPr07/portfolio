package Tema1;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;
import java.text.*;

public class App {
    private Scanner scanner;

    public App(InputStream input) {
        this.scanner = new Scanner(input);
    }

    public void run() {
        // Implementati aici cerintele din enunt
        // Pentru citirea datelor de la tastatura se foloseste campul scanner.
        ArrayList<CreareAlegeri> alegeri = new ArrayList<>();
        ArrayList<Circumscriptii> circ = new ArrayList<>();
        ArrayList<Candidati> candidati = new ArrayList<>();
        ArrayList<Votanti> votanti = new ArrayList<>();
        ArrayList<Votare> voturi = new ArrayList<>();
        ArrayList<String> fraude = new ArrayList<>();
        // am creat cate un ArrayList pentru fiecare clasa relevanta, pe care le folosesc pe parcurs
        Votare VOT = new Votare("","","", "");
        Rapoarte RAP = new Rapoarte("", "", "", "");
        // am creat aceste variabile, VOT si RAP, doar pentru a putea apela prin intermediul lor metodele de care am nevoie din clasele resp.
        String sir; // in sir retin mereu output-ul primit pentru fiecare comanda
        // in momentul in care sir mi-a retinut o eroare, o afisez
        // altfel, suprascriu sir mereu cu ultimul output pozitiv, afisandu-l in final pe ultimul
        boolean ok;
        ok = false;
        // de ok ma folosesc ca sa stiu in final daca s-a afisat deja o eroare, sau trebuie sa afisez output-ul pozitiv
        sir = "\n";
        label:
        while (scanner.hasNextLine()) {
            String comanda = scanner.nextLine(); // citesc mereu o noua linie (comanda)
            switch (comanda) { // am considerat ca arata mai bine un switch
                case "0": {
                    String id, nume, sir_intreg;
                    String[] desparte;
                    sir_intreg = scanner.nextLine(); // citesc id-ul si numele alegerilor
                    desparte = sir_intreg.split(" ", 2); // despart sirul in doua siruri
                    id = desparte[0]; // primul este id-ul, al doilea numele, cu tot cu spatii
                    nume = desparte[1];
                    CreareAlegeri a = new CreareAlegeri(id, nume, false); // creez o alegere cu un nou id
                    sir = a.verif_exista(alegeri); // functia verifica daca exista deja alegeri cu acel id
                    if (sir.equals("EROARE: Deja exista alegeri cu id " + a.getId_alegeri() + "\n")) {
                        System.out.println(sir); // daca functia mi-a returnat acel sir, afisez eroarea
                        ok = true;
                        break label;
                    } else {
                        // altfel, pentru fiecare alegere cu id nou, adaug un nou element in urmatorii vectori:
                        Circumscriptii c;
                        c = new Circumscriptii(a.getId_alegeri(), a.getNume_alegeri(), a.getInceput());
                        circ.add(c);
                        Candidati x;
                        x = new Candidati(a.getId_alegeri(), a.getNume_alegeri(), a.getInceput());
                        candidati.add(x);
                        Votanti y;
                        y = new Votanti(a.getId_alegeri(), a.getNume_alegeri(), a.getInceput());
                        votanti.add(y);
                    }
                    break;
                }
                case "1": { // cand citesc comanda 1
                    // incep alegerile
                    String id;
                    id = scanner.nextLine();
                    CreareAlegeri a;
                    a = alegeri.get(0);
                    sir = a.verif_incepere(alegeri, id);
                    if (sir.equals("EROARE: Nu exista alegeri cu acest id\n") || sir.equals("EROARE: Alegerile deja au inceput\n")) {
                        // cazul de eroare, afisez sirul
                        System.out.println(sir);
                        ok = true;
                        break label;
                    } else {
                        // caut in fiecare vector dintre acestia obiectul cu acel id, si setez campul inceput ca true
                        for (Circumscriptii c : circ) {
                            if (c.getId_alegeri().equals(id)) {
                                c.setInceput(true);
                                break; // ies doar din for ul mic
                            }
                        }
                        for (Candidati x : candidati) {
                            if (x.getId_alegeri().equals(id)) {
                                x.setInceput(true);
                                break; // ies doar din for ul mic
                            }
                        }
                        for (Votanti y : votanti) {
                            if (y.getId_alegeri().equals(id)) {
                                y.setInceput(true);
                                break;
                            }
                        }
                    }
                    break;
                }
                case "2":
                case "3": {
                    // am facut un singur caz pentru 2 si 3 pentru ca mare parte a codului se aseamana
                    // aici am adaugare/ stergere circumscriptie
                    String sir_intreg, id, nume_circ, regiune;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ");
                    id = desparte[0];
                    nume_circ = desparte[1];
                    if (comanda.equals("2")) {
                        // daca adaug o circumscriptie, trebuie sa retin si regiunea
                        regiune = desparte[2];
                        sir = circ.get(0).adauga_circumscriptie(circ, nume_circ, id, regiune);
                        //m-am folosit de primul obiect din vectorul de circumscriptii ca sa apelez functia
                    } else {
                        // altfel, doar apelez functia de stergere
                        sir = circ.get(0).verif_sterge_circ(circ, nume_circ, id);
                    }
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "4": {
                    // adaugare un candidat
                    String sir_intreg, id, CNP, nume_candidat;
                    int varsta;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ", 4);
                    id = desparte[0];
                    CNP = desparte[1];
                    varsta = Integer.parseInt(desparte[2]);
                    nume_candidat = desparte[3];
                    // am extras din sir fiecare camp de care am nevoie pentru a crea candidatul
                    sir = candidati.get(0).adauga_candidat(candidati, id, CNP, varsta, nume_candidat);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "5": {
                    // sterg un candidat din vectorul de candidati
                    String sir_intreg, id, CNP;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ");
                    id = desparte[0];
                    CNP = desparte[1];
                    sir = candidati.get(0).sterge_candidat(candidati, id, CNP);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "6": {
                    // adaug un votant intr-o anumita circumscriptie
                    String sir_intreg, id, nume_circ, CNP, neindemanatic, nume_votant;
                    int varsta;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ", 6);
                    id = desparte[0];
                    nume_circ = desparte[1];
                    CNP = desparte[2];
                    varsta = Integer.parseInt(desparte[3]);
                    neindemanatic = desparte[4];
                    nume_votant = desparte[5];
                    // trimit si true/ false functiei, ca sa ma folosesc in functie de faptul ca este indemanatic sau nu
                    if (neindemanatic.equals("da"))
                        sir = votanti.get(0).adauga_votant(circ, votanti, id, nume_circ, CNP, varsta, true, nume_votant);
                    else
                        sir = votanti.get(0).adauga_votant(circ, votanti, id, nume_circ, CNP, varsta, false, nume_votant);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "7": {
                    // afisarea tuturor candidatilor
                    String id;
                    id = scanner.nextLine();
                    sir = candidati.get(0).afisare_candidati(candidati, id);
                    String[] aux;
                    aux = sir.split(" ");
                    // ori se afiseaza eroarea, ori candidatii in ordine cresc.
                    if (aux[0].equals("EROARE:") || aux[0].equals("GOL:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "8": {
                    // afisarea tuturor votantilor dintr-o circ.
                    String sir_intreg, id, nume_circ;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ");
                    id = desparte[0];
                    nume_circ = desparte[1];
                    sir = votanti.get(0).afiseaza_votanti(circ, votanti, id, nume_circ);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:") || aux[0].equals("GOL:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "9" : {
                    // votarea in sine
                    String sir_intreg, id, nume_circ, CNP_votant, CNP_candidat;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ");
                    id = desparte[0];
                    nume_circ = desparte[1];
                    CNP_votant = desparte[2];
                    CNP_candidat = desparte[3];
                    sir = VOT.vot(candidati, votanti, voturi, id, nume_circ, CNP_votant, CNP_candidat);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) { // si frauda o afisez tot la final, ca mesajul de succes
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    else if(aux[0].equals("FRAUDa:"))
                        fraude.add(id + " " + nume_circ + " " + sir + " " + CNP_votant);
                    // daca functia a returnat mesajul de frauda, retin ce imi trebuie in vectorul de fraude
                    break;
                }
                case "10" : {
                    // oprirea alegerilor
                    String id;
                    id = scanner.nextLine();
                    sir = VOT.oprire(alegeri, circ, candidati, votanti, id);
                    // fac pentru fiecare vector, obiectele corespunzatoare acelui id sa aiba variabila inceput false
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "11":
                case "13": {
                    // am facut si raportul per circumscriptie si analiza per circumscriptie in aceeasi metoda
                    // deoarece codul se asemana foarte mult
                    String sir_intreg, id, nume_circ;
                    String[] desparte;
                    sir_intreg = scanner.nextLine();
                    desparte = sir_intreg.split(" ");
                    id = desparte[0];
                    nume_circ = desparte[1];
                    // trimit metodei ca parametru si numarul comenzii, ca sa stiu cum gestionez partea separata a acestora
                    if (comanda.equals("11"))
                        sir = RAP.raport_circ(alegeri, circ, voturi, id, nume_circ, 11);
                    else
                        sir = RAP.raport_circ(alegeri, circ, voturi, id, nume_circ, 13);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:") || aux[0].equals("GOL:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }

                case "12":
                case "14": {
                    // aceeasi poveste ca la raport/ analiza per circumscriptie => metoda comuna
                    String id;
                    id = scanner.nextLine();
                    if (comanda.equals("12"))
                        sir = RAP.raport_national(alegeri, circ, voturi, id, 12);
                    else
                        sir = RAP.raport_national(alegeri, circ, voturi, id, 14);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:") || aux[0].equals("GOL:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "15" : {
                    // afisare fraude comise
                    String id;
                    id = scanner.nextLine();
                    sir = Fraude.fraude_vot(alegeri, voturi, id, fraude, votanti);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    else {
                        if (fraude.isEmpty()) // daca nu am retinut nicio frauda in partea de vot
                            sir = "GOL: Romanii sunt cinstiti\n";
                    }
                    break;
                }
                case "16" : {
                    // stergere alegeri
                    String id;
                    id = scanner.nextLine();
                    sir =  alegeri.get(0).sterge(alegeri, id);
                    String[] aux;
                    aux = sir.split(" ");
                    if (aux[0].equals("EROARE:")) {
                        System.out.println(sir);
                        ok = true;
                        break label;
                    }
                    break;
                }
                case "17" : {
                    // afisare alegeri
                    // nu am mai apelat nicio metoda
                    // a fost mai usor sa fac afisarea direct aici
                    if (alegeri.isEmpty())
                        System.out.println("GOL: Nu sunt alegeri");
                    else {
                        sir = "Alegeri:\n";
                        for (CreareAlegeri a : alegeri)
                            System.out.println(a.getId_alegeri() + " " + a.getNume_alegeri() + "\n");
                    }
                    break;
                }
            }
        }
        // daca nu s-a afisat nicio eroare/ caz special, afisez aici ultima concluzie buna retinuta in sir
        if (!ok) {
            System.out.println(sir);
        }
    }

    public static void main(String[] args) {
        App app = new App(System.in);
        app.run();
    }
}