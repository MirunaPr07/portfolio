package Tema1;

import java.util.ArrayList;

public class CreareAlegeri {
    String id_alegeri, nume_alegeri;
    boolean inceput; // variabilele specifice unei alegeri
    // constructorul:
    CreareAlegeri(String id_alegeri_nou, String nume_alegeri_nou, boolean inceput_nou) {
        this.id_alegeri = id_alegeri_nou;
        this.nume_alegeri = nume_alegeri_nou;
        this.inceput = inceput_nou;
    }
    void setId_alegeri(String id_alegeri_nou) {
        this.id_alegeri = id_alegeri_nou;
    }
    void setNume_alegeri(String nume_alegeri_nou) {
        this.nume_alegeri = nume_alegeri_nou;
    }
    void setInceput(boolean inceput_nou) {
        this.inceput = inceput_nou;
    }
    String getId_alegeri() {
        return this.id_alegeri;
    }
    String getNume_alegeri() {
        return this.nume_alegeri;
    }
    boolean getInceput() {
        return this.inceput;
    }
    String verif_exista(ArrayList<CreareAlegeri> alegeri) {
        for (CreareAlegeri a : alegeri) {
            // parcurg fiecare element al array-ului de alegeri
            // daca exista un obiect cu acel id deja, returnez sirul de eroare
            if (a.getId_alegeri().equals(this.id_alegeri)) {
                return "EROARE: Deja exista alegeri cu id " + a.getId_alegeri() + "\n";
            }
        }
        // daca am iesit din for si am ajuns aici, inseamna ca sunt pe cazul favorabil
        // adaug obiectul curent in vectorul de alegeri
        alegeri.add(this);
        return "S-au creat alegerile " + this.nume_alegeri + "\n";
    }
    String verif_incepere(ArrayList<CreareAlegeri> alegeri, String id) {
        for(CreareAlegeri a : alegeri) {
            if (a.getId_alegeri().equals(id)) {
                // ajung aici daca gasesc in vector un elem de tip CreareAlegeri care are acel id
                if (a.getInceput()) {
                    // daca alegerile deja au inceput, returnez mesaj de eroare
                    return "EROARE: Alegerile deja au inceput\n";
                }
                else {
                    // cazul bun, setez inceputul acelui obiect la true
                    a.setInceput(true);
                    return "Au pornit alegerile " + a.getNume_alegeri() + "\n";
                }
            }
        }
        // daca nu am ajuns sa intru nici macar o data in if-ul mare
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    String sterge(ArrayList<CreareAlegeri> alegeri, String id_caut) {
        for (CreareAlegeri a : alegeri) {
            if (a.getId_alegeri().equals(id_caut)) {
                // daca am gasit in vector obiectul cu acel id, il elimin din vector
                alegeri.remove(a);
                return "S-au sters alegerile " + a.getNume_alegeri() + "\n";
            }
        }
        // inseamna ca nu a intrat in if => mesaj de eroare
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
}
