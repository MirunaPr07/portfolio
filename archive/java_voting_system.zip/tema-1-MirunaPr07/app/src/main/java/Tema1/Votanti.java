package Tema1;

import java.util.ArrayList;
import java.util.Collections;

public class Votanti extends Circumscriptii implements Comparable {
    String CNP, nume_votanti;
    int varsta;
    boolean neindemanatic;
    // aceeasi logica si la Candidati
    // vector mic pt fiecare obiect, in care retin datele votantului
    ArrayList<Votanti> date_votanti;
    Votanti(String id_alegeri_nou, String nume_alegeri_nou, boolean inceput_nou) {
        super(id_alegeri_nou, nume_alegeri_nou, inceput_nou);
        this.CNP = "";
        this.nume_votanti = "";
        this.varsta = 0;
        this.neindemanatic = false;
        this.date_votanti = new ArrayList<>();
    }
    String getCNP() {
        return CNP;
    }
    void setCNP(String CNP_nou) {
        this.CNP = CNP_nou;
    }
    String getNume_votanti() {
        return this.nume_votanti;
    }
    void setNume_votanti(String nume_votanti_nou) {
        this.nume_votanti = nume_votanti_nou;
    }
    int getVarsta() {
        return this.varsta;
    }
    void setVarsta(int varsta_nou) {
        this.varsta = varsta_nou;
    }
    boolean getNeindemanatic() {
        return this.neindemanatic;
    }
    void setNeindemanatic(boolean neindemanatic_nou) {
        this.neindemanatic = neindemanatic_nou;
    }
    ArrayList<Votanti> getDate_votanti() {
        return this.date_votanti;
    }
    void setDate_votanti(Votanti date_votanti_nou) {
        this.date_votanti.add(date_votanti_nou);
    }

    String adauga_votant(ArrayList <Circumscriptii> circ, ArrayList<Votanti> votanti, String id_caut, String nume_circ_caut, String CNP_nou, int varsta_nou, boolean neindemanatic_nou, String nume_nou) {
        // fac cautarea direct in vectorul votanti, pt ca are datele din vect de circumscriptii
        boolean gas_circ;
        gas_circ = false;
        // verif erori
        if (CNP_nou.length() != 13)
            return "EROARE: CNP invalid\n";
        if (varsta_nou < 18)
            return "EROARE: Varsta invalida\n";
        // verific daca exista acea circ in vect de circ.
        for (Circumscriptii c : circ) {
            for (String y : c.getNume_circumscriptii())
                if (y.equals(nume_circ_caut)) {
                    gas_circ = true;
                    break;
                }
            if (gas_circ)
                break;
        }
        if (!gas_circ) // nu exista circ. => eroare
            return "EROARE: Nu exista o circumscriptie cu numele " + nume_circ_caut + "\n";
        else {
            for (Votanti v : votanti) { // parcurg vectorul mare
                if (v.getId_alegeri().equals(id_caut)) { // exista acel id in vect.
                    if (!v.getInceput())
                        return "EROARE: Nu este perioada de votare\n";
                    for (Votanti y : v.getDate_votanti()) // parc. vect mic cu datele votantilor
                        if (y.getCNP().equals(CNP_nou)) {
                            return "EROARE: Votantul " + y.getNume_votanti() + " are deja acelasi CNP\n";
                        }
                    // creez un nou votant, pe care il adaug in vectorul mic
                    Votanti v_nou = new Votanti(v.getId_alegeri(), v.getNume_alegeri(), v.getInceput());
                    v_nou.setCNP(CNP_nou);
                    v_nou.setVarsta(varsta_nou);
                    v_nou.setNeindemanatic(neindemanatic_nou);
                    v_nou.setNume_votanti(nume_nou);
                    v_nou.setNume_circumscriptie(nume_circ_caut);
                    v.setDate_votanti(v_nou); // setDate adauga elem. creat la sfarsitul vect mic de votanti al obiectului bun gasit in cel mare
                    return "S-a adaugat votantul " + nume_nou + "\n";
                }
            }
            return "EROARE: Nu exista alegeri cu acest id\n";
        }
    }
    // comparare dupa CNP-ul votantilor
    public int compareTo(Object o) {
        Votanti x;
        x = (Votanti) o;
        return this.CNP.compareTo(x.getCNP());
    }
    String afiseaza_votanti(ArrayList<Circumscriptii> circ, ArrayList<Votanti> votanti, String id_caut, String nume_circ_caut) {
        boolean gas_bun = false;
        for (Circumscriptii c : circ) {
            for (String y : c.getNume_circumscriptii())
                if (y.equals(nume_circ_caut)) {
                    gas_bun = true;
                    break;
                }
            if (gas_bun)
                break;
        }
        // nu am gasit circ. cu acel nume
        if (!gas_bun)
            return "EROARE: Nu exista o circumscriptie cu numele " + nume_circ_caut + "\n";
        gas_bun = false;
        for (Votanti v : votanti) {
            if (v.getId_alegeri().equals(id_caut)) {
                if (!v.getInceput()) // am gasit acel id, dar nu au inceput alegerile
                    return "EROARE: Inca nu au inceput alegerile\n";
                gas_bun = true;
                break;
            }
        }
        // nu s-au gasit alegeri cu acel id
        if (!gas_bun)
            return "EROARE: Nu exista alegeri cu acest id\n";
        Votanti votanti_caut;
        votanti_caut = new Votanti("", "", false);
        // imi creez acest obiect in care retin votantii din circ. care imi trebuie
        for (Votanti v : votanti) {
            if (v.getId_alegeri().equals(id_caut)) {
                for (Votanti x : v.getDate_votanti())
                    for (String y : x.getNume_circumscriptii())
                        if (y.equals(nume_circ_caut)) {
                            votanti_caut.setDate_votanti(x); // pun in vectorul de votanti al variabilei care imi tb. val coresp. cu numele circ. bun
                        }
                break;
            }
        }
        if (votanti_caut.getDate_votanti().isEmpty()) // nu am gasit niciunul
            return "GOL: Nu sunt votanti in " + nume_circ_caut + "\n";
        // sortez datele retinute in obiectul creat
        Collections.sort(votanti_caut.getDate_votanti()); // sortez vectorul pe care mi l am creat in interiorul variabilei votanti_caut
        String sir_final;
        sir_final = new String();
        // in final, imi creez sirul pe care il returnez, in functie de datele retinute
        sir_final += "Votantii din " + nume_circ_caut + ":";
        for (Votanti v : votanti_caut.getDate_votanti()) {
            sir_final += v.getNume_votanti();
            sir_final += " ";
            sir_final += v.getCNP();
            sir_final += " ";
            sir_final += v.getVarsta();
            sir_final += "\n";
        }
        return sir_final;
    }
}
