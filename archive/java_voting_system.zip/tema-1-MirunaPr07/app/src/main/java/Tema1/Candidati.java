package Tema1;

import java.util.ArrayList;
import java.util.Collections;

public class Candidati extends CreareAlegeri implements Comparable {
    String CNP, nume_candidati;
    int varsta;
    // vectorul mare de candidati retine, la fel ca cel de Circumscriptii, in mare, id-ul
    // retin, pentru fiecare obiect din vector, si acest vector date_candidati
    ArrayList<Candidati> date_candidati;
    Candidati(String id_alegeri_nou, String nume_alegeri_nou, boolean inceput_nou) {
        super(id_alegeri_nou, nume_alegeri_nou, inceput_nou);
        this.CNP = "";
        this.nume_candidati = "";
        this.varsta = 0;
        this.date_candidati = new ArrayList<>();
    }
    String getCNP() {
        return this.CNP;
    }
    void setCNP(String CNP_nou) {
        this.CNP = CNP_nou;
    }
    String getNume_candidati() {
        return this.nume_candidati;
    }
    void setNume_candidati(String nume_candidati_nou) {
        this.nume_candidati = nume_candidati_nou;
    }
    int getVarsta() {
        return this.varsta;
    }
    void setVarsta(int varsta_nou) {
        this.varsta = varsta_nou;
    }
    ArrayList<Candidati> getDate_candidati() {
        return this.date_candidati;
    }
    void setDate_candidati(Candidati date_candidati_nou) {
        this.date_candidati.add(date_candidati_nou);
    }
    String adauga_candidat(ArrayList<Candidati> candidati, String id_caut, String CNP_nou, int varsta_nou, String nume_nou) {
        // verificari erori
        if (CNP_nou.length() != 13) {
            return "EROARE: CNP invalid\n";
        } else if (varsta_nou < 35) {
            return "EROARE: Varsta invalida\n";
        } else {
            for (Candidati x : candidati) {
                for (Candidati y : x.getDate_candidati()) // daca gasesc in vectorul efectiv cu datele fiecarui candidat CNP-ul cautat
                    if (y.getCNP().equals(CNP_nou)) // eroare => deja exista
                        return "EROARE: Candidatul " + y.getNume_candidati() + " are deja acelasi CNP\n";
            }
            for (Candidati x : candidati) {
                if (x.getId_alegeri().equals(id_caut)) { // am gasit elem din vect mare cu acel id
                    if (!x.getInceput()) { // nu au inceput alegerile => eroare
                        return "EROARE: Nu este perioada de votare\n";
                    }
                    else {
                        Candidati y;
                        y = new Candidati(x.getId_alegeri(), x.getNume_alegeri(), x.getInceput());
                        // am creat un nou candidat cu datele trimise ca param.
                        y.setCNP(CNP_nou);
                        y.setVarsta(varsta_nou);
                        y.setNume_candidati(nume_nou);
                        // adaug in vectorul cu datele candidatilor acest candidat creat, in obiectul cu id-ul cautat din vect. mare
                        x.setDate_candidati(y);
                        return "S-a adaugat candidatul " + nume_nou + "\n";
                    }
                }
            }
            return "EROARE: Nu exista alegeri cu acest id\n";
        }
    }
    String sterge_candidat(ArrayList<Candidati> candidati, String id_caut, String CNP_caut) {
        for (Candidati x : candidati) {
            if (x.getId_alegeri().equals(id_caut)) {
                if (!x.getInceput()) {
                    return "EROARE: Nu este perioada de votare\n";
                }
                else {
                    for (Candidati y : x.getDate_candidati())
                        if (y.getCNP().equals(CNP_caut)) {
                            x.getDate_candidati().remove(y); // il sterg din vectorul mic
                            return "S-a sters candidatul " + y.getNume_candidati() + "\n";
                        }
                    return "EROARE: Nu exista un candidat cu CNP-ul " + CNP_caut + "\n";
                }
            }
        }
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    // sortare dupa CNP a doua elemente de tip Candidati
    public int compareTo(Object o) {
        Candidati x;
        x = (Candidati) o;
        return this.CNP.compareTo(x.getCNP());
    }
    String afisare_candidati(ArrayList<Candidati> candidati, String id_caut) {
        for (Candidati x : candidati) {
            if (x.getId_alegeri().equals(id_caut)) {
                if (!x.getInceput())
                    return "EROARE: Inca nu au inceput alegerile\n";
                if (x.getDate_candidati().isEmpty()) // daca nu am candidati, nu am ce afisa
                    return "GOL: Nu sunt candidati\n";
                // cazul favorabil
                // sortez vectorul cu datele candidatilor al elem. din vectorul mare cu id-ul cautat
                Collections.sort(x.getDate_candidati());
                String aux;
                // imi creez sirul pe care il voi returna
                aux = new String();
                aux = "Candidatii:\n";
                for (Candidati y : x.getDate_candidati()) {
                    aux += y.getNume_candidati();
                    aux += " ";
                    aux += y.getCNP();
                    aux += " ";
                    aux += y.getVarsta();
                    aux += "\n";
                }
                return aux;
            }
        }
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
}