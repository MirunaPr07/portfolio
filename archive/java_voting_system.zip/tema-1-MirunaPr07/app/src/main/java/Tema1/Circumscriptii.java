package Tema1;

import java.util.ArrayList;

public class Circumscriptii extends CreareAlegeri {
    // vectorul de circumscriptii, circ, din App il folosesc mai mult ca sa retin cate o instanta a alegerilor cu acel id
    // pentru fiecare element de tip circumscriptii din vector, am un ArrayList de siruri, in care retin numele circumscr. pr-zise
    ArrayList<String> nume_circumscriptii;
    ArrayList<String> nume_regiuni;
    // la fel si pentru regiuni
    Circumscriptii(String id_alegeri, String nume_alegeri, boolean inceput) {
        super(id_alegeri, nume_alegeri, inceput);
        this.nume_circumscriptii = new ArrayList<>();
        this.nume_regiuni = new ArrayList<>();
    }
    // adauga sirul in vectorul de siruri (nume de circ.)
    void setNume_circumscriptie(String nume_circumscriptie_nou) {
        this.nume_circumscriptii.add(nume_circumscriptie_nou);
    }
    // returneaza tot vectorul
    ArrayList<String> getNume_circumscriptii() {
        return this.nume_circumscriptii;
    }
    void setNume_regiuni(String nume_regiune_nou) {
        this.nume_regiuni.add(nume_regiune_nou);
    }
    ArrayList<String> getNume_regiuni() {
        return this.nume_regiuni;
    }
    String adauga_circumscriptie(ArrayList<Circumscriptii> circ, String nume_circ, String id_caut, String regiune) {
        for (Circumscriptii c : circ) {
            // daca gasesc in vectorul de circumscriptii un obiect cu acel id
            if (c.getId_alegeri().equals(id_caut)) {
                if (!c.getInceput()) {
                    // caz de eroare => nu au inceput alegerile
                    return "EROARE: Nu este perioada de votare\n";
                } else {
                    for (String s : c.getNume_circumscriptii()) {
                        // parcurg sirurile(numele de circumscriptii) din elementul cu acel id
                        if (s.equals(nume_circ)) {
                            // daca gasesc un sir in vectorul de siruri care are deja acel nume => eroare
                            return "EROARE: Deja exista o circumscriptie cu numele " + nume_circ + "\n";
                        }
                    }
                }
                // adaugarile in vector
                c.setNume_circumscriptie(nume_circ);
                c.setNume_regiuni(regiune);
                return "S-a adaugat circumscriptia " + nume_circ + "\n";
            }
        }
        // nu s-a intrat in if-ul mare
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    String verif_sterge_circ(ArrayList<Circumscriptii> circ, String nume_circ, String id_caut) {
        for (Circumscriptii c : circ) {
            if (c.getId_alegeri().equals(id_caut)) {
                if (!c.getInceput())
                    return "EROARE: Nu este perioada de votare\n";
                for (String s : c.getNume_circumscriptii()) {
                    if (s.equals(nume_circ)) {
                        // am gasit in vectorul de siruri din instanta cu acel id numele circ. pe care o caut
                        c.getNume_circumscriptii().remove(s); // sterg din vectorul de siruri acel sir
                        return "S-a sters circumscriptia " + nume_circ + "\n";
                    }
                }
                // nu am gasit deloc acel nume de circ in vectorul de siruri al obiectului cu acel id
                return "EROARE: Nu exista o circumscriptie cu numele " + nume_circ;
            }
        }
        // daca am ajuns aici, nici nu a intrat in if-ul mare => nu exista circ cu acel id in vect. de circ
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    void sortare(ArrayList<Circumscriptii> circ, String id_caut) {
        for (Circumscriptii c : circ) {
            if (c.getId_alegeri().equals(id_caut)) {
                // am gasit obiectul de tip Circumscriptii din vect. cu acel id
                for (int j = 1; j <= c.getNume_regiuni().size(); j++) {
                    // un fel de bubble sort putin mai urat
                    for (int i = 0; i <= c.getNume_regiuni().size() - 2; i++) {
                        // sortare descrescatoare dupa numele regiunilor
                        if (c.getNume_regiuni().get(i).compareTo(c.getNume_regiuni().get(i + 1)) < 0) {
                            String aux;
                            aux = c.getNume_regiuni().get(i);
                            c.getNume_regiuni().set(i, c.getNume_regiuni().get(i + 1));
                            c.getNume_regiuni().set(i + 1, aux);
                            // interschimb sirurile din vectorii de nume de regiuni
                            aux = c.getNume_circumscriptii().get(i);
                            c.getNume_circumscriptii().set(i, c.getNume_circumscriptii().get(i + 1));
                            c.getNume_circumscriptii().set(i + 1, aux);
                            // interschimb sirurile din vectorii de nume de circumscriptii
                            // le interschimb pe ambele odata, pentru ca la un anumit index sa am numele circumscriptiei
                            // si numele regiunii in care e acea circumscriptie
                        }
                    }
                }
            }
        }
    }
}
