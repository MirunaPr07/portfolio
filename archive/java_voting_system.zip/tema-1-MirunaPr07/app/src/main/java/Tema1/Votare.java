package Tema1;

import java.util.ArrayList;

public class Votare implements Comparable {
    String id_alegeri;
    String nume_circumscriptie;
    String CNP_votant, CNP_candidat, nume_candidat;
    ArrayList<String> circumscr = new ArrayList<>();
    int nr_voturi;
    public Votare(String id_alegeri_nou, String nume_circ_nou, String CNP_votant_nou, String CNP_candidat_nou) {
        this.id_alegeri = id_alegeri_nou;
        this.nume_circumscriptie = nume_circ_nou;
        this.CNP_votant = CNP_votant_nou;
        this.CNP_candidat = CNP_candidat_nou;
    }
    public ArrayList<String> getCircumscr() {
        return this.circumscr;
    }
    public void setCircumscr(String circumscr_nou) {
        this.circumscr.add(circumscr_nou);
    }
    public int getNr_voturi() {
        return this.nr_voturi;
    }
    public void setNr_voturi(int nr_voturi_nou) {
        this.nr_voturi = nr_voturi_nou;
    }
    public String getNume_candidat() {
        return this.nume_candidat;
    }
    public void setNume_candidat(String nume_candidat_nou) {
        this.nume_candidat = nume_candidat_nou;
    }
    public String getId_alegeri() {
        return this.id_alegeri;
    }
    public void setId_alegeri(String id_alegeri_nou) {
        this.id_alegeri = id_alegeri_nou;
    }
    public String getNume_circumscriptie() {
        return this.nume_circumscriptie;
    }
    public void setNume_circumscriptie(String nume_circ_nou) {
        this.nume_circumscriptie = nume_circ_nou;
    }
    public String getCNP_votant() {
        return this.CNP_votant;
    }
    public void setCNP_votant(String CNP_votant_nou) {
        this.CNP_votant = CNP_votant_nou;
    }
    public String getCNP_candidat() {
        return this.CNP_candidat;
    }
    public void setCNP_candidat(String CNP_candidat_nou) {
        this.CNP_candidat = CNP_candidat_nou;
    }
    String vot(ArrayList<Candidati> candidati, ArrayList<Votanti> votanti, ArrayList<Votare> voturi, String id_caut, String nume_circ_caut, String CNP_votant, String CNP_candidat) {
        // fac verificarile pt erori pe vectorul de candidati
        boolean exista = false;
        String nume_cand = "";
        String nume_votant = "";
        for (Candidati c : candidati) {
            if (c.getId_alegeri().equals(id_caut)) { // caut instanta vectorului de candidati cu acel id
                if (!c.getInceput()) // eroare
                    return "EROARE: Nu este perioada de votare";
                for (Candidati y : c.getDate_candidati())
                    if (y.getCNP().equals(CNP_candidat)) {
                        nume_cand = y.getNume_candidati(); // retin numele, pt crearea sirului returnat
                        for (Votanti v : votanti) {
                            if (v.getId_alegeri().equals(id_caut)) {
                                for (Votanti x : v.getDate_votanti()) {
                                    for (String s : x.getNume_circumscriptii())
                                        if (s.equals(nume_circ_caut)) { // am gasit circumscriptia cu acel nume
                                            exista = true;
                                            break;
                                        }
                                    if (exista)
                                        break;
                                }
                            }
                            if (exista)
                                break;
                        }
                        if (!exista) // nu s-a facut exista true => nu exista circumscriptia
                            return "EROARE: Nu exista o circumscriptie cu numele " + nume_circ_caut + "\n";
                        exista = false;
                        for (Votanti v : votanti) {
                            for (Votanti x : v.getDate_votanti())
                                if (x.getCNP().equals(CNP_votant)) {
                                    exista = true; // retin faptul ca exista votantul cu acel CNP
                                    break;
                                }
                            if (exista)
                                break;
                        }
                        if (!exista)
                            return "EROARE: Nu exista votant cu CNP-ul " + CNP_votant + "\n";
                        exista = false;
                        for (Votanti v : votanti) {
                            if (v.getId_alegeri().equals(id_caut)) {
                                for (Votanti x : v.getDate_votanti()) {
                                    if (x.getCNP().equals(CNP_votant)) {
                                        nume_votant = x.getNume_votanti(); // retin numele votantului cu CNP-ul cautat
                                        for (String s : x.getNume_circumscriptii())
                                            if (s.equals(nume_circ_caut)) {
                                                exista = true;
                                                break;
                                            }
                                    }
                                }
                                if (exista)
                                    break;
                            }
                            if(exista)
                                break;
                        }
                        if (!exista) { // caz de frauda => nu are circ. aceea
                            return "FRAUDa: Votantul cu CNP-ul " + CNP_votant + " a incercat sa comita o frauda. Votul a fost anulat" + "\n";
                        }
                        for (Votare v : voturi) {
                            if (v.getId_alegeri().equals(id_caut) && v.getNume_circumscriptie().equals(nume_circ_caut)) {
                                if (v.getCNP_votant().equals(CNP_votant)) {
                                    // a mai votat acel votant (se gaseste deja in vectorul de voturi)
                                    return "FRAUDa: Votantul cu CNP-ul " + CNP_votant + " a incercat sa comita o frauda. Votul a fost anulat" + "\n";
                                }
                            }
                        }
                        // cazul favorabil => creez votul
                        Votare vot_nou;
                        vot_nou = new Votare(id_caut, nume_circ_caut, CNP_votant, CNP_candidat);
                        vot_nou.setNume_candidat(nume_cand);
                        vot_nou.setNume_circumscriptie(nume_circ_caut);
                        // adaug votul creat in vectorul de voturi
                        voturi.add(vot_nou);
                        return nume_votant + " a votat pentru " + nume_cand + "\n";
                    }
                return "EROARE: Nu exista un candidat cu CNP-ul " + CNP_candidat + "\n";
            }
        }
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    String oprire(ArrayList<CreareAlegeri> alegeri, ArrayList<Circumscriptii> circ, ArrayList<Candidati> candidati, ArrayList<Votanti> votanti, String id_caut) {
        for (CreareAlegeri a : alegeri) {
            if (a.getId_alegeri().equals(id_caut)) {
                if (!a.getInceput()) // inceput e deja false
                    return "EROARE: Nu este perioada de votare\n";
                // cand opresc alegerile, modific in toti vectorii mari (fol. in principal pt id), inceput ca false
                a.setInceput(false);
                for (Circumscriptii c : circ) {
                    if (c.getId_alegeri().equals(id_caut)) {
                        c.setInceput(false);
                    }
                }
                for (Candidati c : candidati) {
                    if (c.getId_alegeri().equals(id_caut)) {
                        c.setInceput(false);
                        for (Candidati y : c.getDate_candidati())
                            y.setInceput(false);
                    }
                }
                for (Votanti v : votanti) {
                    if (v.getId_alegeri().equals(id_caut)) {
                        v.setInceput(false);
                        for (Votanti y : v.getDate_votanti())
                            y.setInceput(false);
                    }
                }
                return "S-au terminat alegerile " + a.getNume_alegeri() + "\n";
            }
        }
        // nu am gasit alegeri cu id-ul ala
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    // functie de comparare a doua elemente de tip Votare (fol mai tarziu)
    public int compareTo(Object o) {
        Votare x;
        x = (Votare) o;
        if (this.getNr_voturi() != x.getNr_voturi())
            return Integer.compare(x.getNr_voturi(), this.getNr_voturi()); // ord descrescator => ordine inv a arg.
        return x.getCNP_candidat().compareTo(this.getCNP_candidat());
    }
}