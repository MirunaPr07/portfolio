package Tema1;

import java.util.ArrayList;
import java.util.Collections;

public class Rapoarte extends Votare {
    Rapoarte(String id_alegeri_nou, String nume_circ_nou, String CNP_votant_nou, String CNP_candidat_nou) {
        super(id_alegeri_nou, nume_circ_nou, CNP_votant_nou, CNP_candidat_nou);
    }
    // aceasta clasa o folosesc doar pt metodele din ea
    // prima metoda face si raport per circumscriptie si analiza per circumscriptie
    public String raport_circ(ArrayList<CreareAlegeri> alegeri, ArrayList<Circumscriptii> circ, ArrayList<Votare> voturi, String id_caut, String nume_circ_caut, int comanda) {
        ArrayList<Votare> vect_voturi, vect_final; // imi creez un vector cu voturile care imi tb
        vect_voturi = new ArrayList<Votare>();
        vect_final = new ArrayList<Votare>();
        boolean ok;
        int nr_voturi_circ, nr_voturi_total;
        nr_voturi_circ = 0;
        nr_voturi_total = 0;
        for (CreareAlegeri a : alegeri) {
            if (a.getId_alegeri().equals(id_caut)) {
                if (a.getInceput()) // e inceput dar nu e terminat
                    return "EROARE: Inca nu s-a terminat votarea\n";
                for (Circumscriptii c : circ) {
                    if (c.getId_alegeri().equals(id_caut)) {
                        for (String y : c.getNume_circumscriptii())
                            if (y.equals(nume_circ_caut)) {
                                for (Votare v : voturi) {
                                    nr_voturi_total++; // incrementez nr de voturi total
                                    if (v.getId_alegeri().equals(id_caut) && v.getNume_circumscriptie().equals(nume_circ_caut)) {
                                        nr_voturi_circ++; // incrementez nr de voturi din circ cautata
                                        vect_voturi.add(v); // adaug in acest vector provizoriu voturile care imi convin
                                    }
                                }
                                if (vect_voturi.isEmpty()) // nu am retinut niciun vot pe acea circ.
                                    return "GOL: Lumea nu isi exercita dreptul de vot in " + nume_circ_caut + "\n";
                                for (Votare v : vect_voturi) {
                                    ok = false;
                                    // creez vectorul final, pe baza celui provizoriu
                                    for (Votare x : vect_final)
                                        if (x.getCNP_candidat().equals(v.getCNP_candidat())) {
                                            x.setNr_voturi(x.getNr_voturi() + 1); // cresc numarul de voturi retinut pentru candidatul curent
                                            ok = true;
                                        }
                                    if (!ok) {
                                        Votare nou;
                                        // daca nu exista deja acel candidat in vect_final, il adaug aici
                                        nou = new Votare(id_caut, nume_circ_caut, v.getCNP_votant(), v.getCNP_candidat());
                                        nou.setNume_candidat(v.getNume_candidat());
                                        nou.setNr_voturi(1); // numarul lui de voturi pana in acest punct e initializat cu 1( e primul lui vot gasit)
                                        vect_final.add(nou);
                                    }
                                }
                                // aici mai am sa imi sortez vectorul final si dupa sa imi creez sirul
                                Collections.sort(vect_final);
                                String sir = new String();
                                if (comanda == 11) {
                                    // cazul pentru raport
                                    sir = "Raport voturi " + nume_circ_caut + ":\n";
                                    for (Votare v : vect_final) {
                                        sir += v.getNume_candidat();
                                        sir += " ";
                                        sir += v.getCNP_candidat();
                                        sir += " - ";
                                        sir += v.getNr_voturi();
                                        sir += "\n";
                                    }
                                }
                                else {
                                    // cazul pentru analiza
                                    sir = "in " + nume_circ_caut + " au fost " + nr_voturi_circ + " voturi din " + nr_voturi_total + ". ";
                                    sir += "Adica " + nr_voturi_circ * 100 / nr_voturi_total + "%";
                                    sir += ". Cele mai multe voturi au fost stranse de " + vect_final.get(0).getCNP_candidat() + " " + vect_final.get(0).getNume_candidat() + ". ";
                                    sir += "Acestea constituie " + vect_final.get(0).getNr_voturi() * 100 / nr_voturi_circ + "% din voturile circumscriptiei.\n";
                                }
                                return sir;
                            }
                        return "EROARE: Nu exista o circumscriptie cu numele " + nume_circ_caut + "\n";
                    }
                }
            }
        }
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
    public String raport_national(ArrayList<CreareAlegeri> alegeri, ArrayList<Circumscriptii> circ, ArrayList<Votare> voturi, String id_caut, int comanda) {
        ArrayList<Votare> vect_final, vect_voturi; // imi creez un vector cu voturile care imi tb
        vect_final = new ArrayList<Votare>();
        vect_voturi = new ArrayList<Votare>();
        int nr_voturi_total;
        nr_voturi_total = 0;
        boolean ok;
        // aproape aceeasi gandire ca la raport_circ
        for (CreareAlegeri a : alegeri) {
            if (a.getId_alegeri().equals(id_caut)) {
                if (a.getInceput()) // e inceput dar nu e terminat
                    return "EROARE: Inca nu s-a terminat votarea\n";
                for (Votare v : voturi) {
                    if (v.getId_alegeri().equals(id_caut)) {
                        vect_voturi.add(v); // imi creez vectorul de baza, cu voturile din id-ul cautat
                        nr_voturi_total++; // totodata, retin si numarul de voturi pe toata alegerea
                    }
                }
                if (vect_voturi.isEmpty())
                    return "GOL: Lumea nu isi exercita dreptul de vot in Romania\n";
                String sir = new String();
                for (Votare v : vect_voturi) {
                    ok = false;
                    for (Votare x : vect_final)
                        if (x.getCNP_candidat().equals(v.getCNP_candidat())) {
                            x.setNr_voturi(x.getNr_voturi() + 1); // imi incrementez nr de voturi ale acelui candidat
                            x.setCircumscr(v.getNume_circumscriptie()); // retin si fiecare circumscriptie
                            ok = true;
                        }
                    if (ok == false) {
                        //System.out.println(v.getNume_circumscriptie() + "\n");
                        Votare nou;
                        // daca nu exista deja acel candidat in vectorul final, il adaug acum
                        nou = new Votare(id_caut, v.getNume_circumscriptie(), v.getCNP_votant(), v.getCNP_candidat());
                        nou.setCircumscr(v.getNume_circumscriptie());
                        nou.setNume_candidat(v.getNume_candidat());
                        nou.setNr_voturi(1); // doar un vot are momentan
                        vect_final.add(nou);
                    }
                }
                // aici mai am sa imi sortez vectorul final si dupa sa imi creez sirul
                Collections.sort(vect_final);
                if (comanda == 12) {
                    // cazul de raport (merge 100%)
                    sir = "Raport voturi Romania:\n";
                    for (Votare v : vect_final) {
                        sir += v.getNume_candidat();
                        sir += " ";
                        sir += v.getCNP_candidat();
                        sir += " - ";
                        sir += v.getNr_voturi();
                        sir += "\n";
                    }
                }
                else {
                    circ.get(0).sortare(circ, id_caut); // imi sortez vectorul de circumscriptii descresc
                    sir += "in Romania au fost " + nr_voturi_total + " voturi.\n";
                    for (Circumscriptii c : circ) {
                        if (c.getId_alegeri().equals(id_caut)) {
                            int i = 0, j, suma, index = 0;
                            // aici am tratat problema precum una de secvente
                            // retin indexul din vector la care am prima si ultima aparitie a numelui regiunii curente
                            while (i != c.getNume_regiuni().size()) {
                                j = i;
                                while (j != c.getNume_regiuni().size() - 1 && c.getNume_regiuni().get(j).equals(c.getNume_regiuni().get(j + 1)))
                                    j++;
                                sir += "in " + c.getNume_regiuni().get(j) + " au fost ";
                                suma = 0;
                                for (int y = i; y <= j; y++) {
                                    for (Votare v : vect_final) {
                                        for (String s : v.getCircumscr())
                                            if (s.equals(c.getNume_circumscriptii().get(y)))
                                                suma++;
                                    }
                                }
                                sir += suma + " voturi din " + nr_voturi_total + ". Adica ";
                                sir += suma * 100 / nr_voturi_total + "%. ";
                                sir += "Cele mai multe voturi au fost stranse de ";
                                sir += vect_final.get(index).getCNP_candidat() + " " + vect_final.get(index).getNume_candidat() + ". ";
                                // pana in punctul acesta, sirul este perfect, afisandu-mi exact ce mi-am dorit
                                int voturi_candidat = 0;
                                for (String s : vect_final.get(index).getCircumscr()) {
                                    for (Votare v : vect_voturi) {
                                        if (v.getNume_circumscriptie().equals(s) && v.getCNP_candidat().equals(vect_final.get(index).getCNP_candidat())) {
                                            voturi_candidat++;
                                        }
                                    }
                                }
                                // aici ceva nu este bine, nu imi calculeaza bine voturi_candidat, motiv pentru care nu imi face bine calculul procentajului
                                // => nu imi primesc punctajul pe un test
                                sir += "Acestea constituie " + voturi_candidat * 100 / suma + "% din voturile regiunii.\n";
                                // System.out.println("\n");
                                i = j + 1;
                                index++;
                            }
                        }
                    }
                }
                return sir;
            }
        }
        return "EROARE: Nu exista alegeri cu acest id\n";
    }
}
