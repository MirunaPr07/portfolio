document.addEventListener('DOMContentLoaded', () => {
    lista = document.getElementById("todo_list"); // lista tuturor task urilor
    todo_nou = document.getElementById("adaug_todo"); // aici adaug un nou todo
    count = document.getElementById("count");
    filtre = document.querySelectorAll(".buton"); // aici retin butoanele pentru filtre
    mark = document.getElementById("mark");
    clear = document.getElementById("clear");
    todos = []; // lista de task uri
    filtru_curent = "all"; // by default, la inceput stau pe All
    function update() {
        lista.innerHTML = ''; // mereu la inceput nu am nimic in lista
        // aplic filtrul pe lista mea de task uri
        let todos_filtrate = todos.filter(todo => {
            if (filtru_curent === "all") {
                return true; // dc am all afisez tot
            } else if (filtru_curent === "active") {
                return todo.completed === false; // aici doar pe cele necompletate
            } else if (filtru_curent === "completed") {
                return todo.completed === true; // si aici completatele
            }
        });

        // adaug task urile in lista
        todos_filtrate.forEach((todo, index) => {
            let li = document.createElement("li"); // fac un element de lista
            // daca task ul e completat, adaug lui li clasa completed
            if (todo.completed == true)
                li.classList.add("completed");
            else
                li.classList.remove("completed"); // ma asigur ca nu e
            // fac un checkbox pt task ul curent
            let checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.checked = todo.completed; // completed e ori true ori false
            checkbox.addEventListener("change", () => {
                todo.completed = checkbox.checked; // ii actualizez starea lui completed dc am dat check
                update(); // dau update dupa ce am pus un nou task
            });
            // creez un elem html pentru textul task ului
            let text = document.createElement("span");
            text.textContent = todo.text; // pun text ul din todo ul curent
            text.addEventListener("dblclick", () => { // cod pt double click
                let input = document.createElement("input"); // creez un input nou in care sa pun textul nou
                input.type = "text";
                input.value = todo.text; // iau textul scris
                input.addEventListener('blur', () => { // cand dau orice,
                    todo.text = input.value.trim(); // salvez noul text
                    update();
                });
                input.addEventListener("keypress", (e) => {
                    if (e.key == 'Enter') {
                        input.blur(); // la fel si la enter, salvez
                    }
                });
                li.replaceChild(input, text); // inc=locuirea pr zisa
                input.focus();
            });
            let delete_button = document.createElement("button"); // fac un nou buton pt stergerea task ului
            delete_button.textContent = "x";
            delete_button.addEventListener("click", () => {
                todos.splice(index, 1); // la click sterg acel task
                update(); // si ii dau update
            });
            // Adaugam elementele in lista (checkbox, text, buton de stergere)
            li.appendChild(checkbox);
            li.appendChild(text);
            li.appendChild(delete_button); // ii dau toate proprietatile 
            lista.appendChild(li); // pun elementul nou creat in lista
        });
        // Actualizam contorul de task-uri ramase
        let ramase;
        ramase = todos.filter(todo => todo.completed == false).length; // retin cate task uri sunt necompletate
        count.textContent = ramase + " items left"; // pt a mi afisa jos numarul de task uri ramsee
    }
    // event ca sa adaug un nou task la enter
    todo_nou.addEventListener("keypress", (e) => {
        if (e.key == "Enter" && todo_nou.value.trim()) { // daca am apasat enter SI am ceva text introdus
            todos.push({ text: todo_nou.value.trim(), completed: false }); // pun task ul facut in lista, cu completed false by default
            todo_nou.value = ''; // fac campul de input gol la loc
            update(); // update listei
        }
    });
    filtre.forEach(button => {
        button.addEventListener("click", () => {
            filtre.forEach(btn => btn.classList.remove("active")); // elimin active de la toate butoanele
            button.classList.add("active"); // setez active la butonul pe care am dat click
            filtru_curent = button.id; // salvez filtrul
            update();
        });
    });
    clear.addEventListener("click", () => { // sterg task uri completate
        todos = todos.filter(todo => todo.completed == false); // le pastrez doar pe cele necompletate
        update();
    });
    mark.addEventListener("click", () => {
        todos.forEach(todo => todo.completed = true); // le pun pe toate drept completed
        update();
    });
    // update la final
    update();
});
