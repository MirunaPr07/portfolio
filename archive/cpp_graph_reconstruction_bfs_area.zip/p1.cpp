#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <queue>
#include <algorithm>

using namespace std;

// mi am facut o functie separata care verifica daca distantele care mi au
// iesit din bfs
// din nodul 1 corespund cu vectorul de distante dat din fisier
// raspunsul e true/false

bool verif_distante(int N, vector<pair<int, int>> &muchii,
                    vector<int> &v_distante) {
    vector<vector<int>> lista_ad(N + 1);  // lista de adiacenta pentru graf
    // pun fiecare muchie in lista de adiacenta
    for (auto& m : muchii) {
        lista_ad[m.first].push_back(m.second);
        lista_ad[m.second].push_back(m.first);
    }
    vector<int> distante_reale(N + 1, -1);  // initial, toate dist = -1 (neviz.)
    queue<int> coada;
    distante_reale[1] = 0;  // distanta de la 1 la el e 0
    coada.push(1);
    // asta e pur si simplu bfs:
    while (coada.empty() == NULL) {
        int u;
        u = coada.front();
        coada.pop();
        for (int v : lista_ad[u]) {
            if (distante_reale[v] == -1) {
                distante_reale[v] = distante_reale[u] + 1;
                coada.push(v);
            }
        }
    }
    // si in final fac comparatia propriu-zisa
    for (int i = 0; i <= N - 1; i++) {
        if (distante_reale[i + 1] != v_distante[i]) {
            return false;
        }
    }
    return true;
}

int main() {
    ifstream fin("p1.in");
    ofstream fout("p1.out");
    int N;
    fin >> N;
    vector<int> v(N);  // asta e vectorul cu distantele dorite
    unordered_map<int, vector<int>> nivele;  // grupez nodurile pe nivel
    // (practic distanta)
    // citesc distantele si construiesc map ul de nivele
    for (int i = 0; i <= N - 1; i++) {
        fin >> v[i];
        nivele[v[i]].push_back(i + 1);
    }
    // verific daca nodul 1 are distanta 0 si este singur pe nivelul 0
    if (v[0] != 0 || nivele[0].size() != 1) {
        fout << -1 << '\n';
        return 0;
    }
    vector<pair<int, int>> muchii;  // lista cu muchiile din graf
    // construiesc graful parcurgand nivelele in ordine
    for (int d = 1; nivele.count(d) != 0; d++) {
        if (nivele.count(d - 1) == 0) {
            fout << -1 << '\n';
            return 0;
        }
        vector<int> parinti = nivele[d - 1];  // noduri de la nivelul anterior
        vector<int> copii = nivele[d];       // noduri de la nivelul curent
        int p;                                // p e indexul parintelui fol.
        p = 0;
        for (int nod : copii) {
            // leg fiecare copil de un parinte in mod circular
            muchii.emplace_back(parinti[p], nod);
            // si apoi trec la urmatorul parinte:
            p = (p + 1) % parinti.size();
        }
    }
    // daca am prea multe muchii sau distantele nu se potrivesc => caz invalid
    if (muchii.size() > 1000000 || verif_distante(N, muchii, v) == 0) {
        fout << -1 << '\n';
        return 0;
    }
    // altfel, afisez toate muchiile
    fout << muchii.size() << '\n';
    for (auto [u, v] : muchii)
        fout << u << " " << v << '\n';
    return 0;
}
