#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

// vectorii astia ma ajuta sa merg in sus/jos/stanga/dreapta:
int dx[] = {-1, 1, 0, 0};
int dy[] = {0, 0, -1, 1};

// fac un bfs care porneste dintr-o celula (i, j) si
// se extinde doar in interiorul intervalului [min_val, max_val]
// in visited marchez ce celule am vizitat ca sa nu le iau de doua ori
int bfs(int i, int j, vector<vector<int>>& matrice,
        vector<vector<bool>>& vizitat, int n, int m,
        int min_val, int max_val) {
    queue<pair<int, int>> coada;
    coada.push({i, j});
    vizitat[i][j] = true;
    int arie = 1;  // incepe cu 1 ca am pornit dintr o celula valida
    while (coada.empty() == NULL) {
        pair<int, int> current;
        current = coada.front();
        coada.pop();
        int x, y;
        x = current.first;
        y = current.second;
        for (int k = 0; k <= 3; k++) {
            int nx, ny;
            nx = x + dx[k];
            ny = y + dy[k];
            // verific daca vecinul e in matrice si in interval
            if (nx >= 0 && nx < n && ny >= 0 &&
                ny < m && vizitat[nx][ny] == 0) {
                int val;
                val = matrice[nx][ny];
                if (val >= min_val && val <= max_val) {
                    vizitat[nx][ny] = true;
                    coada.push({nx, ny});
                    arie++;
                }
            }
        }
    }
    return arie;
}

int main() {
    ifstream fin("p2.in");
    ofstream fout("p2.out");
    int n, m, k;
    fin >> n >> m >> k;
    // citesc matricea si salvez toate valorile unice intr un vector
    vector<vector<int>> matrice(n, vector<int>(m));
    vector<int> valori;
    for (int i = 0; i <= n - 1; i++) {
        for (int j = 0; j <= m - 1; j++) {
            fin >> matrice[i][j];
            valori.push_back(matrice[i][j]);
        }
    }
    // sortez si elimin duplicatele din vectorul de valori
    sort(valori.begin(), valori.end());
    valori.erase(unique(valori.begin(), valori.end()), valori.end());
    int arie_maxima = 0;
    // incerc fiecare valoare ca minim posibil pentru intervalul [min, min + k]
    for (int i = 0; i <= valori.size() - 1; i++) {
        int min_val, max_val;
        min_val = valori[i];
        max_val = min_val + k;
        // pregatesc o matrice in care marchez ce celule sunt in interval
        // si vizitate
        vector<vector<bool>> vizitat(n, vector<bool>(m, false));
        for (int x = 0; x <= n - 1; x++) {
            for (int y = 0; y <= m - 1; y++) {
                if (matrice[x][y] < min_val || matrice[x][y] > max_val) {
                    vizitat[x][y] = true;  // o marchez direct ca vizitata ca
                    // sa o ignor
                }
            }
        }
        // fac bfs din fiecare celula nevizitata:
        for (int x = 0; x <= n - 1; x++) {
            for (int y = 0; y <= m - 1; y++) {
                if (vizitat[x][y] == 0) {
                    int arie_crt;
                    arie_crt = bfs(x, y, matrice, vizitat, n, m,
                                   min_val, max_val);
                    arie_maxima = max(arie_maxima, arie_crt);
                }
            }
        }
    }
    fout << arie_maxima << '\n';
    return 0;
}
