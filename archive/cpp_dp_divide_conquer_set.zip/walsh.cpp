#include <iostream>
#include <fstream>

using namespace std;

bool divide_et_impera(int linie, int coloana, int m) {
    // linie si coloana le trimit functiei ca sa stie ce cauta

    // functia mea foloseste tehnica Divide Et Impera pentru ca mereu imi reduc
    // problema intreaga la o problema pe un sfert de matrice, impart problema
    // mereu in 4 si mi se reduce la o problema care tine strict de partea din
    // stanga sus a matricii
    if (m == 1)
        return 0;
    int mijloc;
    mijloc = m / 2;
    if (linie > mijloc && coloana > mijloc)
        return 1 - divide_et_impera(linie - mijloc, coloana - mijloc, mijloc);
    else {
        if (linie > mijloc)
            linie -= mijloc;
        if (coloana > mijloc)
            coloana -= mijloc;
        // aduc totul in stanga sus (toate celelalte in afara de dr jos sunt ac lucru)
        return divide_et_impera(linie, coloana, mijloc);
    }
}

int main() {
    ifstream fin("walsh.in");
    ofstream fout("walsh.out");
    // nici nu am nevoie sa construiesc matricea, e doar un dei
    int m, nr_intrari, linie, coloana;
    fin >> m >> nr_intrari;
    // am certitudinea ca m este mereu o putere a lui 2
    for (int i = 0; i <= nr_intrari - 1; i++) {
        fin >> linie >> coloana;
        fout << divide_et_impera(linie, coloana, m) << "\n";
    }
    return 0;
}