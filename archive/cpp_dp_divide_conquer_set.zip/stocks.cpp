#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int pd_discret(int nr_actiuni, int suma, int pierdere_max,
               vector<int> &curent, vector<int> &minim, vector<int> &maxim) {
    // dp[investitie][pierdere] = profit maxim posibil
    vector<vector<int>> dp(suma + 1, vector<int>(pierdere_max + 1));
    for (int i = 0; i <= suma; i++)
        for (int j = 0; j <= pierdere_max; j++)
            dp[i][j] = -1;  // cu -1 imi codific in matrice ca nu am ajuns in acel punct

    dp[0][0] = 0;  // initial nu am nimic cumparat => 0
    for (int i = 1; i <= nr_actiuni; i++) {
        int pierd, castig;
        pierd = curent[i] - minim[i];
        castig = maxim[i] - curent[i];
        // parcurg matrivcea invers ca sa nu pot lua o actiune de mai multe ori
        for (int j = suma; j >= curent[i]; j--)
            for (int k = pierdere_max; k >= pierd; k--)
                if (dp[j - curent[i]][k - pierd] != -1)  // daca am ajuns in acel punct 
                    dp[j][k] = max(dp[j][k],
                                   dp[j - curent[i]][k - pierd] + castig);  // vad daca mi ar
								   //  conveni sa completez solutia anterioara cu castigul curent
    }
    // imi parcurg dp si caut maximul ca sa il returnez
    // diferenta fata de rucsac este ca aici maximul este pe o pozitie random,
    // nu mai e pe ultimul loc in matrice (dp[suma][pierdere_max])
    int maxx = -1;
    for (int i = 0; i <= suma; i++)
        for (int j = 0; j <= pierdere_max; j++)
            if (dp[i][j] > maxx)
                maxx = dp[i][j];
    return maxx;
}

int main() {
    ifstream fin("stocks.in");
    ofstream fout("stocks.out");
    int nr_actiuni, suma, pierdere_max;
    vector<int> curent(100), minim(100), maxim(100);  // nr_actiuni e maxim 100
    fin >> nr_actiuni >> suma >> pierdere_max;
    // problema asta mi s a prut de la inceput exact stilul de problema
    // asemanatoare cu rucsac discret, asa ca o voi aborda cu pd
    for (int i = 1; i <= nr_actiuni; i++)
        fin >> curent[i] >> minim[i] >> maxim[i];
    fout << pd_discret(nr_actiuni, suma, pierdere_max, curent, minim, maxim);
    return 0;
}
