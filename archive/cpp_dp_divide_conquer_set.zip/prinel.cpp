#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

void creare_vector(int nr_elem, vector<int> &target, vector<int> &transformari) {
    // am ales sa creez elementele vectorului transformari cu ajutorul unei cozi,
    // cu logica unui BFS
    // initial, am incercat sa simulez coada cu ajutorul uni vector, insa primeam
    // TLE, pentru ca e mult mai costisitor sa accesez un element dintr-un vector,
    // chiar daca ii retin mereu index-ul curent, decat sa folosesc queue si
    // functiile predefinite

    int maxx;
    maxx = -1;  // imi calculez maximul din vectorul de target-uri
    for (int i = 1; i <= nr_elem; i++) {
        if (target[i] > maxx)
            maxx = target[i];
    }

    // imi retin divizorii pentru toate valorile de pana la maxx
    // in divizori[i] am toti divizorii lui i, iar maxx l-am calculat ca sa stiu
    // cand ma pot opri
    vector<vector<int>> divizori(maxx + 1);
    vector<int> dp(maxx + 1);
    queue<int> coada;

    for (int i = 1; i <= maxx; i++) {
        for (int j = i; j <= maxx; j += i) {
            divizori[j].push_back(i);
        }
    }

    // e gandirea ca pentru ciur: pentru o valoare i, adaug in vector ca divizor
    // pe i pentru toate valorile multiple de i (mi le creez eu -> valorile la
    // care voi pune i ca fiind divizor)

    // asta e partea de bfs:
    for (int i = 2; i <= maxx; i++)
        dp[i] = -1;  // nu am ajuns inca in acel punct

    dp[1] = 0;  // caz sep pt ca nu am nev de nimic ca sa ajung la 1

    // e clar ca in dp imi construiesc numarul min. de pasi pentru a ajunge din 1
    // in target[i]
    coada.push(1);
    while (!coada.empty()) {
        int x;
        x = coada.front();
        coada.pop();
        // mi am extras elementul curent de la suprafata cozii si pt fiecare div
        // al lui voi calcula urmatorul
        for (auto d : divizori[x]) {
            int urm;
            urm = x + d;
            if (urm <= maxx && dp[urm] == -1) {
                // daca si valoarea calc. e inca <= maximul, imi retin cazul curent
                // pentru dp
                dp[urm] = dp[x] + 1;
                coada.push(urm);
            }
        }
    }

    // pun toate calculele retinute in vectorul de transformari (cazurile
    // favorabile gasite)
    for (int i = 1; i <= nr_elem; i++) {
        transformari[i] = dp[target[i]];
    }
}

int dp_discret(int nr_elem, int max_operatii,
               vector<int> &castiguri, vector<int> &transformari) {
    // mereu imi retin in dp[i] castigul maxim pe care il pot avea cu fix i
    // transformari
    vector<int> dp(max_operatii + 1);
    for (int i = 1; i <= max_operatii; i++)
        dp[i] = -1;  // initial, nicio combinatie potrivita pentru niciun index

    dp[0] = 0;  // 0 operatii si 0 castiguri (de la asta plec)

    for (int i = 1; i <= nr_elem; i++) {
        // imi retin intr-o variabila separata elementul curent in transformari
        // pentru ca altfel il tot accesam si timpul era prea mare
        int cost;
        cost = transformari[i];
        if (cost != -1 && cost <= max_operatii) {
            // imi convine varianta asta
            for (int j = max_operatii; j >= cost; j--) {
                // invers pentru ca nu trebuie sa pun de mai multe ori ac. elem.
                if (dp[j - cost] != -1) {
                    // daca am o solutie valida deja calculata la punctul anterior
                    dp[j] = max(dp[j], dp[j - cost] + castiguri[i]);
                    // o retin la punctul curent pe cea mai satisfacatoare
                }
            }
        }
    }

    // iar in final, caut maximul din vectorul de dp
    int maxx;
    maxx = -1;
    for (int i = 0; i <= max_operatii; i++) {
        if (dp[i] > maxx)
            maxx = dp[i];
    }
    return maxx;
}

int main() {
    ifstream fin("prinel.in");
    ofstream fout("prinel.out");
    int nr_elem, max_operatii;
    fin >> nr_elem >> max_operatii;

    vector<int> target(1000), castiguri(1000), transformari(1000);
    for (int i = 1; i <= nr_elem; i++)
        fin >> target[i];
    for (int i = 1; i <= nr_elem; i++)
        fin >> castiguri[i];

    // prima mea intuitie a fost sa construiesc un vector nou (transformari), in
    // care sa imi retin de cate transformari am nevoie pentru a trece din 1
    // (initial) in target[i]
    creare_vector(nr_elem, target, transformari);

    // dupa, folosindu-ma de vectorul nou creat (cat mai putine transformari) si
    // de vectorul de castiguri (cat mai mari), sa folosesc logica de la rucsac
    // discret (programare dinamica) la fel ca la stocks, modificata a.i sa mi se
    // plieze pe problema
    fout << dp_discret(nr_elem, max_operatii, castiguri, transformari);
    return 0;
}
