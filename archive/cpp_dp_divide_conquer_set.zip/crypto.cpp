#include <iostream>
#include <fstream>
#include <vector>
#include <set>

using namespace std;
const int MOD = 1000000007;
const char SEMN = '?';

// in functia de dp imi calculez de cate ori apare subsir in cheile valide
int dp_subsiruri(int lg_cheie, int lg_subsir,
                 string &cheie, string &subsir) {
    // am ales sa folosesc o variabila de tip set ca sa nu retin duplicate
    set<char> litere_posibile(subsir.begin(), subsir.end());

    // verific ca daca in cheie exista o litera stiuta care nu apare in subsir
    // si daca exista, returnez 0
    for (int c = 0; c <= lg_cheie - 1; c++) {
        if (cheie[c] != SEMN &&
            litere_posibile.find(cheie[c]) == litere_posibile.end()) {
            return 0;
        }
    }

    vector<long long> dp(lg_subsir + 1);  // in dp[i] am nr de moduri de a forma
    // prefixul lui subsir de la 0 la i
    dp[0] = 1;  // sirul vid apare mereu ca subsir

    for (int i = 0; i <= lg_cheie - 1; i++) {
        vector<long long> urm;
        urm = dp;  // imi creez o copie pt dp ca sa o pot modif.

        if (cheie[i] == SEMN) {
            // parcurg vectorul de dp si inmultesc fiecare elem cu nr de lit
            // posibile din subsir
            // practic, pot continua orice combinatie de pana acum in mai
            // multe moduri
            for (int j = 0; j <= lg_subsir; j++) {
                urm[j] = (urm[j] * litere_posibile.size()) % MOD;
            }

            // dupa, incerc sa prelungesc prefixul daca litera se potriveste
            // pt fiecare litera pe care as putea pune-o in loc de semnul de "?"
            for (char c : litere_posibile) {
                for (int j = lg_subsir - 1; j >= 0; j--) {
                    if (c == subsir[j]) {
                        // daca litera la care sunt coresp. literei din subsir
                        // de pe poz. j
                        urm[j + 1] = (urm[j + 1] + dp[j]) % MOD;
                        // pot extinde un subsir de lg l cu o lit.
                    }
                }
            }
        } else {
            // caz separat daca stiu litera curenta din cheie
            for (int j = lg_subsir - 1; j >= 0; j--) {
                if (cheie[i] == subsir[j]) {
                    // aici doar incerc sa o potrivesc cu subsir
                    urm[j + 1] = (urm[j + 1] + dp[j]) % MOD;
                }
            }
        }

        dp = urm;
    }

    return dp[lg_subsir];
}

int main() {
    ifstream fin("crypto.in");
    ofstream fout("crypto.out");
    int lg_cheie, lg_subsir;
    string cheie, subsir;
    fin >> lg_cheie >> lg_subsir >> cheie >> subsir;

    // mi-am creat functia separata care se ocupa de partea de programare dinamica
    fout << dp_subsiruri(lg_cheie, lg_subsir, cheie, subsir);
    return 0;
}
