#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct lista {
	char info;
	struct lista *urm, *ant;
	struct lista *locomotiva, *mecanic; //locomotiva e considerata santinela
} TCelula, *TLista;

typedef struct {
	TLista prim, ultim; //pentru prim si ultim ma voi folosi doar de elementele specifice listei, nu si de locomotiva sau mecanic
} coada;

int init_tren(TLista *tren) {
	//trebuie sa imi aloc spatiu pentru tren, mai apoi pentru santinela/locomotiva si pentru primul vagon
	TLista aux, aux2, aux3;
	aux = malloc(sizeof(TCelula)); //unde imi pointeaza aux imi aloc memorie de o celula
	aux2 = malloc(sizeof(TCelula));
	aux3 = malloc(sizeof(TCelula));
	if (aux == NULL || aux2 == NULL || aux3 == NULL)
		return 0;
	*tren = aux;
	(*tren)->locomotiva = aux2;
	(*tren)->mecanic = aux3;
	//acum trebuie sa fac legaturile intre locomotiva si santinela
	(*tren)->locomotiva->urm = (*tren)->mecanic;
	(*tren)->locomotiva->ant = (*tren)->mecanic;
	(*tren)->mecanic->info = '#';
	(*tren)->mecanic->ant = (*tren)->locomotiva;
	(*tren)->mecanic->urm = (*tren)->locomotiva;
	return 1;
}

int init_comenzi(coada **comenzi) { //pointer catre adresa comenzii ca sa pot modifica adresa in afara functiei
	*comenzi = malloc(sizeof(coada));
	if (comenzi == NULL)
		return 0;
	(*comenzi)->prim = NULL;
	(*comenzi)->ultim = NULL;
	return 1;
}

void pune_in_coada(coada **comenzi, char c) {
	//folosidu ma de functia asta voi modifica coada astfel incat in ea sa pun valorile coresp. operatiilor pe care le voi face cand voi primi execute
	TLista aux;
	if ((*comenzi)->prim == NULL) {//cazul in care nu am niciun element in coada
		aux = malloc(sizeof(TCelula));
		if (aux == NULL) {
			printf("ERR");
			return;
		}
		aux->info = c;
		aux->urm = NULL;
		aux->ant = NULL;
		(*comenzi)->prim = aux;
		(*comenzi)->ultim = aux;
	}
	else {
		aux = malloc(sizeof(TCelula));
		if (aux == NULL) {
			printf("ERR");
			return;
		}
		aux->info = c;
		aux->urm = NULL;
		(*comenzi)->ultim->urm = aux;
		aux->ant = (*comenzi)->ultim;
		(*comenzi)->ultim = aux;

	}
}

void show(FILE *file_out, TLista tren) {
	TLista p;
	for (p = tren->locomotiva->urm; p!= tren->locomotiva; p = p->urm) {
		if (p == tren->mecanic)
			fprintf(file_out, "|%c|", p->info);
		else fprintf(file_out, "%c", p->info);
	}
	fprintf(file_out, "\n");
}

void move_left(TLista *tren) {
	//daca mecanicul e in primul vagon il mut in ultimul
	if ((*tren)->mecanic->ant == (*tren)->locomotiva)
		(*tren)->mecanic = (*tren)->locomotiva->ant;
	else (*tren)->mecanic = (*tren)->mecanic->ant; //altfel il mut efectiv la stanga
}

void move_right(FILE *file_out, TLista *tren) {
	if ((*tren)->mecanic->urm == (*tren)->locomotiva) { //inseamna ca mecanicul e in ultimul vagon
		TLista aux; //trebuie sa imi aloc memorie pentru un nou vagon
		aux = malloc(sizeof(TCelula));
		if (aux == NULL) {
			fprintf(file_out, "ERR");
			return;
		}
		aux->info = '#';
		aux->ant = (*tren)->mecanic;
		aux->urm = (*tren)->locomotiva;
		(*tren)->locomotiva->ant = aux;
		(*tren)->mecanic->urm = aux;
		(*tren)->mecanic = aux;
	}
	else (*tren)->mecanic = (*tren)->mecanic->urm;
}

void write(TLista *tren, int *nr_val, char puse_tren[]) {
	//trebuie sa schimb valoarea vagonului in care e mecanicul
	(*tren)->mecanic->info = puse_tren[0];
	int i;
	for (i = 0; i<=(*nr_val)-2; i++)
		puse_tren[i] = puse_tren[i+1];
	(*nr_val)--; //numarul valorilor ramase in vectorul de valori ce trebuie puse in tren scade oricum
}

void clear_cell(TLista *tren) {
	if ((*tren)->mecanic->urm == (*tren)->locomotiva && (*tren)->mecanic->ant == (*tren)->locomotiva) {//cazul in care trenul are un singur vagon
		(*tren)->mecanic->info = '#';
		return;
	}
	if ((*tren)->mecanic->ant == (*tren)->locomotiva) { //cazul in care mecanicul se afla in primul vagon
		TLista aux, urmator;
		aux = (*tren)->mecanic;
		urmator = (*tren)->mecanic->urm;
		(*tren)->mecanic = (*tren)->locomotiva->ant; //mut mecanicul in ultimul vagon
		(*tren)->locomotiva->urm = urmator;
		urmator->ant = (*tren)->locomotiva;
		free(aux);
		return;
	}
	//cand elimin un vagon oarecare
	TLista aux, urmator;
	aux = (*tren)->mecanic; //retin intr o variabila auxiliara vagonul pe care il sterg
	urmator = aux->urm;
	(*tren)->mecanic = (*tren)->mecanic->ant; //mut mecanicul direct la stanga
	(*tren)->mecanic->urm = urmator;
	urmator->ant = (*tren)->mecanic;
	free(aux);
}

void clear_all(TLista *tren) {
	(*tren)->mecanic = (*tren)->locomotiva->ant; //ma folosesc de variabila mecanic ca sa merg de la ultimul vagon pana la primul
	while ((*tren)->mecanic != (*tren)->locomotiva->urm) { //cat timp nu am ajuns la primul vagon
		TLista aux = (*tren)->mecanic;
		(*tren)->mecanic = (*tren)->mecanic->ant;
		free(aux);
	}
	//acum mecanicul a ramas pe primul vagon
	(*tren)->mecanic->info = '#';
	(*tren)->mecanic->urm = (*tren)->locomotiva;
	(*tren)->locomotiva->ant = (*tren)->mecanic; //iar locomotiva->urm e deja mecanicul si mecanic->ant e deja locomotiva
}

void insert_left(FILE *file_out, TLista *tren, int val) {
	if ((*tren)->mecanic->ant == (*tren)->locomotiva) {//daca mecanicul e in primul vagon
		fprintf(file_out, "ERROR\n");
		return;
	}
	TLista aux;
	aux = malloc(sizeof(TCelula));
	if (aux == NULL) {
		fprintf(file_out, "ERR");
		return;
	}
	TLista anterior;
	//inserez un element intre anterior si mecanic
	anterior = (*tren)->mecanic->ant;
	aux->info = val;
	aux->urm = (*tren)->mecanic;
	aux->ant = anterior;
	anterior->urm = aux;
	(*tren)->mecanic->ant = aux;
	(*tren)->mecanic = aux;
}

void insert_right(FILE *file_out, TLista *tren, int val) {
	TLista aux;
	aux = malloc(sizeof(TCelula));
	if (aux == NULL) {
		fprintf(file_out, "ERR");
		return;
	}
	TLista urmator;
	//inserez dupa mecanic si inainte de urmator
	//functioneaza si in cazul in care mecanicul e in ultimul vagon -> urmator e locomotiva
	urmator = (*tren)->mecanic->urm;
	aux->info = val;
	aux->ant = (*tren)->mecanic;
	aux->urm = urmator;
	(*tren)->mecanic->urm = aux;
	urmator->ant = aux;
	(*tren)->mecanic = aux;
}

void search(FILE *file_out, TLista *tren, char sir[]) {
	int lg_sir, ok, pas = 1, i;
	TLista maxim, x, p;
	lg_sir = strlen (sir);
	for (p = (*tren)->mecanic; ; p = p->urm) { //p e vagonul de la care ar putea incepe sirul
		if (p == (*tren)->locomotiva)
			p = p->urm;
		ok = 1;
		x = p; //cu x parcurg lg_sir vagoane incepand cu p
		if (x == (*tren)->mecanic && pas!=1) { //daca am luat o de la capat cu cautarea de la mecanic in dreapta si nu e chiar primul pas
			fprintf(file_out, "ERROR\n");
			return;
		}
		for (i = 0; i <= lg_sir-1 && ok == 1; i++) {
			if (sir[i] != x->info) //nu corespunde valoarea din tren cu valoarea din sir
				ok = 0;
			x = x->urm;
			if (x == (*tren)->locomotiva)
				x = x->urm;
		}
		if (ok == 1) {
			(*tren)->mecanic = p;
			return;
		}
		pas++;
	}
}

void search_left(FILE *file_out, TLista *tren, char sir[]) {
	int lg, ok = 1, i;
	lg = strlen(sir);
	TLista p, x;
	//pornesc cu p de la adresa mecanicului
	for (p = (*tren)->mecanic; ; p = p->ant) {
		x = p;
		for (i = 0; i <= lg-1 && ok == 1; i++) {
			if (x == (*tren)->locomotiva) { //aici ajung daca nu se gaseste sirul in tren
				fprintf(file_out, "ERROR\n");
				return;
			}
			if (x->info != sir[i])
				ok = 0;
			x = x->ant;
		}
		if (ok == 1) { //atunci x reprezinta vagonul din stanga ultimului vagon corespunzator ultimului caracter din sir
			(*tren)->mecanic = x->urm;//x s a mai mutat o data la stanga
			return;
		}
		ok = 1;
	}
}
void search_right (FILE *file_out, TLista *tren, char sir[]) {
	int lg, ok = 1, i;
	lg = strlen(sir);
	TLista p, x;
	//pornesc cu p de la adresa mecanicului
	for (p = (*tren)->mecanic; ; p = p->urm) {
		x = p;
		for (i = 0; i <= lg-1 && ok == 1; i++) {
			if (x == (*tren)->locomotiva) { //aici ajung daca nu se gaseste sirul in tren
				fprintf(file_out, "ERROR\n");
				return;
			}
			if (x->info != sir[i])
				ok = 0;
			x = x->urm;
		}
		if (ok == 1) { //atunci x reprezinta vagonul din dreapta ultimului vagon corespunzator ultimului caracter din sir
			(*tren)->mecanic = x->ant; //x s a mai mutat o data la dreapta
			return;
		}
		ok = 1;
	}
}

void execute(FILE *file_out, coada **comenzi, TLista *tren, int *nr_val, char puse_tren[], char siruri[][100], int *cate_siruri) {
	int i;
	if ((*comenzi)->prim->info == '0')
		move_left(tren);
	else if ((*comenzi)->prim->info == '1')
			move_right(file_out, tren);
		else if ((*comenzi)->prim->info == '2')
			write(tren, nr_val, puse_tren);
			else if ((*comenzi)->prim->info == '3')
				clear_cell(tren);
				else if ((*comenzi)->prim->info == '4')
					clear_all(tren);
					else if ((*comenzi)->prim->info == '5') {
						insert_left(file_out, tren, puse_tren[0]);
						for (i = 0; i <= (*nr_val) - 2; i++) //fac aici instructiunile prin care elimin din vectorul de valori de pus in tren elementul pus ca sa nu mai trimit 3 var ca param
							puse_tren[i] = puse_tren[i + 1];
						(*nr_val)--;
					}
						else if ((*comenzi)->prim->info == '6') {
							insert_right(file_out, tren, puse_tren[0]);
							for (i = 0; i <= (*nr_val) - 2; i++)
								puse_tren[i] = puse_tren[i + 1];
							(*nr_val)--;
						}
							else if ((*comenzi)->prim->info == '7') {
								search(file_out, tren, siruri[0]);
								for (i = 0; i <= (*cate_siruri) - 2; i++)
									strcpy(siruri[i], siruri[i + 1]);
								(*cate_siruri)--;
							}
								else if ((*comenzi)->prim->info == '8') {
									search_left(file_out, tren, siruri[0]);
									for (i = 0; i <= (*cate_siruri) - 2; i++)
										strcpy(siruri[i], siruri[i + 1]);
									(*cate_siruri)--;
								}
									else if ((*comenzi)->prim->info == '9') {
										search_right(file_out, tren, siruri[0]);
										for (i = 0; i <= (*cate_siruri) - 2; i++)
											strcpy (siruri[i], siruri[i + 1]);
										(*cate_siruri)--;
									}
	//la sfarsit sterg comanda pe care am executat o si ii dau free
	TLista aux;
	aux = (*comenzi)->prim;
	(*comenzi)->prim = (*comenzi)->prim->urm;
	free(aux);
	if ((*comenzi)->prim == NULL) //coada pentru comenzi nu mai e circulara
		(*comenzi)->ultim = NULL;
}
int main() {
	coada *comenzi; //voi gandi coduri pentru fiecare comanda pusa in variabila comenzi
	TLista tren; //retin in variabila tren locomotiva si mecanicul, elemente ale unei liste dublu inlantuite
	int nr_comenzi = 0, nr_val = 0, cate_siruri = 0, i, j;
	char num_comanda[20], puse_tren[500], caracter, aux, siruri[100][100];
	if (init_comenzi(&comenzi)==0)
		return 0;
	//initializarea trenului ->trimit ca parametru adresa trenului pentru ca i se modifica inceputul
	if (init_tren(&tren)==0)
		return 0;
	FILE *file, *file_out;
	file = fopen("tema1.in", "r");
	file_out = fopen("tema1.out", "w");
	fscanf(file, "%d", &nr_comenzi);
	for (i = 1; i <= nr_comenzi; i++) {
		fscanf(file, "%s", num_comanda);
		if (strcmp(num_comanda, "MOVE_LEFT") == 0) //daca primesc comanda move_left trebuie sa o pun in coada->cod 0 pentru move_left
			pune_in_coada(&comenzi, '0');
		else if (strcmp(num_comanda, "MOVE_RIGHT") == 0) //daca primesc comanda move_right trebuie sa o pun in coada->cod 1 pentru move_right
				pune_in_coada(&comenzi, '1');
			else if (strcmp(num_comanda, "WRITE") == 0) {
				pune_in_coada(&comenzi, '2'); //un sir de caractere in care sa retin elementele pe care le voi pune in tren pt write, insert_left, insert_right
				fscanf(file, "%c%c", &aux, &puse_tren[nr_val++]); //trebuie sa citesc si spatiul si teminatorul de sir separat pentru a putea citi sirul si caracterul in modul in care vreau
				fscanf(file, "%c", &aux);
			}
				else if (strcmp(num_comanda, "CLEAR_CELL") == 0)
					pune_in_coada(&comenzi, '3');
					else if (strcmp(num_comanda, "CLEAR_ALL") == 0)
						pune_in_coada(&comenzi, '4');
						else if (strcmp(num_comanda, "INSERT_LEFT") == 0) {
							pune_in_coada(&comenzi, '5');
							fscanf(file, "%c%c", &aux, &puse_tren[nr_val++]);
							fscanf(file, "%c", &aux);
						}
							else if (strcmp(num_comanda, "INSERT_RIGHT") == 0) {
								pune_in_coada(&comenzi, '6');
								fscanf(file, "%c%c", &aux, &puse_tren[nr_val++]);
								fscanf(file, "%c", &aux);
							}
								else if (strcmp(num_comanda, "SEARCH") == 0) {
									pune_in_coada(&comenzi, '7');
									fscanf(file, "%c", &aux); //citesc spatiul
									fscanf(file, "%s", siruri[cate_siruri++]);
									fscanf(file, "%c", &aux); //citesc endline ul
								}
									else if (strcmp(num_comanda, "SEARCH_LEFT") == 0) {
										pune_in_coada(&comenzi, '8');
										fscanf(file, "%c", &aux);
										fscanf(file, "%s", siruri[cate_siruri++]);
										fscanf(file, "%c", &aux);
									}
										else if (strcmp(num_comanda, "SEARCH_RIGHT") == 0) {
											pune_in_coada(&comenzi, '9');
											fscanf(file, "%c", &aux);
											fscanf(file, "%s", siruri[cate_siruri++]);
											fscanf(file, "%c", &aux);
										}
											else if (strcmp(num_comanda, "SHOW_CURRENT") == 0)
												fprintf(file_out, "%c\n", tren->mecanic->info);
												else if (strcmp(num_comanda, "SHOW") == 0)
													show(file_out, tren);
													else if (strcmp(num_comanda, "SWITCH") == 0) {
														//inversez si valorile din coada de comenzi, si sirurile pe care le caut, si caracterele pe care le voi pune in tren
														for (j = 0; j <= nr_val / 2 - 1; j++) {
															aux = puse_tren[j];
															puse_tren[j] = puse_tren[nr_val-1-j];
															puse_tren[nr_val - 1 - j] = aux;
														}
														char sir_aux[100];
														for (j = 0; j <= cate_siruri / 2 - 1; j++) {
															strcpy(sir_aux, siruri[j]);
															strcpy(siruri[j], siruri[cate_siruri - 1 - j]);
															strcpy(siruri[cate_siruri - 1 - j], sir_aux);
														}
														//e de ajuns ca la inversarea cozii sa le schimb valorile(->info), care sunt codurile pentru comenzile ce tb executate
														TLista left, right;
														left = comenzi->prim;
														right = comenzi->ultim;
														while (left != right && left->ant != right) { //cat timp nu am trecut de jumatate
															aux = left->info;
															left->info = right->info;
															right->info = aux;
															left = left->urm;
															right = right->ant;
														}
													}
														else if (strcmp(num_comanda, "EXECUTE") == 0)
																execute(file_out, &comenzi, &tren, &nr_val, puse_tren, siruri, &cate_siruri);

		}
	clear_all(&tren);
	free(tren->mecanic);
	free(tren->locomotiva);
	free(tren);
	free(comenzi);
	fclose(file);
	fclose(file_out);
	return 0;
}
