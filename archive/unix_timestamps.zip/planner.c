#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "timelib.h"
#define cinci 5
#define suta 100
#define doi_cinci 25
#define trei_doi 32
#define unu_trei 13
#define patrusute 400
#define doi_noua 29
#define sase 6
#define sapte 7
#define opt 8
#define noua 9
#define zece 10
#define unsp 11
#define doisp 12
typedef struct {
    char n_timezone[4+1];
    int dif_UTC;
}timezones;
typedef struct {
    int ora_inceput, cate_ore;
}intervale;
typedef struct {
    char nume[suta], timezone_pers[cinci];
    int n_interv;
    intervale *v_interv, *interv_UTC;
    TDate *date, *date_UTC;
    int bun;
}persoane;
typedef struct {
    int ora[4*4+3*3];
}ore;
typedef struct {
    ore zi[4*4*2];
}zile;
typedef struct {
    zile luna[4*3+1];
}luni;
typedef struct {
    int pers_coresp[4*4+4*2];
}pers_c;
int main() {
    int T = 0, P = 0, F = 0, d_even = 0;
    timezones *v_tz = NULL;
    persoane *pers = NULL;
    pers_c *pp = NULL;
    scanf("%d", &T);
    v_tz = calloc(T, sizeof(timezones));
    for (int i = 0; i <= T-1; i++) {
        scanf("%s", v_tz[i].n_timezone);
        scanf("%d", &v_tz[i].dif_UTC);
    }
    scanf("%d", &P);
    pers = calloc(P, sizeof(persoane));
    pp = calloc(P, sizeof(persoane));
    for (int i = 0; i <= P-1; i++) {
        scanf("%s", pers[i].nume);
        scanf("%s", pers[i].timezone_pers);
        scanf("%d", &pers[i].n_interv);
        pers[i].date = calloc(pers[i].n_interv, sizeof(TDate));
        pers[i].date_UTC = calloc(pers[i].n_interv, sizeof(TDate));
        pers[i].v_interv = calloc(pers[i].n_interv, sizeof(intervale));
        pers[i].interv_UTC = calloc(pers[i].n_interv, sizeof(intervale));
        for (int j = 0; j <= pers[i].n_interv-1; j++) {
            scanf("%u", &pers[i].date[j].year);
            scanf("%hhu", &pers[i].date[j].month);
            scanf("%hhu", &pers[i].date[j].day);
            scanf("%d", &pers[i].v_interv[j].ora_inceput);
            scanf("%d", &pers[i].v_interv[j].cate_ore);
        }
    }
    scanf("%d", &F);
    scanf("%d", &d_even);
    int dif = 0;
    unsigned int an = 0;
    for (int i = 0; i <= P-1; i++) {
        for (int j = 0; j <= T-1; j++)
            if (strcmp(pers[i].timezone_pers, v_tz[j].n_timezone) == 0) {
                dif = v_tz[j].dif_UTC;
                j = T;
            }
        if (dif > 0) {
            for (int j = 0; j <= pers[i].n_interv-1; j++) {
                pers[i].interv_UTC[j].cate_ore = pers[i].v_interv[j].cate_ore;
                pers[i].interv_UTC[j].ora_inceput = pers[i].v_interv[j].ora_inceput - dif;
                pers[i].date_UTC[j] = pers[i].date[j];
                if (pers[i].interv_UTC[j].ora_inceput < 0) {
                    pers[i].interv_UTC[j].ora_inceput += (doi_cinci-1);
                    if (pers[i].date_UTC[j].day == 1) {
                        if (pers[i].date_UTC[j].month == 3) {
                            if (pers[i].date_UTC[j].year%4 == 0 && !(pers[i].date_UTC[j].year%suta == 0 &&
                            pers[i].date_UTC[j].year%patrusute != 0)) {
                                pers[i].date_UTC[j].month = 2;
                                pers[i].date_UTC[j].day = (doi_noua);
                            } else {
                                if (pers[i].date_UTC[j].year%4 != 0 || (pers[i].date_UTC[j].year%suta == 0 &&
                                pers[i].date_UTC[j].year%patrusute != 0)) {
                                pers[i].date_UTC[j].month = 2;
                                pers[i].date_UTC[j].day = (doi_noua-1);
                                }
                            }
                        } else if ((pers[i].date_UTC[j].month == cinci || pers[i].date_UTC[j].month == sapte ||
                        pers[i].date_UTC[j].month == zece || pers[i].date_UTC[j].month == doisp)) {
                            pers[i].date_UTC[j].month--;
                            pers[i].date_UTC[j].day = (doi_noua+1);
                        } else if (pers[i].date_UTC[j].month == 2 || pers[i].date_UTC[j].month == 4 ||
                        pers[i].date_UTC[j].month == sase || pers[i].date_UTC[j].month == opt ||
                        pers[i].date_UTC[j].month == noua ||
                        pers[i].date_UTC[j].month == unsp) {
                            pers[i].date_UTC[j].month--;
                            pers[i].date_UTC[j].day = (doi_noua+2);
                        } else if (pers[i].date_UTC[j].month == 1) {
                            pers[i].date_UTC[j].year--;
                            pers[i].date_UTC[j].month = doisp;
                            pers[i].date_UTC[j].day = (doi_noua+2);
                        }
                    } else {
                        pers[i].date_UTC[j].day--;
                    }
                }
                an = pers[i].date_UTC[j].year;
            }
        } else {
            if (dif < 0) {
                dif = -dif;
                for (int j = 0; j <= pers[i].n_interv-1; j++) {
                    pers[i].interv_UTC[j].cate_ore = pers[i].v_interv[j].cate_ore;
                    pers[i].interv_UTC[j].ora_inceput = pers[i].v_interv[j].ora_inceput + dif;
                    pers[i].date_UTC[j] = pers[i].date[j];
                    if (pers[i].interv_UTC[j].ora_inceput > (doi_cinci-2)) {
                        pers[i].interv_UTC[j].ora_inceput = pers[i].interv_UTC[j].ora_inceput%(doi_cinci-1);
                        pers[i].date_UTC[j].day = pers[i].date[j].day + 1;
                        if (pers[i].date_UTC[j].month == 2) {
                            if (pers[i].date_UTC[j].year%4 == 0 && !(pers[i].date_UTC[j].year%suta == 0 &&
                            pers[i].date_UTC[j].year%patrusute != 0) && pers[i].date_UTC[j].day > (doi_noua)) {
                                pers[i].date_UTC[j].month = 3;
                                pers[i].date_UTC[j].day = 1;
                            } else {
                                if ((pers[i].date_UTC[j].year%4 != 0 || (pers[i].date_UTC[j].year%suta == 0 &&
                                pers[i].date_UTC[j].year%patrusute != 0)) && pers[i].date_UTC[j].day > (doi_noua-1)) {
                                    pers[i].date_UTC[j].month = 3;
                                    pers[i].date_UTC[j].day = 1;
                                }
                            }
                        } else if ((pers[i].date_UTC[j].month == 4 || pers[i].date_UTC[j].month == sase ||
                        pers[i].date_UTC[j].month == noua || pers[i].date_UTC[j].month == unsp)
                        && pers[i].date_UTC[j].day > (doi_noua+1)) {
                            pers[i].date_UTC[j].month++;
                            pers[i].date_UTC[j].day = 1;
                        } else if ((pers[i].date_UTC[j].month == 1 || pers[i].date_UTC[j].month == 3 ||
                        pers[i].date_UTC[j].month == cinci || pers[i].date_UTC[j].month == sapte ||
                        pers[i].date_UTC[j].month == opt ||
                        pers[i].date_UTC[j].month == zece) && pers[i].date_UTC[j].day > (doi_noua+2)) {
                            pers[i].date_UTC[j].month++;
                            pers[i].date_UTC[j].day = 1;
                        } else if (pers[i].date_UTC[j].month == doisp && pers[i].date_UTC[j].day > (doi_noua+2)) {
                            pers[i].date_UTC[j].year++;
                            pers[i].date_UTC[j].month = 1;
                            pers[i].date_UTC[j].day = 1;
                        }
                    }
                    an = pers[i].date_UTC[j].year;
                }
            } else if (dif == 0) {
                pers[i].date_UTC = pers[i].date;
                pers[i].interv_UTC = pers[i].v_interv;
                for (int j = 0; j <= pers[i].n_interv-1; j++)
                    an = pers[i].date_UTC[j].year;
            }
        }
    }
    /*
    for (int i = 0; i <= P-1; i++) {
        printf("%s\n", pers[i].nume);
        for (int j = 0; j <= pers[i].n_interv-1; j++) {
            printf("%u ", pers[i].date_UTC[j].year);
            printf("%u ", pers[i].date_UTC[j].month);
            printf("%u ", pers[i].date_UTC[j].day);
            printf("%d ", pers[i].interv_UTC[j].ora_inceput);
            printf("%d\n", pers[i].interv_UTC[j].cate_ore);
        }
    }*/
    luni vect_frecv;
    for (int i = 1; i <= doisp; i++)
        for (int j = 1; j <= (doi_noua+2); j++)
             for (int k = 0; k <= (doi_cinci-2); k++)
                 vect_frecv.luna[i].zi[j].ora[k] = 0;
    for (int i = 0; i <= P-1; i++) {
        for (int j = 0; j <= pers[i].n_interv-1; j++) {
            for (int k = 0; k <= pers[i].interv_UTC[j].cate_ore-1; k++) {
                if (pers[i].interv_UTC[j].ora_inceput+k >= (doi_cinci-1)) {
                    if (pers[i].date_UTC[j].month == 2) {
                        if (an%4 == 0 && !(an%suta == 0 && an%patrusute != 0) && pers[i].date_UTC[j].day == doi_noua)
                            vect_frecv.luna[3].zi[1].ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                        else
                        if ((an%4 != 0 || (an%suta == 0 && an%patrusute != 0)) &&
                        pers[i].date_UTC[j].day == (doi_noua-1))
                            vect_frecv.luna[3].zi[1].ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                        else
                            vect_frecv.luna[2].zi[pers[i].date_UTC[j].day+1].
                            ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                    } else {
                        if (pers[i].date_UTC[j].month == 4 || pers[i].date_UTC[j].month == sase ||
                        pers[i].date_UTC[j].month == noua ||
                        pers[i].date_UTC[j].month == unsp) {
                            if (pers[i].date_UTC[j].day == (doi_noua+1))
                                vect_frecv.luna[pers[i].date_UTC[j].month+1].zi[1].
                                ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                            else
                                vect_frecv.luna[pers[i].date_UTC[j].month].zi[pers[i].date_UTC[j].day+1].
                                ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                        } else {
                        if (pers[i].date_UTC[j].month == 1 || pers[i].date_UTC[j].month == 3 ||
                        pers[i].date_UTC[j].month == cinci || pers[i].date_UTC[j].month == sapte ||
                        pers[i].date_UTC[j].month == opt ||
                        pers[i].date_UTC[j].month == zece || pers[i].date_UTC[j].month == doisp) {
                            if (pers[i].date_UTC[j].day == (doi_noua+2))
                                vect_frecv.luna[pers[i].date_UTC[j].month+1].zi[1].
                                ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                            else
                                vect_frecv.luna[pers[i].date_UTC[j].month].zi[pers[i].date_UTC[j].day+1].
                                ora[(pers[i].interv_UTC[j].ora_inceput+k)%(doi_cinci-1)]++;
                        }
                    }
                    }
                } else {
                    vect_frecv.luna[pers[i].date_UTC[j].month].zi[pers[i].date_UTC[j].day].
                    ora[pers[i].interv_UTC[j].ora_inceput+k]++;
                }
            }
        }
    }
    int ok = 0, OK = 0, zi_buna = 0;
    for (int i = 1; i <= doisp && OK == 0; i++) {
        for (int j= 1; j <= (doi_noua+2) && OK == 0; j++) {
            for (int k = 0; k <= (doi_cinci-2)-d_even+1 && OK == 0; k++) {
                int verif = vect_frecv.luna[i].zi[j].ora[k];
                if (verif >= F) {
                    ok = 1;
                    for (int l = 1; l <= d_even-1 && ok == 1; l++)
                        if (vect_frecv.luna[i].zi[j].ora[k+l] < F)
                            ok = 0;
                    if (ok == 1) {
                        for (int l = 0; l <= P-1; l++)
                            for (int m = 0; m <= (doi_cinci-2); m++)
                                pp[l].pers_coresp[m] = 0;
                        for (int l = 0; l <= P-1; l++)
                            for (int m = 0; m <= pers[l].n_interv-1; m++) {
                                if (pers[l].date_UTC[m].month == i && pers[l].date_UTC[m].day == j &&
                                k >= pers[l].interv_UTC[m].ora_inceput &&
                                k+d_even <= pers[l].interv_UTC[m].ora_inceput+pers[l].interv_UTC[m].cate_ore) {
                                    pp[l].pers_coresp[k]++;
                                    zi_buna = pers[l].date_UTC[m].day;
                                } else {
                                if (pers[l].date_UTC[m].month == i && pers[l].date_UTC[m].day == j-1 &&
                                pers[l].interv_UTC[m].ora_inceput+pers[l].
                                interv_UTC[m].cate_ore >= (doi_cinci-1) &&
                                k+d_even <= (pers[l].interv_UTC[m].ora_inceput+pers[l].
                                interv_UTC[m].cate_ore)%(doi_cinci-1)) {
                                    pp[l].pers_coresp[k]++;
                                    zi_buna = pers[l].date_UTC[m].day;
                                }
                                }
                            }
                        int cnt = 0;
                        for (int l = 0; l <= P-1; l++)
                            if (pp[l].pers_coresp[k] != 0)
                                cnt++;
                        if (cnt >= F)
                            OK = 1;
                    }
                }
            }
        }
    }
    for (int i = 0; i <= P-1; i++)
        pers[i].bun = 0;
    int ORA = 0;
    if (OK == 0) {
        printf("imposibil");
    } else {
        for (int l = 0; l <= P-1; l++)
            for (int k = 0; k <= (doi_cinci-2)-d_even+1; k++)
                if (pp[l].pers_coresp[k] != 0) {
                    ORA = k;
                    pers[l].bun = 1;
                }
        do {
            ok = 1;
            for (int i = 0; i <= P-2; i++)
                if (strcmp(pers[i].nume, pers[i+1].nume) > 0) {
                    persoane aux = pers[i];
                    pers[i] = pers[i+1];
                    pers[i+1] = aux;
                    ok = 0;
                }
        }while (ok == 0);
        for (int i = 0; i <= P-1; i++) {
            if (pers[i].bun == 0) {
                printf("%s: ", pers[i].nume);
                printf("invalid\n");
            } else {
                for (int j = 0; j <= T-1; j++)
                    if (strcmp(pers[i].timezone_pers, v_tz[j].n_timezone) == 0) {
                    printf("%s: ", pers[i].nume);
                    if (ORA+v_tz[j].dif_UTC >= (doi_cinci-1))
                        printf("%02d ", zi_buna+1);
                    else
                    if (ORA+v_tz[j].dif_UTC < 0)
                        printf("%02d ", zi_buna-1);
                    else
                        printf("%02d ", zi_buna);
                    if (pers[i].date[0].month == 1)
                        printf("ianuarie ");
                    else
                    if (pers[i].date[0].month == 2)
                        printf("februarie ");
                    else
                    if (pers[i].date[0].month == 3)
                        printf("martie ");
                    else
                    if (pers[i].date[0].month == 4)
                        printf("aprilie ");
                    else
                    if (pers[i].date[0].month == cinci)
                        printf("mai ");
                    else
                    if (pers[i].date[0].month == sase)
                        printf("iunie ");
                    else
                    if (pers[i].date[0].month == sapte)
                        printf("iulie ");
                    else
                    if (pers[i].date[0].month == opt)
                        printf("august ");
                    else
                    if (pers[i].date[0].month == noua)
                        printf("septembrie ");
                    else
                    if (pers[i].date[0].month == zece)
                        printf("octombrie ");
                    else
                    if (pers[i].date[0].month == unsp)
                        printf("noiembrie ");
                    else
                    if (pers[i].date[0].month == doisp)
                        printf("decembrie ");
                    printf("%u, ", an);
                    if (ORA+v_tz[j].dif_UTC >= 0)
                        printf("%02d:00:00", (ORA+v_tz[j].dif_UTC)%(doi_cinci-1));
                    else
                    printf("%02d:00:00", ORA+v_tz[j].dif_UTC+(doi_cinci-1));
                    printf(" %s ", pers[i].timezone_pers);
                    printf("(UTC%+d)\n", v_tz[j].dif_UTC);
                }
            }
        }
    }
    return 0;
}
