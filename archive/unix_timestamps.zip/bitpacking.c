#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "timelib.h"
#define mia 1000
#define trei_unu 31
#define unu_cinci 15
#define an_plecare 1970
#define sase_trei 63
#define nr_mare 16383
#define totul_unu 32767
#define cinci 5
#define sase 6
#define sapte 7
#define opt 8
#define noua 9
#define zece 10
#define unsp 11
#define doisp 12
#define opt_unu_noua_unu 8191
#define doi_sase 26
#define doi_cinci_cinci 255
#define douazeci 20
#define omiedoitrei 1023
#define patru_zero_noua_cinci 4095
#define unu_doi_sapte 127
#define cinci_unu_unu 511
#define doi_zero_patru_sapte 2047
void exercitiu7(int n, unsigned int vect[]) {
    TDate v[2*2*2*(4+1)*(4+1)*(4+1)];
    int ok = 0;
    unsigned int x = 0, masca1 = trei_unu, masca2 = unu_cinci, masca3 = sase_trei;
    for (int i = 0; i <= n-1; i++) {
        x = vect[i];
        v[i].day = x&masca1;
        v[i].month = (x >> cinci)&masca2;
        v[i].year = an_plecare + ((x >> noua)&masca3);
    }
    do {
        ok = 1;
        for (int i = 0; i <= n-2; i++) {
            if ((v[i].year > v[i+1].year) || (v[i].year == v[i+1].year && v[i].month > v[i+1].month) ||
            (v[i].year == v[i+1].year && v[i].month == v[i+1].month && v[i].day > v[i+1].day)) {
                TDate aux = v[i];
                v[i] = v[i+1];
                v[i+1] = aux;
                ok = 0;
            }
        }
    } while (ok == 0);
    for (int i = 0; i <= n-1; i++) {
        if (v[i].day != 0) {
        printf("%u ", v[i].day);
        if (v[i].month == 1)
            printf("ianuarie ");
        else
        if (v[i].month == 2)
            printf("februarie ");
        else
        if (v[i].month == 3)
            printf("martie ");
        else
        if (v[i].month == 4)
            printf("aprilie ");
        else
        if (v[i].month == cinci)
            printf("mai ");
        else
        if (v[i].month == sase)
            printf("iunie ");
        else
        if (v[i].month == sapte)
            printf("iulie ");
        else
        if (v[i].month == opt)
            printf("august ");
        else
        if (v[i].month == noua)
            printf("septembrie ");
        else
        if (v[i].month == zece)
            printf("octombrie ");
        else
        if (v[i].month == unsp)
            printf("noiembrie ");
        else
        if (v[i].month == doisp)
            printf("decembrie ");
        printf("%u\n", v[i].year);
        }
    }
}
void exercitiu8() {
    int n = 0;
    unsigned int *p = NULL, *control = NULL, verif[mia], masca = UINT_MAX, data = 0, vect_bun[mia];
    int N_bun = 0;
    scanf("%d", &n);
    int c = n*unu_cinci/(trei_unu+1), cnt = 0;
    if (c*(trei_unu+1) == n*unu_cinci) {
        p = calloc(c, sizeof(int));
    } else {
        p = calloc(c+1, sizeof(int));
        c++;
      }
    for (int i = 0; i <= c-1; i++)
        scanf("%u", &p[i]);
    cnt = c/(trei_unu+1);
    if (cnt*(trei_unu+1) == c) {
        control = calloc(cnt, sizeof(int));
    } else {
        control = calloc(cnt+1, sizeof(int));
        cnt++;
    }
    for (int i = 0; i <= cnt-1; i++)
        scanf("%u", &control[i]);
    for (int i = 0; i <= c-1; i++) {
        masca = 1;
        int val = 0;
        for (int j = 0 ; j <= trei_unu; j++) {
            if ((masca&p[i]) != 0)
                val++;
            masca = masca << 1;
        }
        int x = (i+1)/(trei_unu+1);
        if (x*(trei_unu+1) == i+1) {
            if (val%2 == ((control[x-1] >> trei_unu)&1))
                verif[i] = 1;
            else
                verif[i] = 0;
        } else {
            if (val%2 == ((control[x]>>((i+1)%(trei_unu+1)-1))&1))
                verif[i] = 1;
            else
                verif[i] = 0;
        }
    }
    masca = totul_unu;
    for (int i = 0; i <= c-1; i++)
        if (verif[i] == 1) {
            if (i%unu_cinci == 0) {
                data = p[i]&masca;
                vect_bun[N_bun++] = data;
                data = (p[i] >> unu_cinci)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == 1) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << 2)+((p[i-1] >> (trei_unu-1))&3))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> (doisp+1))&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == 2) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << 4)+((p[i-1] >> (doi_sase+2))&unu_cinci))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> unsp)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == 3) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << sase)+((p[i-1] >> doi_sase)&sase_trei))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> noua)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == 4) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << opt)+((p[i-1] >> (doi_sase-2))&doi_cinci_cinci))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> sapte)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == cinci) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << zece)+((p[i-1] >> (douazeci+2))&omiedoitrei))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> cinci)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == sase) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << doisp)+((p[i-1] >> douazeci)&patru_zero_noua_cinci))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> 3)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == sapte) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << (unu_cinci-1))+((p[i-1] >> (unu_cinci+3))&nr_mare))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> 1)&masca;
                vect_bun[N_bun++] = data;
                data = (p[i] >> (unu_cinci+1))&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == opt) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << 1)+((p[i-1] >> trei_unu)&1))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> (unu_cinci-1))&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == noua) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << 3)+((p[i-1] >> (doi_sase+3))&sapte))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> doisp)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == zece) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << cinci)+((p[i-1] >> (doi_sase+1))&trei_unu))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> zece)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == unsp) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << sapte)+((p[i-1] >> (doi_sase-1))&unu_doi_sapte))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> opt)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == doisp) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << noua)+((p[i-1] >> (doi_sase-3))&cinci_unu_unu))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> sase)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == (doisp+1)) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << unsp)+((p[i-1] >>(douazeci+1))&doi_zero_patru_sapte))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> 4)&masca;
                vect_bun[N_bun++] = data;
            } else {
            if (i%unu_cinci == (unu_cinci-1)) {
                if (verif[i-1] == 1) {
                    data = ((p[i] << (doisp+1))+((p[i-1] >> (unu_cinci+4))&opt_unu_noua_unu))&masca;
                    vect_bun[N_bun++] = data;
                }
                data = (p[i] >> 2)&masca;
                vect_bun[N_bun++] = data;
                data = (p[i] >> (unu_cinci+2))&masca;
                vect_bun[N_bun++] = data;
            }
        } } } } } } } } } } } } } }
    }
    exercitiu7(N_bun, vect_bun);
}
int main() {
    int ntask = 0, n = 0;
    unsigned int vect[mia];
    scanf("%d", &ntask);
    if (ntask == sapte) {
        scanf("%d", &n);
        for (int i = 0; i <= n-1; i++)
            scanf("%u", &vect[i]);
        exercitiu7(n, vect);
    } else {
    if (ntask == opt)
        exercitiu8();
    }
    return 0;
}
