#include <stdio.h>
#include <stdlib.h>
#include "timelib.h"
#define sec_in_o_zi 86400
#define sec_in_o_ora 3600
#define sec_in_un_min 60
#define sec_in_an_nebis 31536000
#define an_plecare 1970
#define sec_feb 2419200
#define sec_luni_30 2592000
#define sec_luni_31 2678400
#define sec_an_bis 31622400
#define sec_feb_bis 2505600
#define suta 100
#define psute 400
#define cinci 5
#define sase 6
#define sapte 7
#define opt 8
#define noua 9
#define zece 10
#define unsp 11
#define doisp 12
#define treizeci 30
#define doi_patru 24
TTime convertUnixTimestampToTime(unsigned int timestamp) {
    TTime result;
    timestamp = timestamp%sec_in_o_zi;
    result.hour = timestamp/sec_in_o_ora;
    timestamp = timestamp%sec_in_o_ora;
    result.min = timestamp/sec_in_un_min;
    timestamp = timestamp%sec_in_un_min;
    result.sec = timestamp;
    return result;
}
TDate convertUnixTimestampToDateWithoutLeapYears(unsigned int timestamp) {
    TDate result;
    unsigned int ani = 0, cnt = 0, verif = 1;
    ani = timestamp/sec_in_an_nebis;
    timestamp = timestamp%sec_in_an_nebis;
    result.year = an_plecare+ani;
    while (verif == 1) {
        cnt++;
        if (cnt == 2 && timestamp >= sec_feb)
            timestamp -= sec_feb;
        else
        if ((cnt == 4 || cnt == sase || cnt == noua || cnt == unsp) && timestamp >= sec_luni_30)
            timestamp -= sec_luni_30;
        else
        if (timestamp >= sec_luni_31) {
            timestamp -= sec_luni_31;
        } else {
            result.month = cnt;
            result.day = timestamp/sec_in_o_zi+1;
            verif = 0;
            }
        }
    return result;
}

TDate convertUnixTimestampToDate(unsigned int timestamp) {
    TDate result;
    unsigned int ctimestamp = timestamp, cnt = 0, verif = 1;
    result.year = an_plecare;
    while (verif == 1) {
        if ((result.year%4 != 0 || (result.year%suta == 0 && result.year%psute != 0))
        && ctimestamp >= sec_in_an_nebis) {
                ctimestamp -= sec_in_an_nebis;
                result.year++;
            } else if (ctimestamp >= sec_an_bis) {
                ctimestamp -= sec_an_bis;
                result.year++;
            } else {
                timestamp = ctimestamp;
                verif = 0;
            }
    }
    verif = 1;
    if (result.year%4 == 0 && !(result.year%suta == 0 && result.year%psute != 0)) {
        while (verif == 1) {
            cnt++;
            if (cnt == 2 && timestamp >= sec_feb_bis)
                timestamp -= sec_feb_bis;
            else
            if ((cnt == 4 || cnt == sase || cnt == noua || cnt == unsp) && timestamp >= sec_luni_30) {
                timestamp -= sec_luni_30;
            } else {
                if (timestamp >= sec_luni_31) {
                    timestamp -= sec_luni_31;
                } else {
                    result.month = cnt;
                    result.day = timestamp/sec_in_o_zi+1;
                    verif = 0;
                }
            }
        }
    } else {
        while (verif == 1) {
            cnt++;
            if (cnt == 2 && timestamp >= sec_feb)
                timestamp -= sec_feb;
            else
            if ((cnt == 4 || cnt == sase || cnt == noua || cnt == unsp) && timestamp >= sec_luni_30)
                timestamp -= sec_luni_30;
            else
            if (timestamp >= sec_luni_31) {
                timestamp -= sec_luni_31;
            } else {
                result.month = cnt;
                result.day = timestamp/sec_in_o_zi+1;
                verif = 0;
            }
        }
    }
    return result;
}
TDateTimeTZ convertUnixTimestampToDateTimeTZ(unsigned int timestamp, TTimezone *timezones, int timezone_index) {
    TDateTimeTZ result;
    result.tz = timezones+timezone_index;
    if (timestamp+timezones[timezone_index].utc_hour_difference*sec_in_o_ora < 0) {
        int timestamp_neg = (int)(timestamp+timezones[timezone_index].utc_hour_difference*sec_in_o_ora);
        int secunde = -timestamp_neg-1;
        result.date.year = an_plecare-1;
        result.date.month = doisp;
        result.date.day = treizeci+1;
        result.time.hour = doi_patru-1-secunde/sec_in_o_ora;
        secunde = secunde%sec_in_o_ora;
        result.time.min = (sec_in_un_min-1)-secunde/sec_in_un_min;
        secunde = secunde%sec_in_un_min;
        result.time.sec = (sec_in_un_min-1)-secunde;
        return result;
    } else  {
        timestamp += timezones[timezone_index].utc_hour_difference*sec_in_o_ora;
        unsigned int ctimestamp = timestamp, cnt = 0, verif = 1;
        result.date.year = an_plecare;
        while (verif == 1) {
            if ((result.date.year%4 != 0 || (result.date.year%suta == 0 && result.date.year%psute != 0))
            && ctimestamp >= sec_in_an_nebis) {
                    ctimestamp -= sec_in_an_nebis;
                    result.date.year++;
                } else {
                    if (ctimestamp >= sec_an_bis) {
                        ctimestamp -= sec_an_bis;
                        result.date.year++;
                    } else {
                        timestamp = ctimestamp;
                        verif = 0;
                    }
                }
        }
        verif = 1;
        if (result.date.year%4 == 0 && !(result.date.year%suta == 0 && result.date.year%psute != 0)) {
            while (verif == 1) {
                cnt++;
                if (cnt == 2 && ctimestamp >= sec_feb_bis)
                    ctimestamp -= sec_feb_bis;
                else
                if ((cnt == 4 || cnt == sase || cnt == noua || cnt == unsp) && ctimestamp >= sec_luni_30)
                    ctimestamp -= sec_luni_30;
                else
                if (ctimestamp >= sec_luni_31) {
                    ctimestamp -= sec_luni_31;
                } else {
                    result.date.month = cnt;
                    result.date.day = ctimestamp/sec_in_o_zi+1;
                    timestamp = ctimestamp%sec_in_o_zi;
                    verif = 0;
                }
            }
        } else {
            while (verif == 1) {
                cnt++;
                if (cnt == 2 && ctimestamp >= sec_feb)
                    ctimestamp -= sec_feb;
                else
                if ((cnt == 4 || cnt == sase || cnt == noua || cnt == unsp) && ctimestamp >= sec_luni_30)
                    ctimestamp -= sec_luni_30;
                else
                if (ctimestamp >= sec_luni_31) {
                    ctimestamp -= sec_luni_31;
                } else {
                    result.date.month = cnt;
                    result.date.day = ctimestamp/sec_in_o_zi+1;
                    timestamp = ctimestamp%sec_in_o_zi;
                    verif = 0;
                }
            }
        }
        result.time = convertUnixTimestampToTime(timestamp);
        return result;
    }
}

unsigned int convertDateTimeTZToUnixTimestamp(TDateTimeTZ variabila) {
    unsigned int total = 0;
    for (unsigned int i = variabila.date.year-1; i >= an_plecare; i--) {
        if (i%4 == 0 && !(i%suta == 0 && i%psute != 0))
            total+=sec_an_bis;
        else
            total+=sec_in_an_nebis;
    }
    for (int i = 1; i < variabila.date.month; i++) {
        if (i == 2) {
            if (variabila.date.year%4 == 0 && !(variabila.date.year%suta == 0 && variabila.date.year%psute != 0))
                total+=sec_feb_bis;
            else
                total+=sec_feb;
        } else {
            if (i == 4 || i == sase || i == noua || i == unsp)
                total+=sec_luni_30;
            else
                total+=sec_luni_31;
        }
    }
    total+=(variabila.date.day-1)*sec_in_o_zi;
    total+=variabila.time.hour*sec_in_o_ora;
    total+=variabila.time.min*sec_in_un_min;
    total+=variabila.time.sec;
    total -= variabila.tz[0].utc_hour_difference*sec_in_o_ora;
    return total;
}

void printDateTimeTZ(TDateTimeTZ datetimetz) {
    printf("%02u", datetimetz.date.day);
    if (datetimetz.date.month == 1)
        printf(" ianuarie ");
    else
    if (datetimetz.date.month == 2)
        printf(" februarie ");
    else
    if (datetimetz.date.month == 3)
        printf(" martie ");
    else
    if (datetimetz.date.month == 4)
        printf(" aprilie ");
    else
    if (datetimetz.date.month == cinci)
        printf(" mai ");
    else
    if (datetimetz.date.month == sase)
        printf(" iunie ");
    else
    if (datetimetz.date.month == sapte)
        printf(" iulie ");
    else
    if (datetimetz.date.month == opt)
        printf(" august ");
    else
    if (datetimetz.date.month == noua)
        printf(" septembrie ");
    else
    if (datetimetz.date.month == zece)
        printf(" octombrie ");
    else
    if (datetimetz.date.month == unsp)
        printf(" noiembrie ");
    else
        printf(" decembrie ");
    printf("%u, ", datetimetz.date.year);
    printf("%02u:", datetimetz.time.hour);
    printf("%02u:", datetimetz.time.min);
    printf("%02u ", datetimetz.time.sec);
    printf("%s ", datetimetz.tz[0].name);
    printf("(UTC");
    printf("%+d)", datetimetz.tz[0].utc_hour_difference);
}
